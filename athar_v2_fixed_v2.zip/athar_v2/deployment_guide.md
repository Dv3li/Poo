# دليل تشغيل بوت أثر التعليمي على السيرفر

هذا الدليل يوضح الخطوات اللازمة لتشغيل بوت أثر التعليمي على خادم لينكس (مثل Ubuntu) باستخدام `systemd` لإدارة الخدمة، مع التركيز على حل المشاكل الشائعة التي قد تمنع البوت من العمل.

## 1. المتطلبات الأساسية

قبل البدء، تأكد من توفر المتطلبات التالية على خادمك:

*   **نظام تشغيل لينكس**: يفضل Ubuntu 20.04 أو أحدث.
*   **Python 3.9+**: تأكد من تثبيت إصدار حديث من بايثون.
*   **pip**: مدير حزم بايثون.
*   **git** (اختياري): إذا كنت ستستنسخ المستودع مباشرة.
*   **صلاحيات `sudo`**: لتثبيت الحزم وإدارة الخدمات.

## 2. خطوات النشر (Deployment Steps)

اتبع هذه الخطوات لتجهيز وتشغيل البوت على السيرفر:

### 2.1. تحديث النظام وتثبيت بايثون

افتح طرفية SSH واتصل بسيرفرك، ثم قم بتحديث حزم النظام وتثبيت بايثون 3.10 (إذا لم يكن مثبتاً):

```bash
sudo apt update
sudo apt upgrade -y
sudo apt install python3.10 python3.10-venv python3-pip -y
```

### 2.2. إنشاء مستخدم خاص بالبوت (موصى به للأمان)

لأسباب أمنية، يفضل عدم تشغيل البوت بصلاحيات `root`. قم بإنشاء مستخدم جديد خاص بالبوت:

```bash
sudo adduser atharbot
```

ثم قم بالتبديل إلى هذا المستخدم:

```bash
sudo su - atharbot
```

**ملاحظة**: إذا كنت تفضل تشغيل البوت كمستخدم `root` (غير موصى به)، يمكنك تخطي هذه الخطوة والاستمرار كمستخدم `root`، ولكن ستحتاج إلى تعديل بعض المسارات في الخطوات التالية لتناسب مسار `/root/`.

### 2.3. نقل ملفات البوت

انقل مجلد البوت `athar_v2` (الذي يحتوي على `main.py`, `requirements.txt`, `.env`, إلخ) إلى مجلد `home` الخاص بالمستخدم `atharbot`:

```bash
mkdir /home/atharbot/athar_v2
# استخدم scp أو أي طريقة أخرى لنقل الملفات إلى هذا المسار
# مثال باستخدام scp من جهازك المحلي:
# scp -r /path/to/local/athar_v2 atharbot@your_server_ip:/home/atharbot/
```

تأكد من أن ملف `.env` موجود داخل مجلد `athar_v2` ويحتوي على `BOT_TOKEN` الصحيح.

### 2.4. إنشاء البيئة الافتراضية وتثبيت المكتبات

داخل مجلد البوت، قم بإنشاء بيئة بايثون افتراضية وتثبيت المكتبات المطلوبة:

```bash
cd /home/atharbot/athar_v2
python3.10 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
deactivate
```

### 2.5. إعداد ملف خدمة `systemd`

ملف `athar.service` الذي قمت بتعديله يحتاج إلى وضعه في المسار الصحيح وتعديل بعض الإعدادات ليناسب المستخدم الجديد والمسارات.

**أولاً**: تأكد من أن محتوى ملف `athar.service` الخاص بك هو كالتالي (تم تعديل `User` و `WorkingDirectory` و `ExecStart`):

```ini
[Unit]
Description=Athar Telegram Bot
After=network.target

[Service]
Type=simple
User=atharbot
WorkingDirectory=/home/atharbot/athar_v2
ExecStart=/home/atharbot/athar_v2/venv/bin/python3 main.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

**ثانياً**: انقل هذا الملف إلى مسار خدمات `systemd`:

```bash
sudo cp /home/atharbot/athar_v2/athar.service /etc/systemd/system/
```

**ثالثاً**: قم بتعيين الصلاحيات الصحيحة لملفات البوت:

```bash
sudo chown -R atharbot:atharbot /home/atharbot/athar_v2
```

### 2.6. تفعيل وتشغيل خدمة البوت

الآن، قم بإعادة تحميل خدمات `systemd`، تفعيل خدمة البوت، وتشغيلها:

```bash
sudo systemctl daemon-reload
sudo systemctl enable athar.service
sudo systemctl start athar.service
```

## 3. التحقق من حالة البوت والسجلات

للتحقق مما إذا كان البوت يعمل بشكل صحيح، استخدم الأوامر التالية:

*   **التحقق من الحالة**: 
    ```bash
sudo systemctl status athar.service
    ```
    يجب أن ترى `active (running)`.

*   **عرض السجلات**: 
    ```bash
sudo journalctl -u athar.service -f
    ```
    هذا الأمر سيعرض سجلات البوت في الوقت الفعلي. ابحث عن أي رسائل خطأ.

## 4. استكشاف الأخطاء الشائعة (Troubleshooting)

إذا لم يعمل البوت، إليك بعض المشاكل الشائعة وحلولها:

*   **`ValueError: BOT_TOKEN فارغ! تأكد من ملف .env`**:
    *   **السبب**: ملف `.env` غير موجود في `athar_v2/`، أو لا يحتوي على `BOT_TOKEN=YOUR_TOKEN_HERE`، أو أن `BOT_TOKEN` فارغ.
    *   **الحل**: تأكد من وجود ملف `.env` في المسار الصحيح، وأنه يحتوي على توكن البوت الخاص بك.

*   **`sqlite3.OperationalError: database is locked`**:
    *   **السبب**: مشكلة تزامن مع قاعدة بيانات SQLite. لقد قمت بتعديل الكود لإضافة مهلة زمنية، ولكن إذا استمرت المشكلة تحت ضغط عالٍ، فقد تحتاج إلى حلول إضافية.
    *   **الحل**: تأكد من أنك تستخدم النسخة المحدثة من الكود. إذا استمرت المشكلة، قد تحتاج إلى النظر في استخدام قاعدة بيانات مختلفة (مثل PostgreSQL) أو تحسين منطق الوصول إلى قاعدة البيانات.

*   **`ModuleNotFoundError` أو `ImportError`**:
    *   **السبب**: مكتبة بايثون غير مثبتة، أو البيئة الافتراضية لم يتم تفعيلها بشكل صحيح، أو أن `python3.10` غير موجود في المسار المحدد في `ExecStart`.
    *   **الحل**: تأكد من أنك قمت بتثبيت جميع المكتبات باستخدام `pip install -r requirements.txt` داخل البيئة الافتراضية. تأكد من أن المسار في `ExecStart` صحيح (`/home/atharbot/athar_v2/venv/bin/python3`).

*   **`Permission Denied`**:
    *   **السبب**: المستخدم الذي يقوم بتشغيل البوت (atharbot) ليس لديه صلاحيات كافية للوصول إلى الملفات أو المجلدات.
    *   **الحل**: تأكد من أنك قمت بتعيين الصلاحيات الصحيحة باستخدام `sudo chown -R atharbot:atharbot /home/atharbot/athar_v2`.

*   **`ExecStart` فشل أو البوت لا يبدأ**:
    *   **السبب**: قد يكون هناك خطأ في مسار `ExecStart` أو `WorkingDirectory` في ملف `athar.service`.
    *   **الحل**: تحقق جيداً من المسارات في ملف `athar.service` وتأكد من أنها تشير إلى الموقع الفعلي لملفات البوت والبيئة الافتراضية.

## 5. إعادة تشغيل البوت

بعد أي تغييرات في ملفات البوت أو ملف الخدمة، يجب إعادة تشغيل الخدمة لتطبيق التغييرات:

```bash
sudo systemctl restart athar.service
```

آمل أن يساعدك هذا الدليل في تشغيل البوت بنجاح! إذا واجهت أي مشاكل أخرى، فلا تتردد في طلب المساعدة مع تقديم رسائل الخطأ الكاملة من `journalctl`.
