"""
bot.py — نقطة البداية
يشغّل البوت ويبدأ حلقة الذكاء في الخلفية
"""

import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage

from config import BOT_TOKEN
from database import init_db
from handlers import common, study, plan, challenges, stats, quiz, motivation
from behavior import behavior_loop

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)


async def main():
    bot = Bot(token=8710102462:AAGr6DtJRzbFnu-qGTnYwNoqJdSPPCXy6hM)
    storage = MemoryStorage()
    dp = Dispatcher(storage=storage)

    # ── تسجيل الـ Routers ──────────────────────────────────
    dp.include_router(common.router)
    dp.include_router(study.router)
    dp.include_router(plan.router)
    dp.include_router(challenges.router)
    dp.include_router(stats.router)
    dp.include_router(quiz.router)
    dp.include_router(motivation.router)

    # ── تهيئة قاعدة البيانات ──────────────────────────────
    await init_db()

    # ── تشغيل حلقة الذكاء في الخلفية ─────────────────────
    asyncio.create_task(behavior_loop(bot))

    logger.info("🤖 Study Commander Bot is running!")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
