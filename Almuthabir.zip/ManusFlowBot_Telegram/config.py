# ManusFlow Bot Configuration
# ===========================

# Telegram Bot Token
import os
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
if not BOT_TOKEN:
    raise ValueError("❌ BOT_TOKEN غير موجود! أضفه كمتغير بيئة: export BOT_TOKEN='your_token_here'")

# Bot Information
BOT_NAME = "ManusFlow"
BOT_DESCRIPTION = "بوت ذكي لتحميل ومعالجة الوسائط من منصات متعددة"
BOT_USERNAME = "Almuthabirtnzbot"

# Supported Platforms
SUPPORTED_PLATFORMS = {
    "youtube": {
        "name": "YouTube",
        "emoji": "🎥",
        "patterns": [r"youtube\.com", r"youtu\.be"]
    },
    "instagram": {
        "name": "Instagram",
        "emoji": "📷",
        "patterns": [r"instagram\.com"]
    },
    "tiktok": {
        "name": "TikTok",
        "emoji": "🎵",
        "patterns": [r"tiktok\.com", r"vm\.tiktok\.com"]
    },
    "facebook": {
        "name": "Facebook",
        "emoji": "👥",
        "patterns": [r"facebook\.com", r"fb\.watch"]
    },
    "pinterest": {
        "name": "Pinterest",
        "emoji": "📌",
        "patterns": [r"pinterest\.com"]
    },
    "twitter": {
        "name": "Twitter/X",
        "emoji": "𝕏",
        "patterns": [r"twitter\.com", r"x\.com"]
    }
}

# Download Settings
DOWNLOAD_SETTINGS = {
    "max_file_size": 50 * 1024 * 1024,  # 50 MB (Telegram limit)
    "timeout": 300,  # 5 minutes
    "output_format": "best",
    "audio_format": "mp3",
    "video_format": "mp4"
}

# AI Features Settings
AI_FEATURES = {
    "enable_summarization": True,
    "enable_transcription": True,
    "enable_translation": True,
    "enable_metadata_extraction": True,
    "enable_sentiment_analysis": True
}

# Database Settings (for future use)
DATABASE = {
    "type": "sqlite",
    "path": "manusflow.db"
}

# Logging Settings
LOGGING = {
    "level": "INFO",
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    "file": "manusflow.log"
}

# User Settings
USER_SETTINGS = {
    "max_downloads_per_day": 100,
    "max_queue_size": 10,
    "auto_delete_after_hours": 24
}
