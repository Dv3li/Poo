# 🚀 دليل التثبيت الكامل - ManusFlow Bot

## 📌 ملخص سريع

هذا البوت يحتاج إلى:
1. **Python 3.11+** - لغة البرمجة
2. **المكتبات المطلوبة** - من requirements.txt
3. **توكن البوت** - من BotFather
4. **ffmpeg** (اختياري) - لمعالجة الفيديو

---

## 🎯 خطوات التثبيت الخطوة بخطوة

### 1️⃣ التحقق من Python

**على Windows:**
```bash
python --version
```

**على Mac/Linux:**
```bash
python3 --version
```

يجب أن تكون النسخة **3.11 أو أحدث**.

إذا لم يكن مثبتاً:
- تحميل: https://www.python.org/downloads/
- اختر الإصدار الأخير
- أثناء التثبيت، **تأكد من تحديد "Add Python to PATH"**

### 2️⃣ فتح Terminal/Command Prompt

**على Windows:**
- اضغط `Win + R`
- اكتب `cmd`
- اضغط Enter

**على Mac:**
- اضغط `Cmd + Space`
- اكتب `Terminal`
- اضغط Enter

**على Linux:**
- اضغط `Ctrl + Alt + T`

### 3️⃣ الانتقال إلى مجلد البوت

```bash
cd ManusFlowBot_Telegram
```

أو إذا كان في مكان آخر:
```bash
cd /path/to/ManusFlowBot_Telegram
```

### 4️⃣ إنشاء بيئة افتراضية

**على Windows:**
```bash
python -m venv venv
venv\Scripts\activate.bat
```

**على Mac/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

✅ يجب أن ترى `(venv)` في بداية السطر

### 5️⃣ تثبيت المكتبات

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

انتظر حتى ينتهي التثبيت (قد يستغرق دقائق).

### 6️⃣ الحصول على توكن البوت

1. افتح Telegram
2. ابحث عن `@BotFather`
3. اضغط `/start`
4. اضغط `/newbot`
5. اتبع التعليمات:
   - اختر اسم البوت (مثل: ManusFlow)
   - اختر username (مثل: manusflow_bot)
6. سيعطيك رسالة بالتوكن (نسخ التوكن)

### 7️⃣ إدخال التوكن

1. افتح ملف `config.py` بأي محرر نصوص
2. ابحث عن:
   ```python
   BOT_TOKEN = "8718628606:AAENcCKG1bcitAo_kI7XTpqXGQ0tItDMoU0"
   ```
3. استبدل التوكن بتوكنك:
   ```python
   BOT_TOKEN = "YOUR_TOKEN_HERE"
   ```
4. احفظ الملف (Ctrl+S)

### 8️⃣ تثبيت ffmpeg (اختياري لكن موصى به)

**على Windows:**
- حمل من: https://ffmpeg.org/download.html
- اختر "Full" build
- اتبع التعليمات

**على Mac:**
```bash
brew install ffmpeg
```

**على Ubuntu/Debian:**
```bash
sudo apt-get install ffmpeg
```

### 9️⃣ تشغيل البوت

**الطريقة الأولى (الأسهل):**

على Windows:
```bash
run.bat
```

على Mac/Linux:
```bash
./run.sh
```

**الطريقة الثانية:**
```bash
python bot.py
```

### ✅ التحقق من النجاح

إذا رأيت:
```
🚀 ManusFlow is starting...
```

فالبوت يعمل! 🎉

الآن:
1. افتح Telegram
2. ابحث عن بوتك
3. اضغط `/start`
4. أرسل رابط يوتيوب أو إنستجرام

---

## 🆘 حل المشاكل الشائعة

### ❌ خطأ: "python: command not found"

**السبب:** Python غير مثبت أو غير مضاف إلى PATH

**الحل:**
- تثبيت Python من https://www.python.org/downloads/
- **أثناء التثبيت، تأكد من تحديد "Add Python to PATH"**
- أعد تشغيل الكمبيوتر

### ❌ خطأ: "No module named 'telegram'"

**السبب:** المكتبات لم تثبت بشكل صحيح

**الحل:**
```bash
# تأكد من تفعيل البيئة الافتراضية
source venv/bin/activate  # Mac/Linux
venv\Scripts\activate.bat  # Windows

# أعد التثبيت
pip install -r requirements.txt
```

### ❌ خطأ: "Invalid token"

**السبب:** التوكن غير صحيح

**الحل:**
- تحقق من التوكن في `config.py`
- تأكد من نسخه بدون مسافات إضافية
- احصل على توكن جديد من BotFather

### ❌ خطأ: "Connection refused"

**السبب:** مشكلة في الإنترنت أو Telegram

**الحل:**
- تحقق من اتصال الإنترنت
- أعد تشغيل البوت
- جرب لاحقاً

### ❌ البوت لا يستجيب

**السبب:** البوت متوقف أو لم يبدأ

**الحل:**
- تأكد من رؤية الرسالة `🚀 ManusFlow is starting...`
- أعد تشغيل البوت
- تحقق من السجلات (manusflow.log)

---

## 📱 اختبار البوت

بعد التشغيل الناجح:

1. **افتح Telegram**
2. **ابحث عن بوتك** (اسم البوت من BotFather)
3. **اضغط "ابدأ" أو اكتب `/start`**
4. **أرسل رابط:**
   - YouTube: `https://www.youtube.com/watch?v=...`
   - Instagram: `https://www.instagram.com/p/...`
   - TikTok: `https://www.tiktok.com/@.../video/...`

5. **انتظر التحميل**
6. **احصل على الملف**

---

## 🔧 الإعدادات الأساسية

### تغيير مجلد التحميل

في `config.py`:
```python
# قبل:
downloader = MediaDownloader(output_dir="downloads")

# بعد:
downloader = MediaDownloader(output_dir="/path/to/my/folder")
```

### تفعيل الميزات الإضافية

في `config.py`:
```python
AI_FEATURES = {
    "enable_summarization": True,      # تفعيل التلخيص
    "enable_transcription": True,      # تفعيل النسخ
    "enable_translation": True,        # تفعيل الترجمة
    "enable_metadata_extraction": True, # تفعيل استخراج البيانات
    "enable_sentiment_analysis": True,  # تفعيل تحليل المشاعر
}
```

---

## 📊 مراقبة البوت

### عرض السجلات

```bash
# آخر 50 سطر
tail -50 manusflow.log

# البحث عن أخطاء
grep ERROR manusflow.log
```

### التحقق من حالة البوت

```bash
# على Linux/Mac
ps aux | grep bot.py

# على Windows
tasklist | findstr python
```

---

## 🚀 تشغيل البوت في الخلفية

### على Mac/Linux (باستخدام screen)

```bash
# بدء جلسة جديدة
screen -S manusflow

# شغل البوت
python bot.py

# اضغط Ctrl+A ثم D للخروج (البوت سيستمر في العمل)

# العودة إلى الجلسة
screen -r manusflow
```

### على Windows (باستخدام Task Scheduler)

1. افتح Task Scheduler
2. Create Basic Task
3. اسم: ManusFlow
4. Trigger: At startup
5. Action: Start a program
6. Program: `C:\path\to\venv\Scripts\python.exe`
7. Arguments: `C:\path\to\bot.py`

---

## 🔐 الأمان

### ⚠️ تحذيرات مهمة

1. **لا تشارك التوكن مع أحد**
2. **لا تضعه في GitHub أو أي مكان عام**
3. **استخدم متغيرات البيئة للإنتاج**

### استخدام متغيرات البيئة

**على Mac/Linux:**
```bash
export MANUSFLOW_TOKEN="your_token_here"
```

**على Windows:**
```bash
set MANUSFLOW_TOKEN=your_token_here
```

ثم في `config.py`:
```python
import os
BOT_TOKEN = os.getenv('MANUSFLOW_TOKEN')
```

---

## 📞 الدعم والمساعدة

إذا واجهت مشكلة:

1. **اقرأ هذا الملف** - قد تجد الحل
2. **تحقق من السجلات** - `tail -f manusflow.log`
3. **ابحث على Google** - "python-telegram-bot" + المشكلة
4. **اطلب المساعدة:**
   - 📧 البريد: support@manusflow.bot
   - 💬 Telegram: [@Almuthabirtnzbot](https://t.me/Almuthabirtnzbot)

---

## 📚 الملفات المهمة

| الملف | الوصف |
|------|-------|
| `bot.py` | البوت الرئيسي |
| `config.py` | الإعدادات والتوكن |
| `downloader.py` | تحميل الوسائط |
| `media_processor.py` | معالجة الملفات |
| `requirements.txt` | المكتبات المطلوبة |
| `README.md` | الوثائق الكاملة |
| `SETUP.md` | إعدادات متقدمة |

---

## ✨ الخطوات التالية

بعد التثبيت الناجح:

1. ✅ اختبر البوت مع روابط مختلفة
2. ✅ جرب الميزات المختلفة
3. ✅ اقرأ README.md للمزيد
4. ✅ فكر في إضافة ميزات جديدة
5. ✅ شارك البوت مع الآخرين

---

## 🎉 تم!

لقد أنهيت التثبيت بنجاح! 

الآن يمكنك:
- ✅ تحميل الفيديوهات والصور
- ✅ تحويل الصيغ
- ✅ استخراج الصور المصغرة
- ✅ إنشاء GIF
- ✅ والمزيد...

**استمتع باستخدام ManusFlow!** 🚀

---

**آخر تحديث:** مارس 2026
**الإصدار:** 1.0.0
