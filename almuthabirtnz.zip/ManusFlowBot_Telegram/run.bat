@echo off
REM ManusFlow Bot Launcher Script for Windows
REM ==========================================

echo.
echo 🚀 ManusFlow Bot Launcher
echo ========================
echo.

REM Check if virtual environment exists
if not exist "venv" (
    echo 📦 Creating virtual environment...
    python -m venv venv
)

REM Activate virtual environment
echo ✅ Activating virtual environment...
call venv\Scripts\activate.bat

REM Install/Update requirements
echo 📥 Installing requirements...
pip install -r requirements.txt -q

REM Create downloads directory if it doesn't exist
if not exist "downloads" mkdir downloads

REM Check if config is set up
findstr /M "8718628606:AAENcCKG1bcitAo_kI7XTpqXGQ0tItDMoU0" config.py >nul
if %errorlevel% equ 0 (
    echo.
    echo ⚠️  WARNING: Using default token!
    echo Please update BOT_TOKEN in config.py with your actual token
    echo.
)

REM Run the bot
echo.
echo 🤖 Starting ManusFlow Bot...
echo Press Ctrl+C to stop
echo.

python bot.py

REM Deactivate virtual environment on exit
deactivate
