"""
ManusFlow Telegram Bot
======================
Main bot implementation with user interface and commands.
"""

import logging
import os
from typing import Optional
from pathlib import Path
from datetime import datetime

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)
from telegram.constants import ChatAction

from config import BOT_TOKEN, BOT_NAME, BOT_DESCRIPTION, SUPPORTED_PLATFORMS
from downloader import MediaDownloader, PlatformDetector
from media_processor import MediaProcessor

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Initialize components
downloader = MediaDownloader(output_dir="downloads")
processor = MediaProcessor()
detector = PlatformDetector()


class ManusFlowBot:
    """Main bot class."""
    
    def __init__(self, token: str):
        """Initialize the bot."""
        self.token = token
        self.app = None
        self.user_sessions = {}  # Store user session data
    
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /start command."""
        user = update.effective_user
        
        welcome_text = f"""
👋 مرحباً بك في {BOT_NAME}! 

{BOT_DESCRIPTION}

🎯 **الميزات الرئيسية:**
✅ تحميل الفيديوهات والصور والملفات الصوتية
✅ دعم منصات متعددة (YouTube, Instagram, TikTok, Facebook, Pinterest, Twitter)
✅ معالجة ذكية للوسائط
✅ تحويل الصيغ والتنسيقات
✅ استخراج المعلومات والبيانات الوصفية

📝 **الأوامر المتاحة:**
/help - عرض المساعدة والأوامر
/download - تحميل وسائط من رابط
/info - معلومات عن الملف
/convert - تحويل الملف إلى صيغة أخرى
/settings - الإعدادات الشخصية

💡 **كيفية الاستخدام:**
1️⃣ أرسل رابط من منصة مدعومة
2️⃣ اختر الإجراء المطلوب
3️⃣ انتظر التحميل والمعالجة
4️⃣ احصل على الملف النهائي

🚀 **ابدأ الآن:** أرسل رابط أي فيديو أو صورة!
"""
        
        keyboard = [
            [
                InlineKeyboardButton("📚 المساعدة", callback_data="help"),
                InlineKeyboardButton("⚙️ الإعدادات", callback_data="settings"),
            ],
            [
                InlineKeyboardButton("📞 الدعم", callback_data="support"),
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            welcome_text,
            reply_markup=reply_markup,
            parse_mode="Markdown"
        )
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /help command."""
        help_text = """
📖 **دليل الاستخدام:**

🔗 **تحميل الوسائط:**
أرسل رابط من أي منصة مدعومة:
• YouTube: youtube.com/watch?v=...
• Instagram: instagram.com/p/...
• TikTok: tiktok.com/@.../video/...
• Facebook: facebook.com/watch/?v=...
• Pinterest: pinterest.com/pin/...
• Twitter: twitter.com/i/web/status/...

⚙️ **الأوامر:**
/start - البداية
/help - هذه الرسالة
/download [URL] - تحميل مباشر
/info [URL] - معلومات الملف
/convert [صيغة] - تحويل الصيغة
/settings - الإعدادات

💾 **الصيغ المدعومة:**
الفيديو: mp4, mkv, avi, webm
الصوت: mp3, wav, m4a, aac
الصور: jpg, png, gif, webp

🎬 **الميزات الإضافية:**
• استخراج الصور المصغرة
• إنشاء GIF من الفيديو
• معلومات تفصيلية عن الملف
• تحويل الصيغ التلقائي

❓ **الأسئلة الشائعة:**

س: ما هو الحد الأقصى لحجم الملف؟
ج: 50 MB (حد Telegram)

س: هل يمكن تحميل قوائم التشغيل؟
ج: نعم، من YouTube فقط

س: كم وقت يستغرق التحميل؟
ج: يعتمد على حجم الملف (عادة 1-5 دقائق)

📞 **الدعم:**
للمساعدة والإبلاغ عن المشاكل، استخدم /support
"""
        
        await update.message.reply_text(help_text, parse_mode="Markdown")
    
    async def handle_url(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle URL messages."""
        user_id = update.effective_user.id
        message_text = update.message.text
        
        # Check if message contains a URL
        if not any(domain in message_text for domain in ['youtube.com', 'youtu.be', 'instagram.com', 
                                                          'tiktok.com', 'facebook.com', 'pinterest.com',
                                                          'twitter.com', 'x.com', 'vm.tiktok.com', 'fb.watch']):
            return
        
        # Show processing message
        await context.bot.send_chat_action(chat_id=update.effective_chat.id, action=ChatAction.TYPING)
        
        processing_msg = await update.message.reply_text(
            "⏳ جاري معالجة الرابط...\n\n🔍 يتم التحقق من المنصة والمحتوى..."
        )
        
        try:
            # Detect platform
            platform = detector.detect_platform(message_text)
            if not platform:
                await processing_msg.edit_text(
                    "❌ المنصة غير مدعومة\n\n"
                    "المنصات المدعومة:\n"
                    "• YouTube\n"
                    "• Instagram\n"
                    "• TikTok\n"
                    "• Facebook\n"
                    "• Pinterest\n"
                    "• Twitter/X"
                )
                return
            
            platform_info = detector.get_platform_info(platform)
            emoji = platform_info.get("emoji", "📥") if platform_info else "📥"
            
            # Update processing message
            await processing_msg.edit_text(
                f"⏳ جاري التحميل من {platform_info.get('name', platform)} {emoji}...\n\n"
                "📥 يتم تحميل الملف..."
            )
            
            # Download media
            success, file_path, message = downloader.download(message_text)
            
            if not success:
                await processing_msg.edit_text(f"❌ فشل التحميل\n\n{message}")
                return
            
            # Get file info
            file_info = processor.get_file_info(file_path)
            media_type = file_info.get('file_type', 'unknown')
            
            # Prepare action buttons
            keyboard = []
            
            if media_type == 'video':
                keyboard = [
                    [
                        InlineKeyboardButton("🖼️ صورة مصغرة", callback_data=f"thumbnail_{file_path}"),
                        InlineKeyboardButton("🎬 تحويل GIF", callback_data=f"gif_{file_path}"),
                    ],
                    [
                        InlineKeyboardButton("🔊 استخراج صوت", callback_data=f"audio_{file_path}"),
                        InlineKeyboardButton("📊 معلومات", callback_data=f"info_{file_path}"),
                    ]
                ]
            elif media_type == 'audio':
                keyboard = [
                    [
                        InlineKeyboardButton("📊 معلومات", callback_data=f"info_{file_path}"),
                    ]
                ]
            elif media_type == 'image':
                keyboard = [
                    [
                        InlineKeyboardButton("📊 معلومات", callback_data=f"info_{file_path}"),
                    ]
                ]
            
            reply_markup = InlineKeyboardMarkup(keyboard) if keyboard else None
            
            # Send the file
            await processing_msg.delete()
            
            if media_type == 'video':
                await context.bot.send_video(
                    chat_id=update.effective_chat.id,
                    video=open(file_path, 'rb'),
                    caption=f"✅ {message}\n\n📝 الملف: {Path(file_path).name}",
                    reply_markup=reply_markup
                )
            elif media_type == 'audio':
                await context.bot.send_audio(
                    chat_id=update.effective_chat.id,
                    audio=open(file_path, 'rb'),
                    caption=f"✅ {message}\n\n📝 الملف: {Path(file_path).name}",
                    reply_markup=reply_markup
                )
            elif media_type == 'image':
                await context.bot.send_photo(
                    chat_id=update.effective_chat.id,
                    photo=open(file_path, 'rb'),
                    caption=f"✅ {message}\n\n📝 الملف: {Path(file_path).name}",
                    reply_markup=reply_markup
                )
            else:
                await context.bot.send_document(
                    chat_id=update.effective_chat.id,
                    document=open(file_path, 'rb'),
                    caption=f"✅ {message}\n\n📝 الملف: {Path(file_path).name}",
                    reply_markup=reply_markup
                )
            
            # Store file path for later operations
            self.user_sessions[user_id] = {'last_file': file_path}
            
        except Exception as e:
            logger.error(f"Error handling URL: {str(e)}")
            await processing_msg.edit_text(f"❌ حدث خطأ: {str(e)}")
    
    async def button_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle button callbacks."""
        query = update.callback_query
        await query.answer()
        
        data = query.data
        user_id = query.from_user.id
        
        if data == "help":
            await self.help_command(update, context)
        elif data == "settings":
            await query.edit_message_text(
                "⚙️ **الإعدادات:**\n\n"
                "🔧 الإعدادات الشخصية:\n"
                "• جودة التحميل: عالية (افتراضي)\n"
                "• صيغة الفيديو: MP4\n"
                "• صيغة الصوت: MP3\n\n"
                "💾 التخزين:\n"
                "• حد أقصى للملفات: 100 ملف يومياً\n"
                "• حجم الملف الأقصى: 50 MB\n\n"
                "🔔 الإشعارات:\n"
                "• إشعارات التحميل: مفعلة\n"
                "• إشعارات الأخطاء: مفعلة",
                parse_mode="Markdown"
            )
        elif data == "support":
            await query.edit_message_text(
                "📞 **الدعم والمساعدة:**\n\n"
                "للإبلاغ عن مشكلة أو طلب ميزة جديدة:\n"
                "📧 البريد: support@manusflow.bot\n"
                "🐛 الأخطاء: أرسل تفاصيل المشكلة\n"
                "💡 الاقتراحات: نرحب بأفكارك!\n\n"
                "⏱️ وقت الرد: عادة خلال 24 ساعة",
                parse_mode="Markdown"
            )
        elif data.startswith("thumbnail_"):
            file_path = data.replace("thumbnail_", "")
            await query.edit_message_text("⏳ جاري استخراج الصورة المصغرة...")
            success, thumb_path, msg = processor.extract_thumbnail(file_path)
            if success:
                await context.bot.send_photo(
                    chat_id=query.message.chat_id,
                    photo=open(thumb_path, 'rb'),
                    caption=msg
                )
            else:
                await query.edit_message_text(msg)
        elif data.startswith("gif_"):
            file_path = data.replace("gif_", "")
            await query.edit_message_text("⏳ جاري إنشاء GIF...")
            success, gif_path, msg = processor.create_gif_from_video(file_path, duration=5)
            if success:
                await context.bot.send_animation(
                    chat_id=query.message.chat_id,
                    animation=open(gif_path, 'rb'),
                    caption=msg
                )
            else:
                await query.edit_message_text(msg)
        elif data.startswith("info_"):
            file_path = data.replace("info_", "")
            file_info = processor.get_file_info(file_path)
            
            info_text = f"""
📊 **معلومات الملف:**

📝 الاسم: {file_info.get('filename', 'unknown')}
📁 النوع: {file_info.get('file_type', 'unknown')}
💾 الحجم: {file_info.get('file_size_mb', 0)} MB
📅 التاريخ: {file_info.get('created_at', 'unknown')}
"""
            
            if file_info.get('file_type') == 'image':
                info_text += f"📐 الأبعاد: {file_info.get('width', 0)}x{file_info.get('height', 0)}\n"
            elif file_info.get('file_type') == 'video':
                duration = file_info.get('duration_seconds', 0)
                minutes = int(duration // 60)
                seconds = int(duration % 60)
                info_text += f"⏱️ المدة: {minutes}:{seconds:02d}\n"
                info_text += f"📐 الأبعاد: {file_info.get('width', 0)}x{file_info.get('height', 0)}\n"
                info_text += f"🎬 معدل الإطارات: {file_info.get('fps', 0):.1f} fps\n"
            
            await query.edit_message_text(info_text, parse_mode="Markdown")
    
    async def setup(self) -> None:
        """Setup the bot."""
        self.app = Application.builder().token(self.token).build()
        
        # Add handlers
        self.app.add_handler(CommandHandler("start", self.start))
        self.app.add_handler(CommandHandler("help", self.help_command))
        self.app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_url))
        self.app.add_handler(CallbackQueryHandler(self.button_callback))
        
        # Set bot commands
        commands = [
            ("start", "البداية والترحيب"),
            ("help", "عرض المساعدة"),
            ("settings", "الإعدادات الشخصية"),
        ]
        await self.app.bot.set_my_commands(commands)
    
    async def run(self) -> None:
        """Run the bot."""
        await self.setup()
        logger.info(f"🚀 {BOT_NAME} is starting...")
        await self.app.run_polling()


def main():
    """Main entry point."""
    bot = ManusFlowBot(BOT_TOKEN)
    
    try:
        import asyncio
        asyncio.run(bot.run())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {str(e)}")


if __name__ == "__main__":
    main()
