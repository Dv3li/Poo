"""
ManusFlow Media Processor Module
================================
Handles media processing and AI features.
"""

import os
import logging
from typing import Optional, Dict, List, Tuple
from pathlib import Path
from PIL import Image
import subprocess
import json
from datetime import datetime

logger = logging.getLogger(__name__)

class MediaProcessor:
    """Handles media processing and transformation."""
    
    def __init__(self):
        """Initialize the media processor."""
        self.supported_formats = {
            'image': ['.jpg', '.jpeg', '.png', '.gif', '.webp'],
            'video': ['.mp4', '.mkv', '.avi', '.mov', '.webm'],
            'audio': ['.mp3', '.wav', '.m4a', '.aac', '.flac']
        }
    
    def get_media_type(self, file_path: str) -> Optional[str]:
        """
        Determine the type of media file.
        
        Args:
            file_path: Path to the media file
            
        Returns:
            Media type ('image', 'video', 'audio') or None
        """
        ext = Path(file_path).suffix.lower()
        
        for media_type, extensions in self.supported_formats.items():
            if ext in extensions:
                return media_type
        
        return None
    
    def get_file_info(self, file_path: str) -> Dict:
        """
        Get detailed information about a media file.
        
        Args:
            file_path: Path to the media file
            
        Returns:
            Dictionary with file information
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                return {'error': 'File not found'}
            
            file_size = file_path.stat().st_size
            file_size_mb = file_size / (1024 * 1024)
            
            media_type = self.get_media_type(str(file_path))
            
            info = {
                'filename': file_path.name,
                'file_type': media_type,
                'file_size_bytes': file_size,
                'file_size_mb': round(file_size_mb, 2),
                'created_at': datetime.fromtimestamp(file_path.stat().st_ctime).isoformat(),
            }
            
            # Get additional info based on media type
            if media_type == 'image':
                info.update(self._get_image_info(str(file_path)))
            elif media_type == 'video':
                info.update(self._get_video_info(str(file_path)))
            elif media_type == 'audio':
                info.update(self._get_audio_info(str(file_path)))
            
            return info
            
        except Exception as e:
            logger.error(f"Error getting file info: {str(e)}")
            return {'error': str(e)}
    
    def _get_image_info(self, file_path: str) -> Dict:
        """Get image-specific information."""
        try:
            with Image.open(file_path) as img:
                return {
                    'width': img.width,
                    'height': img.height,
                    'format': img.format,
                    'mode': img.mode,
                }
        except Exception as e:
            logger.error(f"Error getting image info: {str(e)}")
            return {}
    
    def _get_video_info(self, file_path: str) -> Dict:
        """Get video-specific information using ffprobe."""
        try:
            cmd = [
                'ffprobe', '-v', 'quiet',
                '-print_format', 'json',
                '-show_format', '-show_streams',
                file_path
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                data = json.loads(result.stdout)
                format_info = data.get('format', {})
                streams = data.get('streams', [])
                
                video_stream = next((s for s in streams if s.get('codec_type') == 'video'), {})
                audio_stream = next((s for s in streams if s.get('codec_type') == 'audio'), {})
                
                return {
                    'duration_seconds': float(format_info.get('duration', 0)),
                    'bitrate': int(format_info.get('bit_rate', 0)),
                    'video_codec': video_stream.get('codec_name', 'unknown'),
                    'audio_codec': audio_stream.get('codec_name', 'unknown'),
                    'width': video_stream.get('width', 0),
                    'height': video_stream.get('height', 0),
                    'fps': eval(video_stream.get('r_frame_rate', '0/1')),
                }
        except Exception as e:
            logger.error(f"Error getting video info: {str(e)}")
            return {}
    
    def _get_audio_info(self, file_path: str) -> Dict:
        """Get audio-specific information using ffprobe."""
        try:
            cmd = [
                'ffprobe', '-v', 'quiet',
                '-print_format', 'json',
                '-show_format', '-show_streams',
                file_path
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                data = json.loads(result.stdout)
                format_info = data.get('format', {})
                streams = data.get('streams', [])
                
                audio_stream = next((s for s in streams if s.get('codec_type') == 'audio'), {})
                
                return {
                    'duration_seconds': float(format_info.get('duration', 0)),
                    'bitrate': int(format_info.get('bit_rate', 0)),
                    'audio_codec': audio_stream.get('codec_name', 'unknown'),
                    'sample_rate': audio_stream.get('sample_rate', 0),
                    'channels': audio_stream.get('channels', 0),
                }
        except Exception as e:
            logger.error(f"Error getting audio info: {str(e)}")
            return {}
    
    def convert_format(self, input_file: str, output_format: str) -> Tuple[bool, Optional[str], str]:
        """
        Convert media to a different format.
        
        Args:
            input_file: Path to input file
            output_format: Target format (e.g., 'mp4', 'mp3', 'gif')
            
        Returns:
            Tuple of (success, output_file, message)
        """
        try:
            input_path = Path(input_file)
            if not input_path.exists():
                return False, None, "❌ الملف غير موجود"
            
            output_file = str(input_path.parent / f"{input_path.stem}_converted.{output_format}")
            
            # Use ffmpeg for conversion
            cmd = ['ffmpeg', '-i', input_file, '-y', output_file]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            
            if result.returncode == 0 and os.path.exists(output_file):
                file_size_mb = os.path.getsize(output_file) / (1024 * 1024)
                return True, output_file, f"✅ تم تحويل الملف بنجاح\n📁 الحجم: {file_size_mb:.2f} MB"
            else:
                return False, None, f"❌ فشل التحويل: {result.stderr}"
                
        except Exception as e:
            logger.error(f"Format conversion error: {str(e)}")
            return False, None, f"❌ خطأ في التحويل: {str(e)}"
    
    def extract_thumbnail(self, video_file: str) -> Tuple[bool, Optional[str], str]:
        """
        Extract thumbnail from video.
        
        Args:
            video_file: Path to video file
            
        Returns:
            Tuple of (success, thumbnail_path, message)
        """
        try:
            input_path = Path(video_file)
            if not input_path.exists():
                return False, None, "❌ الملف غير موجود"
            
            thumbnail_file = str(input_path.parent / f"{input_path.stem}_thumbnail.jpg")
            
            cmd = [
                'ffmpeg', '-i', video_file,
                '-ss', '00:00:01',
                '-vf', 'scale=320:-1',
                '-y', thumbnail_file
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0 and os.path.exists(thumbnail_file):
                return True, thumbnail_file, "✅ تم استخراج الصورة المصغرة بنجاح"
            else:
                return False, None, "❌ فشل استخراج الصورة المصغرة"
                
        except Exception as e:
            logger.error(f"Thumbnail extraction error: {str(e)}")
            return False, None, f"❌ خطأ في استخراج الصورة: {str(e)}"
    
    def create_gif_from_video(self, video_file: str, duration: int = 5) -> Tuple[bool, Optional[str], str]:
        """
        Create GIF from video.
        
        Args:
            video_file: Path to video file
            duration: Duration in seconds
            
        Returns:
            Tuple of (success, gif_path, message)
        """
        try:
            input_path = Path(video_file)
            if not input_path.exists():
                return False, None, "❌ الملف غير موجود"
            
            gif_file = str(input_path.parent / f"{input_path.stem}.gif")
            
            cmd = [
                'ffmpeg', '-i', video_file,
                '-t', str(duration),
                '-vf', 'scale=320:-1:flags=lanczos,fps=10',
                '-y', gif_file
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0 and os.path.exists(gif_file):
                file_size_mb = os.path.getsize(gif_file) / (1024 * 1024)
                return True, gif_file, f"✅ تم إنشاء GIF بنجاح\n📁 الحجم: {file_size_mb:.2f} MB"
            else:
                return False, None, "❌ فشل إنشاء GIF"
                
        except Exception as e:
            logger.error(f"GIF creation error: {str(e)}")
            return False, None, f"❌ خطأ في إنشاء GIF: {str(e)}"
