"""
ManusFlow Downloader Module
===========================
Handles downloading content from various social media platforms.
"""

import os
import re
import logging
from typing import Optional, Dict, List, Tuple
from pathlib import Path
from datetime import datetime
import yt_dlp
import requests
from bs4 import BeautifulSoup
from config import SUPPORTED_PLATFORMS, DOWNLOAD_SETTINGS

# Setup logging
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

class PlatformDetector:
    """Detects which platform a URL belongs to."""
    
    @staticmethod
    def detect_platform(url: str) -> Optional[str]:
        """
        Detect the platform from a given URL.
        
        Args:
            url: The URL to check
            
        Returns:
            Platform name or None if not supported
        """
        for platform, info in SUPPORTED_PLATFORMS.items():
            for pattern in info["patterns"]:
                if re.search(pattern, url):
                    return platform
        return None
    
    @staticmethod
    def get_platform_info(platform: str) -> Optional[Dict]:
        """Get platform information."""
        return SUPPORTED_PLATFORMS.get(platform)


class MediaDownloader:
    """Main downloader class for handling media downloads."""
    
    def __init__(self, output_dir: str = "downloads"):
        """
        Initialize the downloader.
        
        Args:
            output_dir: Directory to save downloaded files
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        self.detector = PlatformDetector()
        
    def download(self, url: str) -> Tuple[bool, Optional[str], str]:
        """
        Download media from the given URL.
        
        Args:
            url: The media URL
            
        Returns:
            Tuple of (success, file_path, message)
        """
        try:
            # Detect platform
            platform = self.detector.detect_platform(url)
            if not platform:
                return False, None, "❌ المنصة غير مدعومة. المنصات المدعومة: YouTube, Instagram, TikTok, Facebook, Pinterest, Twitter"
            
            platform_info = self.detector.get_platform_info(platform)
            logger.info(f"Detected platform: {platform}")
            
            # Download based on platform
            if platform in ["youtube", "tiktok", "instagram", "facebook", "twitter"]:
                return self._download_with_ytdlp(url, platform)
            elif platform == "pinterest":
                return self._download_pinterest(url)
            else:
                return False, None, "❌ لم يتمكن من تحميل المحتوى من هذه المنصة"
                
        except Exception as e:
            logger.error(f"Download error: {str(e)}")
            return False, None, f"❌ حدث خطأ أثناء التحميل: {str(e)}"
    
    def _download_with_ytdlp(self, url: str, platform: str) -> Tuple[bool, Optional[str], str]:
        """
        Download using yt-dlp (works for most platforms).
        
        Args:
            url: The media URL
            platform: The platform name
            
        Returns:
            Tuple of (success, file_path, message)
        """
        try:
            # Prepare output template
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_template = str(self.output_dir / f"{platform}_{timestamp}_%(title)s.%(ext)s")
            
            # Configure yt-dlp options
            ydl_opts = {
                'format': 'best',
                'outtmpl': output_template,
                'quiet': False,
                'no_warnings': False,
                'socket_timeout': 30,
                'max_downloads': 1,
                'no_color': True,
            }
            
            # Platform-specific options
            if platform == "instagram":
                ydl_opts['format'] = 'best[ext=mp4]/best'
            elif platform == "tiktok":
                ydl_opts['format'] = 'best'
            elif platform == "youtube":
                ydl_opts['format'] = 'best[ext=mp4]/best'
            
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                logger.info(f"Starting download from {platform}: {url}")
                info = ydl.extract_info(url, download=True)
                filename = ydl.prepare_filename(info)
                
                if os.path.exists(filename):
                    file_size = os.path.getsize(filename)
                    file_size_mb = file_size / (1024 * 1024)
                    
                    logger.info(f"Download completed: {filename} ({file_size_mb:.2f} MB)")
                    
                    platform_info = self.detector.get_platform_info(platform)
                    emoji = platform_info.get("emoji", "📥") if platform_info else "📥"
                    
                    return True, filename, f"✅ تم التحميل بنجاح {emoji}\n📁 الحجم: {file_size_mb:.2f} MB"
                else:
                    return False, None, "❌ فشل التحميل: لم يتم إنشاء الملف"
                    
        except Exception as e:
            logger.error(f"yt-dlp download error: {str(e)}")
            return False, None, f"❌ خطأ في التحميل: {str(e)}"
    
    def _download_pinterest(self, url: str) -> Tuple[bool, Optional[str], str]:
        """
        Download from Pinterest.
        
        Args:
            url: The Pinterest URL
            
        Returns:
            Tuple of (success, file_path, message)
        """
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Try to find image or video URL
            img_tags = soup.find_all('img')
            for img in img_tags:
                src = img.get('src', '')
                if 'pinimg.com' in src:
                    return self._download_image(src, "pinterest")
            
            return False, None, "❌ لم يتمكن من العثور على الوسائط في رابط Pinterest"
            
        except Exception as e:
            logger.error(f"Pinterest download error: {str(e)}")
            return False, None, f"❌ خطأ في تحميل Pinterest: {str(e)}"
    
    def _download_image(self, image_url: str, platform: str) -> Tuple[bool, Optional[str], str]:
        """
        Download an image from URL.
        
        Args:
            image_url: The image URL
            platform: The platform name
            
        Returns:
            Tuple of (success, file_path, message)
        """
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            
            response = requests.get(image_url, headers=headers, timeout=10)
            response.raise_for_status()
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = str(self.output_dir / f"{platform}_{timestamp}.jpg")
            
            with open(filename, 'wb') as f:
                f.write(response.content)
            
            file_size = os.path.getsize(filename)
            file_size_mb = file_size / (1024 * 1024)
            
            return True, filename, f"✅ تم تحميل الصورة بنجاح 📷\n📁 الحجم: {file_size_mb:.2f} MB"
            
        except Exception as e:
            logger.error(f"Image download error: {str(e)}")
            return False, None, f"❌ خطأ في تحميل الصورة: {str(e)}"
    
    def get_media_info(self, url: str) -> Optional[Dict]:
        """
        Get information about the media without downloading.
        
        Args:
            url: The media URL
            
        Returns:
            Dictionary with media information or None
        """
        try:
            ydl_opts = {
                'quiet': True,
                'no_warnings': True,
                'socket_timeout': 10,
            }
            
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                return {
                    'title': info.get('title', 'Unknown'),
                    'duration': info.get('duration', 0),
                    'uploader': info.get('uploader', 'Unknown'),
                    'upload_date': info.get('upload_date', 'Unknown'),
                    'description': info.get('description', ''),
                }
        except Exception as e:
            logger.error(f"Error getting media info: {str(e)}")
            return None
