# دليل الإعداد والتثبيت - ManusFlow Bot

## 📋 المتطلبات الأساسية

قبل البدء، تأكد من توفر:

- **Python 3.11 أو أحدث**
  - تحقق: `python3 --version`
  - تحميل: https://www.python.org/downloads/

- **pip (مدير الحزم)**
  - يأتي مع Python عادة
  - تحقق: `pip --version`

- **ffmpeg (اختياري لكن موصى به)**
  - مطلوب لمعالجة الفيديو والصوت
  - تحميل: https://ffmpeg.org/download.html

- **توكن بوت تيليجرام**
  - تواصل مع [@BotFather](https://t.me/botfather)

## 🔧 خطوات التثبيت

### الخطوة 1: تحضير المشروع

```bash
# انتقل إلى مجلد المشروع
cd ManusFlowBot_Telegram

# تأكد من وجود جميع الملفات
ls -la
```

يجب أن ترى:
- `bot.py` - البوت الرئيسي
- `config.py` - الإعدادات
- `downloader.py` - وحدة التحميل
- `media_processor.py` - معالجة الوسائط
- `requirements.txt` - المكتبات المطلوبة
- `README.md` - الوثائق

### الخطوة 2: إنشاء بيئة افتراضية

**على Linux/Mac:**
```bash
python3 -m venv venv
source venv/bin/activate
```

**على Windows:**
```bash
python -m venv venv
venv\Scripts\activate.bat
```

يجب أن ترى `(venv)` في بداية السطر الموجه.

### الخطوة 3: تثبيت المكتبات

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

سيتم تثبيت:
- `python-telegram-bot` - مكتبة Telegram
- `yt-dlp` - تحميل من YouTube ومنصات أخرى
- `requests` - طلبات HTTP
- `beautifulsoup4` - تحليل HTML
- `pillow` - معالجة الصور

### الخطوة 4: تثبيت ffmpeg

**على Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install ffmpeg
```

**على CentOS/RHEL:**
```bash
sudo yum install ffmpeg
```

**على macOS:**
```bash
brew install ffmpeg
```

**على Windows:**
```bash
choco install ffmpeg
```

أو حمل من: https://ffmpeg.org/download.html

### الخطوة 5: إعداد التوكن

1. افتح ملف `config.py`
2. ابحث عن السطر:
   ```python
   BOT_TOKEN = "8718628606:AAENcCKG1bcitAo_kI7XTpqXGQ0tItDMoU0"
   ```
3. استبدل التوكن بتوكنك الفعلي من BotFather

### الخطوة 6: التشغيل

**الطريقة 1: استخدام السكريبت (موصى به)**

على Linux/Mac:
```bash
chmod +x run.sh
./run.sh
```

على Windows:
```bash
run.bat
```

**الطريقة 2: التشغيل المباشر**

```bash
# تأكد من تفعيل البيئة الافتراضية
source venv/bin/activate  # Linux/Mac
# أو
venv\Scripts\activate.bat  # Windows

# شغل البوت
python3 bot.py
```

## ✅ التحقق من التثبيت

إذا رأيت الرسالة التالية، فالتثبيت نجح:

```
🚀 ManusFlow is starting...
```

الآن يمكنك:
1. فتح تيليجرام
2. البحث عن بوتك (اسم البوت من BotFather)
3. الضغط على "ابدأ" أو `/start`

## 🐛 استكشاف الأخطاء

### خطأ: "ModuleNotFoundError: No module named 'telegram'"

**الحل:**
```bash
# تأكد من تفعيل البيئة الافتراضية
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate.bat  # Windows

# أعد تثبيت المكتبات
pip install -r requirements.txt
```

### خطأ: "python: command not found"

**الحل:**
- استخدم `python3` بدلاً من `python`
- تأكد من تثبيت Python: `python3 --version`

### خطأ: "ffmpeg: command not found"

**الحل:**
- تثبيت ffmpeg (انظر الخطوة 4 أعلاه)
- أو استخدم البوت بدون معالجة متقدمة (التحميل الأساسي سيعمل)

### خطأ: "Connection refused" أو "Network error"

**الحل:**
- تحقق من اتصال الإنترنت
- تأكد من صحة التوكن
- حاول لاحقاً (قد يكون هناك مشكلة في Telegram)

### خطأ: "Invalid token"

**الحل:**
- تحقق من التوكن في `config.py`
- تأكد من نسخه بشكل صحيح من BotFather
- لا توجد مسافات إضافية

## 📝 الإعدادات المتقدمة

### تغيير مجلد التحميل

في `config.py`:
```python
# غير المسار
downloader = MediaDownloader(output_dir="/path/to/downloads")
```

### تغيير حد أقصى لحجم الملف

في `config.py`:
```python
DOWNLOAD_SETTINGS = {
    "max_file_size": 100 * 1024 * 1024,  # 100 MB بدلاً من 50 MB
    ...
}
```

### تفعيل الوضع الهادئ (بدون سجلات)

في `bot.py`:
```python
logging.basicConfig(level=logging.WARNING)  # بدلاً من INFO
```

## 🚀 التشغيل في الخلفية

### على Linux/Mac (استخدام nohup)

```bash
nohup python3 bot.py > manusflow.log 2>&1 &
```

### على Linux (استخدام systemd)

1. أنشئ ملف `/etc/systemd/system/manusflow.service`:
```ini
[Unit]
Description=ManusFlow Telegram Bot
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/ManusFlowBot_Telegram
ExecStart=/home/ubuntu/ManusFlowBot_Telegram/venv/bin/python3 bot.py
Restart=always

[Install]
WantedBy=multi-user.target
```

2. فعّل الخدمة:
```bash
sudo systemctl enable manusflow
sudo systemctl start manusflow
```

### على Windows (استخدام Task Scheduler)

1. افتح Task Scheduler
2. أنشئ مهمة جديدة
3. اضبط البرنامج: `C:\path\to\venv\Scripts\python.exe`
4. اضبط الحجج: `C:\path\to\bot.py`

## 📊 مراقبة البوت

### عرض السجلات

```bash
# السجلات الأخيرة
tail -f manusflow.log

# البحث عن أخطاء
grep ERROR manusflow.log

# عدد الأخطاء
grep ERROR manusflow.log | wc -l
```

### التحقق من حالة البوت

```bash
# على Linux
ps aux | grep bot.py

# على macOS
pgrep -f bot.py
```

## 🔐 الأمان

### حماية التوكن

1. **لا تشارك التوكن مع أحد**
2. **لا تضعه في GitHub** (استخدم `.env` بدلاً من ذلك)
3. **استخدم متغيرات البيئة:**

```python
# في config.py
import os
BOT_TOKEN = os.getenv('MANUSFLOW_TOKEN', 'default_token')
```

ثم عيّن المتغير:
```bash
export MANUSFLOW_TOKEN="your_token_here"
```

## 🆘 الحصول على المساعدة

إذا واجهت مشكلة:

1. **تحقق من السجلات:**
   ```bash
   tail -50 manusflow.log
   ```

2. **اقرأ الوثائق:**
   - README.md - نظرة عامة
   - هذا الملف - التثبيت
   - كود البوت - التفاصيل

3. **ابحث عن الحل:**
   - Google: "python-telegram-bot" + المشكلة
   - Stack Overflow: أسئلة مشابهة

4. **اطلب المساعدة:**
   - 📧 البريد: support@manusflow.bot
   - 💬 Telegram: [@ManusFlowSupport](https://t.me/ManusFlowSupport)

## 📈 الخطوات التالية

بعد التثبيت الناجح:

1. ✅ اختبر البوت مع روابط مختلفة
2. ✅ جرب الميزات المختلفة
3. ✅ اقرأ README.md للمزيد من المعلومات
4. ✅ فكر في إضافة ميزات جديدة

## 📞 التواصل

- 🌐 الموقع: https://manusflow.bot
- 📧 البريد: support@manusflow.bot
- 💬 Telegram: [@Almuthabirtnzbot](https://t.me/Almuthabirtnzbot)

---

**تم آخر تحديث:** مارس 2026
**الإصدار:** 1.0.0
