#!/bin/bash

# ManusFlow Bot Launcher Script
# =============================

echo "🚀 ManusFlow Bot Launcher"
echo "========================"
echo ""

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "✅ Activating virtual environment..."
source venv/bin/activate

# Install/Update requirements
echo "📥 Installing requirements..."
pip install -r requirements.txt -q

# Create downloads directory if it doesn't exist
mkdir -p downloads

# Check if config is set up
if grep -q "8718628606:AAENcCKG1bcitAo_kI7XTpqXGQ0tItDMoU0" config.py; then
    echo ""
    echo "⚠️  WARNING: Using default token!"
    echo "Please update BOT_TOKEN in config.py with your actual token"
    echo ""
fi

# Run the bot
echo ""
echo "🤖 Starting ManusFlow Bot..."
echo "Press Ctrl+C to stop"
echo ""

python3 bot.py

# Deactivate virtual environment on exit
deactivate
