"""
seed_exam_math_f1.py
يُشغَّل مرة واحدة فقط لإضافة امتحان الرياضيات فصل أول للداتابيس.

طريقة التشغيل:
    python3 seed_exam_math_f1.py
"""

import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from data.database import init_db, add_exam

# ── مسار مجلد الصور على السيرفر ──────────────────────────────────────────
# بعد ما ترفع مجلد الصور للسيرفر، عدّل هذا المسار إذا كان مختلفاً
IMAGES_DIR = os.path.join(os.path.dirname(__file__), "exam_images", "math_final_1")

def make_path(filename):
    return os.path.join(IMAGES_DIR, filename)

# ── الصفحة 1 فقط = الأسئلة ───────────────────────────────────────────────
question_imgs = [
    make_path("page_01.jpg"),
]

# ── الصفحات 2-17 = الأجوبة ───────────────────────────────────────────────
answer_imgs = [make_path(f"page_{i:02d}.jpg") for i in range(2, 18)]

def main():
    # تحقق من وجود الصور
    missing = [p for p in question_imgs + answer_imgs if not os.path.exists(p)]
    if missing:
        print("❌ ملفات مفقودة:")
        for m in missing:
            print(f"   {m}")
        print("\nتأكد إن مجلد exam_images/math_final_1 موجود بجانب هذا السكريبت.")
        sys.exit(1)

    init_db()
    exam_id = add_exam(
        subject_key  = "math",
        label        = "رياضيات — فصل أول (أعداد مركبة)",
        question_imgs = question_imgs,
        answer_imgs  = answer_imgs,
    )
    print(f"✅ تم إضافة الامتحان بنجاح — ID: {exam_id}")
    print(f"   📋 أسئلة: {len(question_imgs)} صورة")
    print(f"   ✅ أجوبة: {len(answer_imgs)} صورة")

if __name__ == "__main__":
    main()
