"""
بوت أثر — main.py
"""

import logging
import asyncio
from telegram.ext import Application, CommandHandler, MessageHandler, filters, PollAnswerHandler, CallbackQueryHandler
from telegram import ReplyKeyboardRemove

from config import BOT_TOKEN
from handlers.commands import (
    cmd_start, cmd_points, cmd_leaderboard, cmd_done,
    cmd_history, cmd_question, cmd_challenge, cmd_review,
    cmd_help, cmd_settings, cmd_exams, handle_exam_callback,
    handle_main_callbacks,
    cmd_admin_add_question, cmd_admin_add_challenge,
    cmd_admin_add_review, cmd_admin_add_riddle,
    cmd_admin_reset_week, cmd_admin_announce,
    cmd_admin_give_points, cmd_admin_list_groups,
    cmd_admin_add_exam,
)
from handlers.answers import handle_message
from handlers.poll    import handle_poll_answer
from scheduler.jobs   import setup_scheduler
from data.database    import init_db

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
    handlers=[
        logging.FileHandler("athar.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger(__name__)


async def post_init(application: Application):
    logger.info("✅ بوت أثر شغال!")
    init_db()
    setup_scheduler(application)


def main():
    if not BOT_TOKEN:
        raise ValueError("❌ BOT_TOKEN فارغ! تأكد من ملف .env")

    app = Application.builder().token(BOT_TOKEN).post_init(post_init).build()

    # أوامر الطلاب
    app.add_handler(CommandHandler("start",     cmd_start))
    app.add_handler(CommandHandler("points",    cmd_points))
    app.add_handler(CommandHandler("board",     cmd_leaderboard))
    app.add_handler(CommandHandler("done",      cmd_done))
    app.add_handler(CommandHandler("history",   cmd_history))
    app.add_handler(CommandHandler("question",  cmd_question))
    app.add_handler(CommandHandler("challenge", cmd_challenge))
    app.add_handler(CommandHandler("review",    cmd_review))
    app.add_handler(CommandHandler("help",      cmd_help))
    app.add_handler(CommandHandler("settings",  cmd_settings))
    app.add_handler(CommandHandler("exams",     cmd_exams))

    # معالج الأزرار التفاعلية (Callback Queries)
    app.add_handler(CallbackQueryHandler(handle_main_callbacks, pattern="^main_"))
    app.add_handler(CallbackQueryHandler(handle_exam_callback, pattern="^ex_"))

    # أوامر الأدمن
    app.add_handler(CommandHandler("add_q",       cmd_admin_add_question))
    app.add_handler(CommandHandler("add_c",       cmd_admin_add_challenge))
    app.add_handler(CommandHandler("add_r",       cmd_admin_add_review))
    app.add_handler(CommandHandler("add_l",       cmd_admin_add_riddle))
    app.add_handler(CommandHandler("reset_week",  cmd_admin_reset_week))
    app.add_handler(CommandHandler("announce",    cmd_admin_announce))
    app.add_handler(CommandHandler("give_points", cmd_admin_give_points))
    app.add_handler(CommandHandler("list_groups", cmd_admin_list_groups))
    app.add_handler(CommandHandler("add_exam",    cmd_admin_add_exam))

    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.add_handler(PollAnswerHandler(handle_poll_answer))

    logger.info("🚀 بدء التشغيل...")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
