"""
handlers/answers.py — معالج الإجابات في الجروب
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from config import POINTS
from data import database as db
from handlers.commands import check_subscription, CHANNEL_URL

logger = logging.getLogger(__name__)


def _normalize(text: str) -> str:
    """توحيد النص للمقارنة"""
    import re
    text = text.strip().lower()
    text = re.sub(r'[\u064B-\u065F]', '', text)   # إزالة التشكيل
    text = re.sub(r'[أإآا]', 'ا', text)            # توحيد الألف
    text = text.replace('ى', 'ي').replace('ة', 'ه')
    return text


async def handle_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    msg  = update.message
    user = update.effective_user

    if not msg or not msg.text:
        return

    # التحقق من الاشتراك الإجباري في الخاص
    if msg.chat.type == "private":
        is_subscribed = await check_subscription(user.id, ctx.bot)
        if not is_subscribed:
            keyboard = [[InlineKeyboardButton("اشترك في القناة 📢", url=CHANNEL_URL)]]
            await msg.reply_text(
                "عليك الاشتراك في القناة ثم اضغط /start",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        return

    # فقط في الجروبات المسجّلة
    if msg.chat.type not in ["group", "supergroup"]:
        return

    registered_groups = [g["group_id"] for g in db.get_all_groups()]
    if msg.chat.id not in registered_groups:
        return

    db.upsert_student(user.id, user.username, user.full_name)

    text = msg.text.strip()

    # ── تحقق من إجابة السؤال اليومي ──────────────────────────
    q = db.get_active_question()
    if q:
        correct_answer = _normalize(q["answer"])
        user_answer    = _normalize(text)

        if user_answer == correct_answer:
            # سجّل الإجابة — إذا رجع False يعني جاوب قبل
            recorded = db.record_question_answer(q["id"], user.id, True)
            if not recorded:
                return  # جاوب قبل، تجاهل

            correct_count = db.count_correct_answers(q["id"])

            if correct_count == 1:
                db.set_question_winner(q["id"], user.id, 1)
                db.add_points(user.id, POINTS["question_first"], "أول إجابة صحيحة")
                await msg.reply_text(
                    f"🎯 إجابة صحيحة يا {user.first_name}!\n"
                    f"🥇 أنت الأول! +{POINTS['question_first']} نقطة 🎉"
                )
            elif correct_count == 2:
                db.set_question_winner(q["id"], user.id, 2)
                db.add_points(user.id, POINTS["question_second"], "ثاني إجابة صحيحة")
                await msg.reply_text(
                    f"✅ إجابة صحيحة يا {user.first_name}!\n"
                    f"🥈 أنت الثاني! +{POINTS['question_second']} نقاط"
                )
            else:
                await msg.reply_text(f"✅ إجابة صحيحة يا {user.first_name}! (بدون نقاط إضافية)")

        else:
            # إجابة خاطئة — سجّلها مرة وحدة
            db.record_question_answer(q["id"], user.id, False)
