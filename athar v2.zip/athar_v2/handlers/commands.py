"""
handlers/commands.py — معالج الأوامر مع دعم الأزرار التفاعلية والتعديل المباشر
"""

import logging
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import ContextTypes
from telegram.error import BadRequest, Forbidden

from config import ADMIN_IDS, POINTS, CHANNEL_URL, CHANNEL_ID, DEVELOPER_CHAT
from data import database as db

logger = logging.getLogger(__name__)


def _is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


def _name(user) -> str:
    return user.full_name or user.username or str(user.id)


async def check_subscription(user_id: int, bot) -> bool:
    try:
        member = await bot.get_chat_member(chat_id=CHANNEL_ID, user_id=user_id)
        return member.status in ["member", "administrator", "creator"]
    except Exception:
        return True


# لوحة المفاتيح الرئيسية (Reply Keyboard) - للوصول السريع
# أزرار التحكم الرئيسية (Inline Keyboard) للتنقل المباشر
def get_main_inline_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🧠 سؤال اليوم", callback_data="main_question"),
            InlineKeyboardButton("✅ تحدي اليوم", callback_data="main_challenge")
        ],
        [
            InlineKeyboardButton("📝 الامتحانات", callback_data="main_exams"),
            InlineKeyboardButton("📚 مراجعة", callback_data="main_review")
        ],
        [
            InlineKeyboardButton("📊 نقاطي", callback_data="main_points"),
            InlineKeyboardButton("🏆 المتصدرين", callback_data="main_board")
        ],
        [
            InlineKeyboardButton("📖 المساعدة", callback_data="main_help"),
            InlineKeyboardButton("⚙️ الإعدادات", callback_data="main_settings")
        ]
    ])


# ═══════════════════════════════════════════════════════
#                   أوامر الطلاب
# ═══════════════════════════════════════════════════════

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u    = update.effective_user
    chat = update.effective_chat

    if chat.type in ["group", "supergroup"]:
        db.register_group(chat.id, chat.title)
        await update.message.reply_text(
            f"✅ تم تفعيل بوت أثر في *{chat.title}*!\n\n"
            "سيبدأ البوت إرسال:\n"
            "📚 دقيقة مراجعة — ٨ صباحاً\n"
            "🧠 سؤال يومي — ١٠ صباحاً\n"
            "✅ تحدي اليوم — ٢ ظهراً\n"
            "🧩 لغز التفكير — ٦ مساءً\n\n"
            "اكتب /help لقائمة الأوامر",
            parse_mode="Markdown"
        )
        return

    if chat.type == "private":
        is_subscribed = await check_subscription(u.id, ctx.bot)
        if not is_subscribed:
            keyboard = [[InlineKeyboardButton("اشترك في القناة 📢", url=CHANNEL_URL)]]
            await update.message.reply_text(
                "عليك الاشتراك في القناة ثم اضغط /start",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            return

    db.upsert_student(u.id, u.username, u.full_name)
    # إزالة أي Reply Keyboard قديم
    await update.message.reply_text("​", reply_markup=ReplyKeyboardRemove())
    await update.message.reply_text(
        f"أهلاً {u.first_name}! 👋\n\n"
        "🎓 *بوت أثر التعليمي*\n\n"
        "اختر من القائمة أدناه للتنقل السريع:",
        reply_markup=get_main_inline_keyboard()
    )


async def handle_main_callbacks(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """معالجة ضغطات أزرار القائمة الرئيسية للتنقل المباشر"""
    query = update.callback_query
    data = query.data
    u = update.effective_user
    
    await query.answer()

    if data == "main_points":
        student = db.get_student(u.id)
        if not student:
            text = "ما وجدت بياناتك، جرّب /start أول."
        else:
            streak_text = f"\n🔥 سلسلة: {student['streak']} يوم" if student['streak'] > 1 else ""
            text = (f"📊 نقاطك يا {u.first_name}\n\n"
                    f"⭐ المجموع: {student['points']} نقطة"
                    f"{streak_text}")
        await query.edit_message_text(text, reply_markup=get_main_inline_keyboard())

    elif data == "main_board":
        board = db.get_leaderboard(10)
        if not board:
            text = "ما في نقاط بعد!"
        else:
            medals = ["🥇", "🥈", "🥉"]
            lines  = ["🏆 لوحة المتصدرين\n"]
            for i, row in enumerate(board):
                medal = medals[i] if i < 3 else f"{i+1}."
                name  = row["full_name"] or row["username"] or "—"
                lines.append(f"{medal} {name} — {row['points']} نقطة")
            text = "\n".join(lines)
        await query.edit_message_text(text, reply_markup=get_main_inline_keyboard())

    elif data == "main_challenge":
        c = db.get_active_challenge()
        if not c:
            text = "❌ ما في تحدٍّ نشط الآن، انتظر الساعة ٢ ظهراً."
        else:
            closes = datetime.fromisoformat(c["closes_at"]).strftime("%H:%M")
            count  = db.get_challenge_completions_count(c["id"])
            text = (f"✅ تحدي اليوم\n\n📌 {c['challenge']}\n\n"
                    f"⏰ يغلق الساعة {closes}\n"
                    f"👥 أنجزه {count} طالب حتى الآن\n\n"
                    "اكتب /done بعد ما تخلص!")
        await query.edit_message_text(text, reply_markup=get_main_inline_keyboard())

    elif data == "main_question":
        q = db.get_active_question()
        if not q:
            text = "❌ ما في سؤال نشط الآن، انتظر سؤال الساعة ١٠ صباحاً."
        else:
            subject = f"[{q['subject']}] " if q['subject'] else ""
            text = f"🧠 السؤال اليومي {subject}\n\n{q['question']}\n\nاكتب إجابتك!"
        await query.edit_message_text(text, reply_markup=get_main_inline_keyboard())

    elif data == "main_review":
        r = db.get_last_review()
        if not r:
            text = "❌ ما في مراجعة بعد."
        else:
            subject = f"[{r['subject']}] " if r['subject'] else ""
            text = f"📚 دقيقة مراجعة {subject}\n\n{r['content']}"
        await query.edit_message_text(text, reply_markup=get_main_inline_keyboard())

    elif data == "main_settings":
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("قناة البوت 📢", url=CHANNEL_URL)],
            [InlineKeyboardButton("مطور البوت 👨‍💻", url=f"https://t.me/{DEVELOPER_CHAT.replace('@', '.')}")] ,
            [InlineKeyboardButton("↩️ رجوع", callback_data="main_home")]
        ])
        await query.edit_message_text("⚙️ إعدادات البوت:", reply_markup=keyboard)

    elif data == "main_help":
        text = (
            "📖 قائمة الأوامر\n\n"
            "👤 للطلاب:\n"
            "/points — رصيدك الحالي\n"
            "/board — لوحة المتصدرين\n"
            "/done — تسجيل إنجاز التحدي\n"
            "/history — تاريخ نشاطك\n"
            "/question — السؤال اليومي\n"
            "/challenge — تحدي اليوم\n"
            "/review — آخر معلومة\n"
            "/exams — قسم الامتحانات 📝\n\n"
            "🏆 النقاط:\n"
            "• أول إجابة صحيحة = 10 نقاط\n"
            "• ثاني إجابة صحيحة = 5 نقاط\n"
            "• إنجاز تحدي اليوم = 3 نقاط\n"
            "• أفضل تفسير للغز = 8 نقاط\n"
            "• بونص 5 أيام متتالية = 15 نقطة"
        )
        await query.edit_message_text(text, reply_markup=get_main_inline_keyboard())

    elif data == "main_home":
        await query.edit_message_text(
            f"أهلاً {u.first_name}! 👋\n\n"
            "🎓 *بوت أثر التعليمي*\n\n"
            "اختر من القائمة أدناه للتنقل السريع:",
            reply_markup=get_main_inline_keyboard()
        )
    
    elif data == "main_exams":
        await cmd_exams(update, ctx)


# الأوامر النصية العادية (للتوافق)
async def cmd_points(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    student = db.get_student(u.id)
    if not student:
        await update.message.reply_text("ما وجدت بياناتك، جرّب /start أول.")
        return
    streak_text = f"🔥 سلسلة: {student['streak']} يوم" if student['streak'] > 1 else ""
    await update.message.reply_text(
        f"📊 نقاطك يا {u.first_name}\n\n"
        f"⭐ المجموع: {student['points']} نقطة\n"
        f"{streak_text}",
        reply_markup=get_main_inline_keyboard()
    )

async def cmd_leaderboard(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    board = db.get_leaderboard(10)
    if not board:
        await update.message.reply_text("ما في نقاط بعد!")
        return
    medals = ["🥇", "🥈", "🥉"]
    lines  = ["🏆 لوحة المتصدرين\n"]
    for i, row in enumerate(board):
        medal = medals[i] if i < 3 else f"{i+1}."
        name  = row["full_name"] or row["username"] or "—"
        lines.append(f"{medal} {name} — {row['points']} نقطة")
    await update.message.reply_text("\n".join(lines), reply_markup=get_main_inline_keyboard())

async def cmd_done(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    challenge = db.get_active_challenge()
    if not challenge:
        await update.message.reply_text("❌ ما في تحدٍّ مفتوح الآن.")
        return
    closes_at = datetime.fromisoformat(challenge["closes_at"])
    if datetime.now() > closes_at:
        await update.message.reply_text("⏰ انتهى وقت التحدي.")
        return
    registered = db.register_challenge_completion(challenge["id"], u.id)
    if not registered:
        await update.message.reply_text("✅ أنت مسجّل مسبقاً في هذا التحدي!")
        return
    db.add_points(u.id, POINTS["challenge_done"], "إنجاز تحدي اليوم")
    streak = db.update_streak(u.id)
    streak_msg = ""
    if streak >= POINTS.get("streak_days_required", 5):
        db.add_points(u.id, POINTS["streak_bonus"], f"بونص {streak} أيام متتالية")
        streak_msg = f"\n🎉 حصلت على بونص {POINTS['streak_bonus']} نقطة!"
    count = db.get_challenge_completions_count(challenge["id"])
    await update.message.reply_text(
        f"✅ تم تسجيل إنجازك يا {u.first_name}!\n"
        f"💫 +{POINTS['challenge_done']} نقاط\n"
        f"🔥 سلسلتك: {streak} يوم\n"
        f"👥 أنجز التحدي: {count} طالب"
        + streak_msg
    )

async def cmd_history(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    history = db.get_points_history(u.id, 10)
    if not history:
        await update.message.reply_text("ما في سجل نشاط بعد.")
        return
    lines = [f"📋 آخر نشاطاتك يا {u.first_name}\n"]
    for row in history:
        sign = "+" if row["amount"] > 0 else ""
        dt   = row["created_at"][:10]
        lines.append(f"• {row['reason']} — {sign}{row['amount']} نقطة ({dt})")
    await update.message.reply_text("\n".join(lines))

async def cmd_question(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = db.get_active_question()
    if not q:
        await update.message.reply_text("❌ ما في سؤال نشط الآن، انتظر سؤال الساعة ١٠ صباحاً.")
        return
    subject = f"[{q['subject']}] " if q['subject'] else ""
    await update.message.reply_text(
        f"🧠 السؤال اليومي {subject}\n\n{q['question']}\n\nاكتب إجابتك!"
    )

async def cmd_challenge(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    c = db.get_active_challenge()
    if not c:
        await update.message.reply_text("❌ ما في تحدٍّ نشط الآن، انتظر الساعة ٢ ظهراً.")
        return
    closes = datetime.fromisoformat(c["closes_at"]).strftime("%H:%M")
    count  = db.get_challenge_completions_count(c["id"])
    await update.message.reply_text(
        f"✅ تحدي اليوم\n\n📌 {c['challenge']}\n\n"
        f"⏰ يغلق الساعة {closes}\n"
        f"👥 أنجزه {count} طالب حتى الآن\n\n"
        "اكتب /done بعد ما تخلص!"
    )

async def cmd_review(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    r = db.get_last_review()
    if not r:
        await update.message.reply_text("❌ ما في مراجعة بعد.")
        return
    subject = f"[{r['subject']}] " if r['subject'] else ""
    await update.message.reply_text(f"📚 دقيقة مراجعة {subject}\n\n{r['content']}")

async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📖 قائمة الأوامر\n\n"
        "👤 للطلاب:\n"
        "/points — رصيدك الحالي\n"
        "/board — لوحة المتصدرين\n"
        "/done — تسجيل إنجاز التحدي\n"
        "/history — تاريخ نشاطك\n"
        "/question — السؤال اليومي\n"
        "/challenge — تحدي اليوم\n"
        "/review — آخر معلومة\n"
        "/exams — قسم الامتحانات 📝\n\n"
        "🏆 النقاط:\n"
        "• أول إجابة صحيحة = 10 نقاط\n"
        "• ثاني إجابة صحيحة = 5 نقاط\n"
        "• إنجاز تحدي اليوم = 3 نقاط\n"
        "• أفضل تفسير للغز = 8 نقاط\n"
        "• بونص 5 أيام متتالية = 15 نقطة"
    )

async def cmd_settings(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("قناة البوت 📢", url=CHANNEL_URL)],
        [InlineKeyboardButton("مطور البوت 👨‍💻", url=f"https://t.me/{DEVELOPER_CHAT.replace('@', '.')}")]
    ]
    await update.message.reply_text("⚙️ إعدادات البوت:", reply_markup=InlineKeyboardMarkup(keyboard))


# ═══════════════════════════════════════════════════════
#                   قسم الامتحانات الجديد
# ═══════════════════════════════════════════════════════

EXAM_SUBJECTS = {
    "islamic": "الإسلامية",
    "arabic":  "العربي",
    "math":    "الرياضيات",
    "chem":    "الكيمياء",
    "phys":    "الفيزياء",
    "english": "English",
    "bio":     "الأحياء",
    "french":  "الفرنسي",
}


async def cmd_exams(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """قسم الامتحانات — يعرض المواد التي عندها امتحانات فقط"""
    import json
    all_exams = db.get_all_exams()

    available = {}
    for e in all_exams:
        sk = e["subject_key"]
        if sk not in available:
            available[sk] = EXAM_SUBJECTS.get(sk, sk)

    if not available:
        text = "📝 قسم الامتحانات\n\n⚠️ لا توجد امتحانات متاحة حالياً.\nتابع القناة لأحدث الاختبارات!"
        keyboard = [[InlineKeyboardButton("↩️ الرجوع", callback_data="main_home")]]
        if update.callback_query:
            await update.callback_query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
        return

    keyboard = []
    keys = list(available.keys())
    for i in range(0, len(keys), 2):
        row = [InlineKeyboardButton(available[keys[i]], callback_data=f"ex_sub_{keys[i]}")]
        if i + 1 < len(keys):
            row.append(InlineKeyboardButton(available[keys[i+1]], callback_data=f"ex_sub_{keys[i+1]}"))
        keyboard.append(row)
    keyboard.append([InlineKeyboardButton("↩️ الرجوع للقائمة الرئيسية", callback_data="main_home")])

    text = "📝 قسم الامتحانات\n\nاختر المادة:"
    if update.callback_query:
        await update.callback_query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
    else:
        await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard))


async def handle_exam_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """معالجة ضغطات أزرار الامتحانات"""
    import json
    query = update.callback_query
    data  = query.data
    await query.answer()

    if data.startswith("ex_sub_"):
        sub_key  = data.replace("ex_sub_", "")
        sub_name = EXAM_SUBJECTS.get(sub_key, sub_key)
        exams    = db.get_exams_by_subject(sub_key)

        if not exams:
            await query.edit_message_text(
                f"⚠️ لا توجد اختبارات لمادة {sub_name} حالياً.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("↩️ رجوع", callback_data="main_exams")]])
            )
            return

        keyboard = []
        for e in exams:
            keyboard.append([InlineKeyboardButton(
                f"📄 {e['label']}", callback_data=f"ex_sel_{e['id']}"
            )])
        keyboard.append([InlineKeyboardButton("↩️ تغيير المادة", callback_data="main_exams")])
        await query.edit_message_text(
            f"📚 {sub_name}\n\nاختر الاختبار:",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    elif data.startswith("ex_sel_"):
        exam_id = int(data.replace("ex_sel_", ""))
        exam    = db.get_exam_by_id(exam_id)
        if not exam:
            await query.edit_message_text("⚠️ الاختبار غير موجود.")
            return

        sub_name = EXAM_SUBJECTS.get(exam["subject_key"], exam["subject_key"])
        keyboard = [
            [
                InlineKeyboardButton("📋 إرسال الأسئلة",  callback_data=f"ex_q_{exam_id}"),
                InlineKeyboardButton("✅ إرسال الأجوبة", callback_data=f"ex_a_{exam_id}"),
            ],
            [InlineKeyboardButton("↩️ رجوع", callback_data=f"ex_sub_{exam['subject_key']}")],
        ]
        await query.edit_message_text(
            f"📝 {sub_name} — {exam['label']}\n\nاختر ما تريد:",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    elif data.startswith("ex_q_"):
        exam_id = int(data.replace("ex_q_", ""))
        exam    = db.get_exam_by_id(exam_id)
        if not exam:
            await query.answer("⚠️ الاختبار غير موجود.", show_alert=True)
            return

        q_imgs  = json.loads(exam["question_imgs"])
        chat_id = update.effective_chat.id
        await query.answer("📤 جاري الإرسال...")
        for img_path in q_imgs:
            with open(img_path, "rb") as f:
                await ctx.bot.send_photo(
                    chat_id=chat_id,
                    photo=f,
                    caption="📋 أسئلة الاختبار — بالتوفيق! 💪" if img_path == q_imgs[-1] else ""
                )

    elif data.startswith("ex_a_"):
        exam_id = int(data.replace("ex_a_", ""))
        exam    = db.get_exam_by_id(exam_id)
        if not exam:
            await query.answer("⚠️ الاختبار غير موجود.", show_alert=True)
            return

        a_imgs  = json.loads(exam["answer_imgs"])
        chat_id = update.effective_chat.id
        await query.answer("📤 جاري إرسال الأجوبة...")

        from telegram import InputMediaPhoto
        batch_size = 10
        for i in range(0, len(a_imgs), batch_size):
            batch = a_imgs[i:i+batch_size]
            media = []
            for j, img_path in enumerate(batch):
                caption = "✅ أجوبة الاختبار النموذجية" if (i == 0 and j == 0) else ""
                with open(img_path, "rb") as f:
                    media.append(InputMediaPhoto(media=f.read(), caption=caption))
            await ctx.bot.send_media_group(chat_id=chat_id, media=media)


# ═══════════════════════════════════════════════════════
#                   أوامر الأدمن
# ═══════════════════════════════════════════════════════

async def cmd_admin_add_question(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update.effective_user.id):
        return
    try:
        text    = " ".join(ctx.args)
        parts   = [p.strip() for p in text.split("|")]
        q, a    = parts[0], parts[1]
        subject = parts[2] if len(parts) > 2 else ""
        q_id    = db.add_question(q, a, subject)
        await update.message.reply_text(f"✅ تم إضافة السؤال #{q_id}")
    except Exception:
        await update.message.reply_text("❌ الصيغة:\n/add_q السؤال | الإجابة | المادة")


async def cmd_admin_add_challenge(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update.effective_user.id):
        return
    try:
        c_id = db.add_challenge(" ".join(ctx.args))
        await update.message.reply_text(f"✅ تم إضافة التحدي #{c_id}")
    except Exception:
        await update.message.reply_text("❌ اكتب النص بعد الأمر.")


async def cmd_admin_add_review(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update.effective_user.id):
        return
    try:
        text    = " ".join(ctx.args)
        parts   = [p.strip() for p in text.split("|")]
        content = parts[0]
        subject = parts[1] if len(parts) > 1 else ""
        r_id    = db.add_review_note(content, subject)
        await update.message.reply_text(f"✅ تم إضافة المراجعة #{r_id}")
    except Exception:
        await update.message.reply_text("❌ الصيغة: /add_r النص | المادة")


async def cmd_admin_add_riddle(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update.effective_user.id):
        return
    try:
        text  = " ".join(ctx.args)
        parts = [p.strip() for p in text.split("|")]
        r_id  = db.add_riddle(parts[0], parts[1])
        await update.message.reply_text(f"✅ تم إضافة اللغز #{r_id}")
    except Exception:
        await update.message.reply_text("❌ الصيغة: /add_l اللغز | الإجابة")


async def cmd_admin_reset_week(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update.effective_user.id):
        return
    db.reset_weekly_points()
    await update.message.reply_text("🔄 تم ريست النقاط الأسبوعية.")


async def cmd_admin_announce(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update.effective_user.id):
        return
    text = " ".join(ctx.args)
    if not text:
        await update.message.reply_text("❌ اكتب الإعلان بعد الأمر.")
        return
    groups = db.get_all_groups()
    count  = 0
    for g in groups:
        try:
            await ctx.bot.send_message(chat_id=g["group_id"], text=f"📢 إعلان\n\n{text}")
            count += 1
        except (Forbidden, BadRequest):
            db.deactivate_group(g["group_id"])
        except Exception as e:
            logger.error(f"Error sending to group {g['group_id']}: {e}")
    await update.message.reply_text(f"✅ تم إرسال الإعلان لـ {count} مجموعة.")


async def cmd_admin_give_points(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """منح نقاط يدوية: /give_points user_id | النقاط | السبب"""
    if not _is_admin(update.effective_user.id):
        return
    try:
        text   = " ".join(ctx.args)
        parts  = [p.strip() for p in text.split("|")]
        uid    = int(parts[0])
        amount = int(parts[1])
        reason = parts[2] if len(parts) > 2 else "منحة من الأدمن"
        student = db.get_student(uid)
        if not student:
            await update.message.reply_text("❌ الطالب غير موجود.")
            return
        db.add_points(uid, amount, reason)
        name = student["full_name"] or student["username"] or str(uid)
        await update.message.reply_text(
            f"✅ تم منح {name}\n"
            f"💫 {amount}+ نقطة\n"
            f"📝 السبب: {reason}"
        )
    except Exception:
        await update.message.reply_text("❌ الصيغة:\n/give_points ID_الطالب | النقاط | السبب")


async def cmd_admin_list_groups(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """عرض المجموعات المسجّلة"""
    if not _is_admin(update.effective_user.id):
        return
    groups = db.get_all_groups()
    if not groups:
        await update.message.reply_text("ما في مجموعات مسجّلة بعد.")
        return
    lines = [f"📋 المجموعات المسجّلة ({len(groups)})\n"]
    for g in groups:
        lines.append(f"• {g['title'] or '—'} — `{g['group_id']}`")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_admin_add_exam(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """
    إضافة امتحان جديد مع صور مسبقة التحويل
    الصيغة: /add_exam subject_key | label | q_img1,q_img2 | a_img1,a_img2,...
    مثال:   /add_exam math | رياضيات فصل أول | /opt/exams/math_f1/q_01.jpg | /opt/exams/math_f1/a_01.jpg,...
    """
    if not _is_admin(update.effective_user.id):
        return
    try:
        import json
        text   = " ".join(ctx.args)
        parts  = [p.strip() for p in text.split("|")]
        if len(parts) < 4:
            raise ValueError("ناقص أجزاء")
        sub_key    = parts[0]
        label      = parts[1]
        q_imgs     = [p.strip() for p in parts[2].split(",") if p.strip()]
        a_imgs     = [p.strip() for p in parts[3].split(",") if p.strip()]

        # تحقق من وجود الصور
        import os
        for p in q_imgs + a_imgs:
            if not os.path.exists(p):
                await update.message.reply_text(f"❌ الملف غير موجود: {p}")
                return

        exam_id = db.add_exam(sub_key, label, q_imgs, a_imgs)
        await update.message.reply_text(
            f"✅ تم إضافة الامتحان #{exam_id}\n"
            f"📚 المادة: {sub_key}\n"
            f"🏷 التسمية: {label}\n"
            f"📋 أسئلة: {len(q_imgs)} صورة\n"
            f"✅ أجوبة: {len(a_imgs)} صورة"
        )
    except Exception as e:
        await update.message.reply_text(
            f"❌ خطأ: {e}\n\n"
            "الصيغة:\n"
            "/add_exam subject_key | التسمية | مسار_سؤال1,مسار_سؤال2 | مسار_جواب1,مسار_جواب2,..."
        )
