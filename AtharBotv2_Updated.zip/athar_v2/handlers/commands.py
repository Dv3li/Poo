"""
handlers/commands.py — معالج الأوامر مع دعم الأزرار التفاعلية والتعديل المباشر
"""

import logging
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ContextTypes
from telegram.error import BadRequest, Forbidden

from config import ADMIN_IDS, POINTS, CHANNEL_URL, CHANNEL_ID, DEVELOPER_CHAT
from data import database as db

logger = logging.getLogger(__name__)


def _is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


def _name(user) -> str:
    return user.full_name or user.username or str(user.id)


async def check_subscription(user_id: int, bot) -> bool:
    try:
        member = await bot.get_chat_member(chat_id=CHANNEL_ID, user_id=user_id)
        return member.status in ["member", "administrator", "creator"]
    except Exception:
        return True


# لوحة المفاتيح الرئيسية (Reply Keyboard) - للوصول السريع
MAIN_KEYBOARD = ReplyKeyboardMarkup(
    [
        [KeyboardButton("سؤال اليوم"), KeyboardButton("تحدي اليوم")],
        [KeyboardButton("الامتحانات"), KeyboardButton("مراجعة")],
        [KeyboardButton("نقاطي"), KeyboardButton("المتصدرين")],
        [KeyboardButton("المساعدة"), KeyboardButton("الإعدادات")],
    ],
    resize_keyboard=True,
    one_time_keyboard=False
)

# أزرار التحكم الرئيسية (Inline Keyboard) للتنقل المباشر
def get_main_inline_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🧠 سؤال اليوم", callback_data="main_question"),
            InlineKeyboardButton("✅ تحدي اليوم", callback_data="main_challenge")
        ],
        [
            InlineKeyboardButton("📝 الامتحانات", callback_data="main_exams"),
            InlineKeyboardButton("📚 مراجعة", callback_data="main_review")
        ],
        [
            InlineKeyboardButton("📊 نقاطي", callback_data="main_points"),
            InlineKeyboardButton("🏆 المتصدرين", callback_data="main_board")
        ],
        [
            InlineKeyboardButton("📖 المساعدة", callback_data="main_help"),
            InlineKeyboardButton("⚙️ الإعدادات", callback_data="main_settings")
        ]
    ])


# ═══════════════════════════════════════════════════════
#                   أوامر الطلاب
# ═══════════════════════════════════════════════════════

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u    = update.effective_user
    chat = update.effective_chat

    if chat.type in ["group", "supergroup"]:
        db.register_group(chat.id, chat.title)
        await update.message.reply_text(
            f"✅ تم تفعيل بوت أثر في *{chat.title}*!\n\n"
            "سيبدأ البوت إرسال:\n"
            "📚 دقيقة مراجعة — ٨ صباحاً\n"
            "🧠 سؤال يومي — ١٠ صباحاً\n"
            "✅ تحدي اليوم — ٢ ظهراً\n"
            "🧩 لغز التفكير — ٦ مساءً\n\n"
            "اكتب /help لقائمة الأوامر",
            parse_mode="Markdown"
        )
        return

    if chat.type == "private":
        is_subscribed = await check_subscription(u.id, ctx.bot)
        if not is_subscribed:
            keyboard = [[InlineKeyboardButton("اشترك في القناة 📢", url=CHANNEL_URL)]]
            await update.message.reply_text(
                "عليك الاشتراك في القناة ثم اضغط /start",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            return

    db.upsert_student(u.id, u.username, u.full_name)
    await update.message.reply_text(
        f"أهلاً {u.first_name}! 👋\n\n"
        "🎓 *بوت أثر التعليمي*\n\n"
        "اختر من القائمة أدناه للتنقل السريع:",
        reply_markup=get_main_inline_keyboard()
    )


async def handle_main_callbacks(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """معالجة ضغطات أزرار القائمة الرئيسية للتنقل المباشر"""
    query = update.callback_query
    data = query.data
    u = update.effective_user
    
    await query.answer()

    if data == "main_points":
        student = db.get_student(u.id)
        if not student:
            text = "ما وجدت بياناتك، جرّب /start أول."
        else:
            streak_text = f"\n🔥 سلسلة: {student['streak']} يوم" if student['streak'] > 1 else ""
            text = (f"📊 نقاطك يا {u.first_name}\n\n"
                    f"⭐ المجموع: {student['points']} نقطة"
                    f"{streak_text}")
        await query.edit_message_text(text, reply_markup=get_main_inline_keyboard())

    elif data == "main_board":
        board = db.get_leaderboard(10)
        if not board:
            text = "ما في نقاط بعد!"
        else:
            medals = ["🥇", "🥈", "🥉"]
            lines  = ["🏆 لوحة المتصدرين\n"]
            for i, row in enumerate(board):
                medal = medals[i] if i < 3 else f"{i+1}."
                name  = row["full_name"] or row["username"] or "—"
                lines.append(f"{medal} {name} — {row['points']} نقطة")
            text = "\n".join(lines)
        await query.edit_message_text(text, reply_markup=get_main_inline_keyboard())

    elif data == "main_challenge":
        c = db.get_active_challenge()
        if not c:
            text = "❌ ما في تحدٍّ نشط الآن، انتظر الساعة ٢ ظهراً."
        else:
            closes = datetime.fromisoformat(c["closes_at"]).strftime("%H:%M")
            count  = db.get_challenge_completions_count(c["id"])
            text = (f"✅ تحدي اليوم\n\n📌 {c['challenge']}\n\n"
                    f"⏰ يغلق الساعة {closes}\n"
                    f"👥 أنجزه {count} طالب حتى الآن\n\n"
                    "اكتب /done بعد ما تخلص!")
        await query.edit_message_text(text, reply_markup=get_main_inline_keyboard())

    elif data == "main_question":
        q = db.get_active_question()
        if not q:
            text = "❌ ما في سؤال نشط الآن، انتظر سؤال الساعة ١٠ صباحاً."
        else:
            subject = f"[{q['subject']}] " if q['subject'] else ""
            text = f"🧠 السؤال اليومي {subject}\n\n{q['question']}\n\nاكتب إجابتك!"
        await query.edit_message_text(text, reply_markup=get_main_inline_keyboard())

    elif data == "main_review":
        r = db.get_last_review()
        if not r:
            text = "❌ ما في مراجعة بعد."
        else:
            subject = f"[{r['subject']}] " if r['subject'] else ""
            text = f"📚 دقيقة مراجعة {subject}\n\n{r['content']}"
        await query.edit_message_text(text, reply_markup=get_main_inline_keyboard())

    elif data == "main_settings":
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("قناة البوت 📢", url=CHANNEL_URL)],
            [InlineKeyboardButton("مطور البوت 👨‍💻", url=f"https://t.me/{DEVELOPER_CHAT.replace('@', '.')}")] ,
            [InlineKeyboardButton("↩️ رجوع", callback_data="main_home")]
        ])
        await query.edit_message_text("⚙️ إعدادات البوت:", reply_markup=keyboard)

    elif data == "main_help":
        text = (
            "📖 قائمة الأوامر\n\n"
            "👤 للطلاب:\n"
            "/points — رصيدك الحالي\n"
            "/board — لوحة المتصدرين\n"
            "/done — تسجيل إنجاز التحدي\n"
            "/history — تاريخ نشاطك\n"
            "/question — السؤال اليومي\n"
            "/challenge — تحدي اليوم\n"
            "/review — آخر معلومة\n"
            "/exams — قسم الامتحانات 📝\n\n"
            "🏆 النقاط:\n"
            "• أول إجابة صحيحة = 10 نقاط\n"
            "• ثاني إجابة صحيحة = 5 نقاط\n"
            "• إنجاز تحدي اليوم = 3 نقاط\n"
            "• أفضل تفسير للغز = 8 نقاط\n"
            "• بونص 5 أيام متتالية = 15 نقطة"
        )
        await query.edit_message_text(text, reply_markup=get_main_inline_keyboard())

    elif data == "main_home":
        await query.edit_message_text(
            f"أهلاً {u.first_name}! 👋\n\n"
            "🎓 *بوت أثر التعليمي*\n\n"
            "اختر من القائمة أدناه للتنقل السريع:",
            reply_markup=get_main_inline_keyboard()
        )
    
    elif data == "main_exams":
        await cmd_exams(update, ctx)


# الأوامر النصية العادية (للتوافق)
async def cmd_points(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    student = db.get_student(u.id)
    if not student:
        await update.message.reply_text("ما وجدت بياناتك، جرّب /start أول.")
        return
    streak_text = f"🔥 سلسلة: {student['streak']} يوم" if student['streak'] > 1 else ""
    await update.message.reply_text(
        f"📊 نقاطك يا {u.first_name}\n\n"
        f"⭐ المجموع: {student['points']} نقطة\n"
        f"{streak_text}",
        reply_markup=get_main_inline_keyboard()
    )

async def cmd_leaderboard(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    board = db.get_leaderboard(10)
    if not board:
        await update.message.reply_text("ما في نقاط بعد!")
        return
    medals = ["🥇", "🥈", "🥉"]
    lines  = ["🏆 لوحة المتصدرين\n"]
    for i, row in enumerate(board):
        medal = medals[i] if i < 3 else f"{i+1}."
        name  = row["full_name"] or row["username"] or "—"
        lines.append(f"{medal} {name} — {row['points']} نقطة")
    await update.message.reply_text("\n".join(lines), reply_markup=get_main_inline_keyboard())

async def cmd_done(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    challenge = db.get_active_challenge()
    if not challenge:
        await update.message.reply_text("❌ ما في تحدٍّ مفتوح الآن.")
        return
    closes_at = datetime.fromisoformat(challenge["closes_at"])
    if datetime.now() > closes_at:
        await update.message.reply_text("⏰ انتهى وقت التحدي.")
        return
    registered = db.register_challenge_completion(challenge["id"], u.id)
    if not registered:
        await update.message.reply_text("✅ أنت مسجّل مسبقاً في هذا التحدي!")
        return
    db.add_points(u.id, POINTS["challenge_done"], "إنجاز تحدي اليوم")
    streak = db.update_streak(u.id)
    streak_msg = ""
    if streak >= POINTS.get("streak_days_required", 5):
        db.add_points(u.id, POINTS["streak_bonus"], f"بونص {streak} أيام متتالية")
        streak_msg = f"\n🎉 حصلت على بونص {POINTS['streak_bonus']} نقطة!"
    count = db.get_challenge_completions_count(challenge["id"])
    await update.message.reply_text(
        f"✅ تم تسجيل إنجازك يا {u.first_name}!\n"
        f"💫 +{POINTS['challenge_done']} نقاط\n"
        f"🔥 سلسلتك: {streak} يوم\n"
        f"👥 أنجز التحدي: {count} طالب"
        + streak_msg
    )

async def cmd_history(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    history = db.get_points_history(u.id, 10)
    if not history:
        await update.message.reply_text("ما في سجل نشاط بعد.")
        return
    lines = [f"📋 آخر نشاطاتك يا {u.first_name}\n"]
    for row in history:
        sign = "+" if row["amount"] > 0 else ""
        dt   = row["created_at"][:10]
        lines.append(f"• {row['reason']} — {sign}{row['amount']} نقطة ({dt})")
    await update.message.reply_text("\n".join(lines))

async def cmd_question(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = db.get_active_question()
    if not q:
        await update.message.reply_text("❌ ما في سؤال نشط الآن، انتظر سؤال الساعة ١٠ صباحاً.")
        return
    subject = f"[{q['subject']}] " if q['subject'] else ""
    await update.message.reply_text(
        f"🧠 السؤال اليومي {subject}\n\n{q['question']}\n\nاكتب إجابتك!"
    )

async def cmd_challenge(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    c = db.get_active_challenge()
    if not c:
        await update.message.reply_text("❌ ما في تحدٍّ نشط الآن، انتظر الساعة ٢ ظهراً.")
        return
    closes = datetime.fromisoformat(c["closes_at"]).strftime("%H:%M")
    count  = db.get_challenge_completions_count(c["id"])
    await update.message.reply_text(
        f"✅ تحدي اليوم\n\n📌 {c['challenge']}\n\n"
        f"⏰ يغلق الساعة {closes}\n"
        f"👥 أنجزه {count} طالب حتى الآن\n\n"
        "اكتب /done بعد ما تخلص!"
    )

async def cmd_review(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    r = db.get_last_review()
    if not r:
        await update.message.reply_text("❌ ما في مراجعة بعد.")
        return
    subject = f"[{r['subject']}] " if r['subject'] else ""
    await update.message.reply_text(f"📚 دقيقة مراجعة {subject}\n\n{r['content']}")

async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📖 قائمة الأوامر\n\n"
        "👤 للطلاب:\n"
        "/points — رصيدك الحالي\n"
        "/board — لوحة المتصدرين\n"
        "/done — تسجيل إنجاز التحدي\n"
        "/history — تاريخ نشاطك\n"
        "/question — السؤال اليومي\n"
        "/challenge — تحدي اليوم\n"
        "/review — آخر معلومة\n"
        "/exams — قسم الامتحانات 📝\n\n"
        "🏆 النقاط:\n"
        "• أول إجابة صحيحة = 10 نقاط\n"
        "• ثاني إجابة صحيحة = 5 نقاط\n"
        "• إنجاز تحدي اليوم = 3 نقاط\n"
        "• أفضل تفسير للغز = 8 نقاط\n"
        "• بونص 5 أيام متتالية = 15 نقطة"
    )

async def cmd_settings(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("قناة البوت 📢", url=CHANNEL_URL)],
        [InlineKeyboardButton("مطور البوت 👨‍💻", url=f"https://t.me/{DEVELOPER_CHAT.replace('@', '.')}")]
    ]
    await update.message.reply_text("⚙️ إعدادات البوت:", reply_markup=InlineKeyboardMarkup(keyboard))


# ═══════════════════════════════════════════════════════
#                   قسم الامتحانات الجديد
# ═══════════════════════════════════════════════════════

EXAM_SUBJECTS = {
    "islamic": {"name": "الإسلامية", "chapter": "الأولى"},
    "arabic": {"name": "العربي", "chapter": "الاستفهام"},
    "math": {"name": "الرياضيات", "chapter": "الأول"},
    "chem": {"name": "الكيمياء", "chapter": "الأول"},
    "phys": {"name": "الفيزياء", "chapter": "الأول"},
    "english": {"name": "E", "chapter": "Unit One"},
    "bio": {"name": "الأحياء", "chapter": "الأول"},
    "french": {"name": "الفرنسي", "chapter": "الأولى"}
}

async def cmd_exams(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """بداية قسم الامتحانات - اختيار المادة"""
    keyboard = []
    # ترتيب المواد في صفوف (كل صف مادتين)
    subjects_keys = list(EXAM_SUBJECTS.keys())
    for i in range(0, len(subjects_keys), 2):
        row = []
        s1 = subjects_keys[i]
        row.append(InlineKeyboardButton(EXAM_SUBJECTS[s1]["name"], callback_data=f"ex_sub_{s1}"))
        if i + 1 < len(subjects_keys):
            s2 = subjects_keys[i+1]
            row.append(InlineKeyboardButton(EXAM_SUBJECTS[s2]["name"], callback_data=f"ex_sub_{s2}"))
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("↩️ الرجوع للقائمة الرئيسية", callback_data="main_home")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    text = "📝 قسم الامتحانات\n\nاختر المادة التي تريد امتحانها:"
    
    if update.callback_query:
        await update.callback_query.edit_message_text(text, reply_markup=reply_markup)
    else:
        await update.message.reply_text(text, reply_markup=reply_markup)


async def handle_exam_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """معالجة ضغطات أزرار الامتحانات"""
    query = update.callback_query
    data = query.data
    await query.answer()

    # المرحلة 1: اختيار الفصل بعد تحديد المادة
    if data.startswith("ex_sub_"):
        sub_key = data.replace("ex_sub_", "")
        subject = EXAM_SUBJECTS.get(sub_key)
        if not subject: return
        
        keyboard = [
            [InlineKeyboardButton(f"{subject['name']} : {subject['chapter']}", callback_data=f"ex_fin_{sub_key}")],
            [InlineKeyboardButton("↩️ تغيير المادة", callback_data="main_exams")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            f"📚 مادة {subject['name']}\n\nاختر الفصل/الموضوع:",
            reply_markup=reply_markup
        )

    # المرحلة 2: النتيجة النهائية (إرسال رسالة منفردة)
    elif data.startswith("ex_fin_"):
        sub_key = data.replace("ex_fin_", "")
        subject = EXAM_SUBJECTS.get(sub_key)
        if not subject: return
        
        # إرسال رسالة جديدة كما طلب المستخدم
        await ctx.bot.send_message(
            chat_id=update.effective_chat.id,
            text=(
                f"📝 *طلب امتحان جديد*\n\n"
                f"📚 المادة: {subject['name']}\n"
                f"📖 الفصل: {subject['chapter']}\n\n"
                "جاري تحضير الأسئلة لك... بالتوفيق! 💪"
            ),
            parse_mode="Markdown"
        )
        # العودة للقائمة الرئيسية في الرسالة الأصلية
        await query.edit_message_text(
            "✅ تم إرسال طلب الامتحان بنجاح!\nيمكنك اختيار مادة أخرى أو العودة:",
            reply_markup=get_main_inline_keyboard()
        )


# ═══════════════════════════════════════════════════════
#                   أوامر الأدمن
# ═══════════════════════════════════════════════════════

async def cmd_admin_add_question(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update.effective_user.id):
        return
    try:
        text    = " ".join(ctx.args)
        parts   = [p.strip() for p in text.split("|")]
        q, a    = parts[0], parts[1]
        subject = parts[2] if len(parts) > 2 else ""
        q_id    = db.add_question(q, a, subject)
        await update.message.reply_text(f"✅ تم إضافة السؤال #{q_id}")
    except Exception:
        await update.message.reply_text("❌ الصيغة:\n/add_q السؤال | الإجابة | المادة")


async def cmd_admin_add_challenge(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update.effective_user.id):
        return
    try:
        c_id = db.add_challenge(" ".join(ctx.args))
        await update.message.reply_text(f"✅ تم إضافة التحدي #{c_id}")
    except Exception:
        await update.message.reply_text("❌ اكتب النص بعد الأمر.")


async def cmd_admin_add_review(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update.effective_user.id):
        return
    try:
        text    = " ".join(ctx.args)
        parts   = [p.strip() for p in text.split("|")]
        content = parts[0]
        subject = parts[1] if len(parts) > 1 else ""
        r_id    = db.add_review_note(content, subject)
        await update.message.reply_text(f"✅ تم إضافة المراجعة #{r_id}")
    except Exception:
        await update.message.reply_text("❌ الصيغة: /add_r النص | المادة")


async def cmd_admin_add_riddle(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update.effective_user.id):
        return
    try:
        text  = " ".join(ctx.args)
        parts = [p.strip() for p in text.split("|")]
        r_id  = db.add_riddle(parts[0], parts[1])
        await update.message.reply_text(f"✅ تم إضافة اللغز #{r_id}")
    except Exception:
        await update.message.reply_text("❌ الصيغة: /add_l اللغز | الإجابة")


async def cmd_admin_reset_week(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update.effective_user.id):
        return
    db.reset_weekly_points()
    await update.message.reply_text("🔄 تم ريست النقاط الأسبوعية.")


async def cmd_admin_announce(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update.effective_user.id):
        return
    text = " ".join(ctx.args)
    if not text:
        await update.message.reply_text("❌ اكتب الإعلان بعد الأمر.")
        return
    groups = db.get_all_groups()
    count  = 0
    for g in groups:
        try:
            await ctx.bot.send_message(chat_id=g["group_id"], text=f"📢 إعلان\n\n{text}")
            count += 1
        except (Forbidden, BadRequest):
            db.deactivate_group(g["group_id"])
        except Exception as e:
            logger.error(f"Error sending to group {g['group_id']}: {e}")
    await update.message.reply_text(f"✅ تم إرسال الإعلان لـ {count} مجموعة.")


async def cmd_admin_give_points(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """منح نقاط يدوية: /give_points user_id | النقاط | السبب"""
    if not _is_admin(update.effective_user.id):
        return
    try:
        text   = " ".join(ctx.args)
        parts  = [p.strip() for p in text.split("|")]
        uid    = int(parts[0])
        amount = int(parts[1])
        reason = parts[2] if len(parts) > 2 else "منحة من الأدمن"
        student = db.get_student(uid)
        if not student:
            await update.message.reply_text("❌ الطالب غير موجود.")
            return
        db.add_points(uid, amount, reason)
        name = student["full_name"] or student["username"] or str(uid)
        await update.message.reply_text(
            f"✅ تم منح {name}\n"
            f"💫 {amount}+ نقطة\n"
            f"📝 السبب: {reason}"
        )
    except Exception:
        await update.message.reply_text("❌ الصيغة:\n/give_points ID_الطالب | النقاط | السبب")


async def cmd_admin_list_groups(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """عرض المجموعات المسجّلة"""
    if not _is_admin(update.effective_user.id):
        return
    groups = db.get_all_groups()
    if not groups:
        await update.message.reply_text("ما في مجموعات مسجّلة بعد.")
        return
    lines = [f"📋 المجموعات المسجّلة ({len(groups)})\n"]
    for g in groups:
        lines.append(f"• {g['title'] or '—'} — `{g['group_id']}`")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
