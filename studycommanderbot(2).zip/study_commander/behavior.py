"""
behavior.py — منطق الذكاء الاصطناعي للبوت
المسؤوليات:
- تذكير المستخدمين غير النشطين (24 ساعة)
- اقتراح جلسة قصيرة عند الفشل المتكرر
- رفع صعوبة التحديات عند الأداء الجيد
"""

import asyncio
import logging
from datetime import datetime, timedelta

import aiosqlite
from aiogram import Bot

from config import get_level, LEVELS
from database import DB_PATH

logger = logging.getLogger(__name__)

# ─── ثوابت ────────────────────────────────────────────────
INACTIVITY_HOURS = 24       # ساعات قبل إرسال التذكير
MAX_FAILS_BEFORE_SUGGEST = 3  # عدد الفشل قبل اقتراح جلسة قصيرة
CHECK_INTERVAL = 3600        # فحص كل ساعة (بالثواني)


# ─── رسائل التذكير ────────────────────────────────────────
REMINDER_MESSAGES = [
    "👀 لاحظت أنك غائب! الدراسة لا تنتظر أحداً.",
    "⚠️ مر {hours} ساعة بدون دراسة. هذا غير مقبول!",
    "🔥 أين أنت؟ منافسوك يدرسون الآن بينما أنت غائب.",
    "💤 استيقظ! كل ساعة تضيع لا تعود.",
]

SHORT_SESSION_MSG = (
    "😤 لاحظت أنك فشلت {fails} مرات متتالية.\n\n"
    "لا مشكلة — ابدأ بـ <b>5 دقائق فقط</b>.\n"
    "أحياناً البداية هي أصعب جزء.\n\n"
    "اضغط الزر أدناه:"
)

LEVEL_UP_CHALLENGE_MSG = (
    "🚀 <b>أداؤك ممتاز!</b> لاحظت تحسناً مستمراً.\n\n"
    "حان وقت رفع التحدي! جرب:\n"
    "• ٤ جلسات يومياً بدلاً من ٣\n"
    "• جلسات ٥٠ دقيقة بدلاً من ٢٥\n\n"
    "هل أنت مستعد؟"
)


# ─── فحص النشاط ───────────────────────────────────────────
async def get_inactive_users(hours: int = INACTIVITY_HOURS) -> list[dict]:
    """جلب المستخدمين الذين لم يكونوا نشطين خلال N ساعة"""
    cutoff = datetime.now() - timedelta(hours=hours)
    cutoff_str = cutoff.strftime("%Y-%m-%d %H:%M:%S")

    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            """
            SELECT u.user_id, u.full_name, u.last_active
            FROM users u
            WHERE u.last_active < ? OR u.last_active IS NULL
            """,
            (cutoff_str,)
        ) as cursor:
            rows = await cursor.fetchall()
    return [dict(r) for r in rows]


async def update_last_active(user_id: int):
    """تحديث وقت آخر نشاط للمستخدم"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET last_active = CURRENT_TIMESTAMP WHERE user_id = ?",
            (user_id,)
        )
        await db.commit()


async def get_recent_fails(user_id: int, limit: int = 5) -> int:
    """حساب عدد الجلسات الفاشلة المتتالية الأخيرة"""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            """
            SELECT completed FROM sessions
            WHERE user_id = ?
            ORDER BY started_at DESC
            LIMIT ?
            """,
            (user_id, limit)
        ) as cursor:
            rows = await cursor.fetchall()

    if not rows:
        return 0

    # عد الفشل المتتالي من الأحدث
    consecutive_fails = 0
    for row in rows:
        if row[0] == 0:
            consecutive_fails += 1
        else:
            break
    return consecutive_fails


async def get_recent_successes(user_id: int, limit: int = 5) -> int:
    """حساب عدد الجلسات الناجحة المتتالية الأخيرة"""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            """
            SELECT completed FROM sessions
            WHERE user_id = ?
            ORDER BY started_at DESC
            LIMIT ?
            """,
            (user_id, limit)
        ) as cursor:
            rows = await cursor.fetchall()

    if not rows:
        return 0

    consecutive_success = 0
    for row in rows:
        if row[0] == 1:
            consecutive_success += 1
        else:
            break
    return consecutive_success


async def update_streak(user_id: int):
    """تحديث streak اليومي للمستخدم"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row

        # جلب آخر جلسة ناجحة
        async with db.execute(
            """
            SELECT DATE(ended_at) as session_date FROM sessions
            WHERE user_id = ? AND completed = 1
            ORDER BY ended_at DESC LIMIT 1
            """,
            (user_id,)
        ) as cursor:
            row = await cursor.fetchone()

        if not row:
            return

        last_date = row["session_date"]
        today = datetime.now().date().isoformat()
        yesterday = (datetime.now().date() - timedelta(days=1)).isoformat()

        # جلب الـ streak الحالي
        async with db.execute(
            "SELECT streak FROM users WHERE user_id = ?",
            (user_id,)
        ) as cursor:
            user_row = await cursor.fetchone()

        current_streak = user_row["streak"] if user_row else 0

        if last_date == today:
            # نجح اليوم — زيّد الـ streak إذا لم يُحسب بعد
            pass
        elif last_date == yesterday:
            # استمر من الأمس
            new_streak = current_streak + 1
        else:
            # انقطع الـ streak
            new_streak = 1
            await db.execute(
                "UPDATE users SET streak = ? WHERE user_id = ?",
                (new_streak, user_id)
            )
            await db.commit()


# ─── منطق الذكاء ──────────────────────────────────────────
async def check_and_notify_inactive(bot: Bot):
    """إرسال تذكير للمستخدمين غير النشطين"""
    inactive_users = await get_inactive_users(INACTIVITY_HOURS)

    for user in inactive_users:
        user_id = user["user_id"]
        try:
            last = user.get("last_active")
            if last:
                last_dt = datetime.fromisoformat(last)
                hours_ago = int((datetime.now() - last_dt).total_seconds() / 3600)
            else:
                hours_ago = INACTIVITY_HOURS

            msg = REMINDER_MESSAGES[1].format(hours=hours_ago)

            from keyboards import main_menu
            await bot.send_message(
                user_id,
                f"⚠️ <b>تذكير!</b>\n\n{msg}",
                reply_markup=main_menu(),
                parse_mode="HTML"
            )
            logger.info(f"Sent inactivity reminder to user {user_id}")
        except Exception as e:
            logger.warning(f"Failed to notify user {user_id}: {e}")


async def suggest_short_session_if_needed(bot: Bot, user_id: int):
    """
    بعد كل جلسة فاشلة:
    إذا فشل أكثر من 3 مرات متتالية → اقترح جلسة 5 دقائق
    """
    fails = await get_recent_fails(user_id)

    if fails >= MAX_FAILS_BEFORE_SUGGEST:
        from keyboards import InlineKeyboardMarkup, InlineKeyboardButton
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⚡ ابدأ جلسة 5 دقائق", callback_data="quick_session_5")],
            [InlineKeyboardButton(text="🏠 القائمة الرئيسية", callback_data="main_menu")],
        ])
        try:
            await bot.send_message(
                user_id,
                SHORT_SESSION_MSG.format(fails=fails),
                reply_markup=keyboard,
                parse_mode="HTML"
            )
        except Exception as e:
            logger.warning(f"Failed to suggest short session to {user_id}: {e}")


async def suggest_harder_challenge_if_needed(bot: Bot, user_id: int):
    """
    بعد كل جلسة ناجحة:
    إذا نجح 5 مرات متتالية → اقترح تحديات أصعب
    """
    successes = await get_recent_successes(user_id)

    if successes >= 5:
        from keyboards import InlineKeyboardMarkup, InlineKeyboardButton
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔥 قبول التحدي الأصعب", callback_data="challenge_harder")],
            [InlineKeyboardButton(text="لاحقاً", callback_data="main_menu")],
        ])
        try:
            await bot.send_message(
                user_id,
                LEVEL_UP_CHALLENGE_MSG,
                reply_markup=keyboard,
                parse_mode="HTML"
            )
        except Exception as e:
            logger.warning(f"Failed to suggest harder challenge to {user_id}: {e}")


# ─── الحلقة الدورية ───────────────────────────────────────
async def behavior_loop(bot: Bot):
    """
    حلقة تعمل كل ساعة لفحص:
    - المستخدمين غير النشطين
    تُشغَّل كـ background task عند بدء البوت
    """
    while True:
        try:
            await check_and_notify_inactive(bot)
        except Exception as e:
            logger.error(f"Error in behavior loop: {e}")
        await asyncio.sleep(CHECK_INTERVAL)
