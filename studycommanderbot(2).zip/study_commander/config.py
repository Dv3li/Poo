"""
config.py — الإعدادات المركزية
يقرأ من .env تلقائياً عبر python-dotenv
"""

import os
from dotenv import load_dotenv

load_dotenv()  # يقرأ ملف .env تلقائياً

# ── التوكن ────────────────────────────────────────────────
BOT_TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
DATABASE_URL = os.getenv("DATABASE_URL", "study_commander.db")

# ── قيم XP ────────────────────────────────────────────────
XP_SESSION_COMPLETE  = 50
XP_SESSION_FAIL      = -20
XP_QUIZ_CORRECT      = 15
XP_CHALLENGE_COMPLETE = 100
XP_DAILY_TASK        = 20

# ── المستويات ─────────────────────────────────────────────
LEVELS = {
    1: {"name": "Beginner 🌱",  "name_ar": "مبتدئ 🌱",  "min_xp": 0},
    2: {"name": "Focused 🎯",   "name_ar": "مركّز 🎯",  "min_xp": 200},
    3: {"name": "Warrior ⚔️",   "name_ar": "محارب ⚔️",  "min_xp": 500},
    4: {"name": "Master 👑",    "name_ar": "أسطورة 👑",  "min_xp": 1000},
}


def get_level(xp: int) -> dict:
    """إرجاع معلومات المستوى الحالي بناءً على XP"""
    level = 1
    for lvl, data in LEVELS.items():
        if xp >= data["min_xp"]:
            level = lvl
    return {"level": level, **LEVELS[level]}


def xp_to_next_level(xp: int) -> int:
    """كم XP متبقي للمستوى التالي"""
    current = get_level(xp)["level"]
    if current == max(LEVELS.keys()):
        return 0
    return LEVELS[current + 1]["min_xp"] - xp
