from aiogram import Router, F
from aiogram.types import CallbackQuery

from database import create_challenge, get_active_challenge, update_xp
from keyboards import challenges_keyboard, back_to_menu
from config import XP_CHALLENGE_COMPLETE

router = Router()

CHALLENGE_INFO = {
    "7days": {
        "name": "7 أيام التزام 📅",
        "description": "التزم بجلسة دراسة واحدة على الأقل كل يوم لمدة 7 أيام",
        "target": 7,
        "reward": XP_CHALLENGE_COMPLETE,
    },
    "3sessions": {
        "name": "3 جلسات يومياً 🔥",
        "description": "أكمل 3 جلسات دراسة في يوم واحد — 7 أيام متتالية",
        "target": 21,
        "reward": XP_CHALLENGE_COMPLETE * 2,
    },
}


@router.callback_query(F.data == "challenges")
async def cb_challenges(callback: CallbackQuery):
    challenge = await get_active_challenge(callback.from_user.id)

    if challenge:
        info = CHALLENGE_INFO.get(challenge["challenge_type"], {})
        progress = challenge["progress"]
        target = challenge["target"]
        bar = "🟩" * progress + "⬜" * (target - progress)
        text = (
            f"🔥 <b>تحديك الحالي</b>\n\n"
            f"📌 {info.get('name', challenge['challenge_type'])}\n"
            f"📝 {info.get('description', '')}\n\n"
            f"التقدم: {progress}/{target}\n"
            f"{bar}\n\n"
            f"استمر! أنت تقترب من النجاح 💪"
        )
        await callback.message.edit_text(
            text,
            reply_markup=challenges_keyboard(),
            parse_mode="HTML"
        )
    else:
        await callback.message.edit_text(
            "🔥 <b>التحديات</b>\n\n"
            "اختر تحدياً لتبدأ به — هذا ما يميز المجتهد عن غيره:",
            reply_markup=challenges_keyboard(),
            parse_mode="HTML"
        )
    await callback.answer()


@router.callback_query(F.data.startswith("challenge_") & ~F.data.in_({"challenge_progress"}))
async def cb_start_challenge(callback: CallbackQuery):
    challenge_type = callback.data.replace("challenge_", "")

    if challenge_type not in CHALLENGE_INFO:
        await callback.answer("تحدي غير معروف")
        return

    existing = await get_active_challenge(callback.from_user.id)
    if existing:
        await callback.answer("⚠️ لديك تحدٍ نشط حالياً! أكمله أولاً.")
        return

    info = CHALLENGE_INFO[challenge_type]
    await create_challenge(callback.from_user.id, challenge_type, info["target"])

    await callback.message.edit_text(
        f"🚀 <b>بدأت التحدي!</b>\n\n"
        f"📌 <b>{info['name']}</b>\n"
        f"📝 {info['description']}\n\n"
        f"🏆 المكافأة عند النجاح: <b>+{info['reward']} XP</b>\n\n"
        f"لا تفشل. أنا أراقبك 👀",
        reply_markup=back_to_menu(),
        parse_mode="HTML"
    )
    await callback.answer("التحدي بدأ! 🔥")


@router.callback_query(F.data == "challenge_progress")
async def cb_challenge_progress(callback: CallbackQuery):
    challenge = await get_active_challenge(callback.from_user.id)

    if not challenge:
        await callback.answer("ليس لديك تحدٍ نشط حالياً.")
        return

    info = CHALLENGE_INFO.get(challenge["challenge_type"], {})
    progress = challenge["progress"]
    target = challenge["target"]
    percent = int((progress / target) * 100)

    await callback.answer(f"التقدم: {progress}/{target} ({percent}%)")
