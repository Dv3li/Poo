from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart

from database import get_or_create_user
from keyboards import main_menu
from config import get_level

router = Router()


def welcome_text(name: str) -> str:
    return (
        f"⚔️ مرحباً <b>{name}</b>!\n\n"
        "أنا <b>مدرب الدراسة الصارم</b> — هنا لأجعلك تدرس بجدية وانضباط.\n\n"
        "لا عذر. لا كسل. فقط نتائج. 💪\n\n"
        "اختر من القائمة:"
    )


@router.message(CommandStart())
async def cmd_start(message: Message):
    user = message.from_user
    await get_or_create_user(user.id, user.username or "", user.full_name)

    await message.answer(
        welcome_text(user.first_name),
        reply_markup=main_menu(),
        parse_mode="HTML"
    )


@router.callback_query(F.data == "main_menu")
async def cb_main_menu(callback: CallbackQuery):
    await callback.message.edit_text(
        welcome_text(callback.from_user.first_name),
        reply_markup=main_menu(),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "my_level")
async def cb_my_level(callback: CallbackQuery):
    from database import get_user
    from keyboards import back_to_menu
    from config import xp_to_next_level

    user = await get_user(callback.from_user.id)
    if not user:
        await callback.answer("سجّل أولاً!")
        return

    xp = user["xp"]
    level_info = get_level(xp)
    to_next = xp_to_next_level(xp)

    text = (
        f"🏆 <b>مستواك الحالي</b>\n\n"
        f"🎖 المستوى: <b>{level_info['name_ar']}</b>\n"
        f"⚡ XP الحالي: <b>{xp}</b>\n"
    )
    if to_next > 0:
        text += f"📈 تحتاج <b>{to_next} XP</b> للمستوى التالي\n"
    else:
        text += "👑 أنت في أعلى مستوى!\n"

    text += (
        f"\n📊 <b>الإنجازات:</b>\n"
        f"• الجلسات المكتملة: {user['total_sessions']}\n"
        f"• دقائق الدراسة: {user['total_minutes']}\n"
    )

    await callback.message.edit_text(text, reply_markup=back_to_menu(), parse_mode="HTML")
    await callback.answer()
