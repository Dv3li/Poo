from aiogram import Router, F
from aiogram.types import CallbackQuery, Message

from database import update_xp
from keyboards import quiz_keyboard, back_to_menu
from config import XP_QUIZ_CORRECT

router = Router()

# Question bank per subject
QUESTIONS = {
    "math": [
        {
            "q": "ما ناتج ٧ × ٨؟",
            "options": ["٥٤", "٥٦", "٦٤", "٤٨"],
            "answer": 1
        },
        {
            "q": "ما هو مربع العدد ١٢؟",
            "options": ["١٢٢", "١٣٢", "١٤٤", "١٦٠"],
            "answer": 2
        },
        {
            "q": "ما ناتج ١٥ ÷ ٣؟",
            "options": ["٣", "٤", "٥", "٦"],
            "answer": 2
        },
    ],
    "science": [
        {
            "q": "ما هي وحدة قياس القوة؟",
            "options": ["واط", "نيوتن", "جول", "باسكال"],
            "answer": 1
        },
        {
            "q": "كم عدد الكروموسومات في الخلية البشرية؟",
            "options": ["٢٣", "٤٦", "٤٢", "٤٨"],
            "answer": 1
        },
        {
            "q": "ما الصيغة الكيميائية للماء؟",
            "options": ["CO2", "H2O", "O2", "NaCl"],
            "answer": 1
        },
    ],
    "arabic": [
        {
            "q": "ما إعراب كلمة 'محمدٌ' في جملة: محمدٌ مجتهدٌ؟",
            "options": ["فاعل", "مبتدأ", "خبر", "مفعول به"],
            "answer": 1
        },
        {
            "q": "ما جمع كلمة 'كتاب'؟",
            "options": ["كتُب", "كتابات", "كتيبات", "أكتاب"],
            "answer": 0
        },
        {
            "q": "ما نوع الجملة: 'جاء الطالبُ'؟",
            "options": ["اسمية", "فعلية", "شرطية", "استفهامية"],
            "answer": 1
        },
    ],
    "social": [
        {
            "q": "ما عاصمة العراق؟",
            "options": ["البصرة", "الموصل", "بغداد", "أربيل"],
            "answer": 2
        },
        {
            "q": "على أي نهرين يقع العراق؟",
            "options": ["النيل والأردن", "دجلة والفرات", "دجلة والنيل", "الفرات والأردن"],
            "answer": 1
        },
        {
            "q": "ما أكبر قارات العالم مساحةً؟",
            "options": ["أفريقيا", "أمريكا الشمالية", "آسيا", "أوروبا"],
            "answer": 2
        },
    ],
    "chemistry": [
        {
            "q": "ما الرمز الكيميائي للذهب؟",
            "options": ["Go", "Gd", "Au", "Ag"],
            "answer": 2
        },
        {
            "q": "ما عدد العناصر في الجدول الدوري؟",
            "options": ["108", "118", "128", "98"],
            "answer": 1
        },
    ],
    "physics": [
        {
            "q": "ما سرعة الضوء تقريباً؟",
            "options": ["300,000 كم/ث", "150,000 كم/ث", "450,000 كم/ث", "200,000 كم/ث"],
            "answer": 0
        },
        {
            "q": "ما وحدة قياس الطاقة؟",
            "options": ["واط", "نيوتن", "جول", "فولت"],
            "answer": 2
        },
    ],
    "biology": [
        {
            "q": "ما وظيفة الكلوروفيل؟",
            "options": ["التنفس", "البناء الضوئي", "الهضم", "التكاثر"],
            "answer": 1
        },
        {
            "q": "ما الوحدة الأساسية للحياة؟",
            "options": ["النسيج", "العضو", "الخلية", "الجزيء"],
            "answer": 2
        },
    ],
    "computer": [
        {
            "q": "ما اختصار CPU؟",
            "options": [
                "Central Processing Unit",
                "Computer Power Unit",
                "Central Power Unit",
                "Computer Processing Unit"
            ],
            "answer": 0
        },
        {
            "q": "ما وحدة قياس سرعة المعالج؟",
            "options": ["GB", "MB", "GHz", "KB"],
            "answer": 2
        },
    ],
}

# Default fallback
DEFAULT_QUESTIONS = QUESTIONS["math"]


async def start_quiz(message: Message, subject: str, session_id: int):
    questions = QUESTIONS.get(subject, DEFAULT_QUESTIONS)
    if not questions:
        return

    q = questions[0]
    await message.answer(
        f"🧠 <b>اختبار سريع!</b>\n\n"
        f"❓ {q['q']}",
        reply_markup=quiz_keyboard(q["options"], session_id, 0),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("quiz_"))
async def cb_quiz_answer(callback: CallbackQuery):
    parts = callback.data.split("_")
    # quiz_{session_id}_{q_index}_{answer_index}
    session_id = int(parts[1])
    q_index = int(parts[2])
    answer_index = int(parts[3])

    from database import get_session
    session = await get_session(session_id)
    subject = session["subject"] if session else "math"

    questions = QUESTIONS.get(subject, DEFAULT_QUESTIONS)
    q = questions[q_index]
    correct = q["answer"] == answer_index

    if correct:
        await update_xp(callback.from_user.id, XP_QUIZ_CORRECT)
        result_text = f"✅ <b>صح!</b> +{XP_QUIZ_CORRECT} XP 🎉"
    else:
        correct_answer = q["options"][q["answer"]]
        result_text = f"❌ <b>خطأ!</b> الجواب الصحيح: <b>{correct_answer}</b>"

    # Check if there's a next question (max 3 questions)
    next_index = q_index + 1
    if next_index < len(questions) and next_index < 3:
        next_q = questions[next_index]
        await callback.message.edit_text(
            f"{result_text}\n\n"
            f"❓ {next_q['q']}",
            reply_markup=quiz_keyboard(next_q["options"], session_id, next_index),
            parse_mode="HTML"
        )
    else:
        await callback.message.edit_text(
            f"{result_text}\n\n"
            f"🏁 <b>انتهى الاختبار!</b>\n"
            f"رائع، استمر في التعلم. 💪",
            reply_markup=back_to_menu(),
            parse_mode="HTML"
        )

    await callback.answer("✅ تم" if correct else "❌ خطأ")


# ── اختبار سريع مستقل من القائمة الرئيسية ────────────────
@router.callback_query(F.data == "quick_quiz")
async def cb_quick_quiz(callback: CallbackQuery):
    """اختبار سريع بدون جلسة — يختار مادة عشوائية"""
    import random
    from keyboards import standalone_quiz_keyboard

    subject = random.choice(list(QUESTIONS.keys()))
    questions = QUESTIONS[subject]
    q = questions[0]

    await callback.message.edit_text(
        f"🧠 <b>اختبار سريع!</b>\n"
        f"المادة: {subject.upper()}\n\n"
        f"❓ {q['q']}",
        reply_markup=standalone_quiz_keyboard(q["options"], subject, 0),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("sqz_"))
async def cb_standalone_quiz_answer(callback: CallbackQuery):
    """معالجة إجابة الاختبار السريع المستقل"""
    parts = callback.data.split("_")
    # sqz_{subject}_{q_index}_{answer_index}
    subject = parts[1]
    q_index = int(parts[2])
    answer_index = int(parts[3])

    questions = QUESTIONS.get(subject, DEFAULT_QUESTIONS)
    q = questions[q_index]
    correct = q["answer"] == answer_index

    if correct:
        await update_xp(callback.from_user.id, XP_QUIZ_CORRECT)
        result_text = f"✅ <b>صح!</b> +{XP_QUIZ_CORRECT} XP 🎉"
    else:
        correct_answer = q["options"][q["answer"]]
        result_text = f"❌ <b>خطأ!</b> الجواب: <b>{correct_answer}</b>"

    next_index = q_index + 1
    if next_index < len(questions) and next_index < 3:
        from keyboards import standalone_quiz_keyboard
        next_q = questions[next_index]
        await callback.message.edit_text(
            f"{result_text}\n\n❓ {next_q['q']}",
            reply_markup=standalone_quiz_keyboard(next_q["options"], subject, next_index),
            parse_mode="HTML"
        )
    else:
        await callback.message.edit_text(
            f"{result_text}\n\n🏁 <b>انتهى الاختبار!</b> 💪",
            reply_markup=back_to_menu(),
            parse_mode="HTML"
        )
    await callback.answer("✅" if correct else "❌")
