"""
handlers/study.py — جلسات الدراسة
المنطق:
- اختيار المادة والمدة
- تشغيل التايمر
- إذا فشل +3 مرات → اقتراح جلسة 5 دقائق
- إذا نجح +5 مرات متتالية → اقتراح تحدي أصعب
"""

import asyncio
from aiogram import Router, F
from aiogram.types import CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database import (
    create_session, complete_session, update_xp,
    update_challenge_progress, get_active_challenge,
    touch_last_active, increment_streak,
    count_recent_fails, count_recent_successes
)
from keyboards import subject_keyboard, duration_keyboard, session_complete_keyboard, back_to_menu
from config import XP_SESSION_COMPLETE, XP_SESSION_FAIL, get_level

router = Router()

SUBJECT_NAMES = {
    "math":      "الرياضيات 📐",
    "science":   "العلوم 🔬",
    "arabic":    "اللغة العربية 📖",
    "social":    "الاجتماعيات 🌍",
    "chemistry": "الكيمياء ⚗️",
    "physics":   "الفيزياء ⚡",
    "biology":   "الأحياء 🧬",
    "computer":  "الحاسوب 💻",
    "general":   "عام 📚",
}


class SessionState(StatesGroup):
    choosing_subject  = State()
    choosing_duration = State()
    in_session        = State()


# ── فتح قائمة الجلسة ──────────────────────────────────────
@router.callback_query(F.data == "start_session")
async def cb_start_session(callback: CallbackQuery, state: FSMContext):
    await touch_last_active(callback.from_user.id)

    # فحص عدد الفشل المتتالي
    fails = await count_recent_fails(callback.from_user.id)
    include_5 = fails >= 3

    await state.set_state(SessionState.choosing_subject)
    text = "📚 <b>اختر المادة التي ستدرسها:</b>"
    if include_5:
        text = (
            "😤 لاحظت أنك فشلت عدة مرات متتالية.\n\n"
            "📚 <b>اختر المادة — أو ابدأ بـ 5 دقائق فقط:</b>"
        )

    await callback.message.edit_text(text, reply_markup=subject_keyboard(), parse_mode="HTML")
    await callback.answer()


# ── اختيار المادة ─────────────────────────────────────────
@router.callback_query(F.data.startswith("subject_"))
async def cb_choose_subject(callback: CallbackQuery, state: FSMContext):
    subject = callback.data.replace("subject_", "")
    await state.update_data(subject=subject)
    await state.set_state(SessionState.choosing_duration)

    subject_name = SUBJECT_NAMES.get(subject, subject)
    fails = await count_recent_fails(callback.from_user.id)
    include_5 = fails >= 3

    await callback.message.edit_text(
        f"✅ المادة: <b>{subject_name}</b>\n\n⏱ <b>كم دقيقة ستدرس؟</b>",
        reply_markup=duration_keyboard(include_5min=include_5),
        parse_mode="HTML"
    )
    await callback.answer()


# ── اختيار المدة وبدء الجلسة ─────────────────────────────
@router.callback_query(F.data.startswith("duration_"))
async def cb_choose_duration(callback: CallbackQuery, state: FSMContext):
    duration = int(callback.data.replace("duration_", ""))
    data = await state.get_data()
    subject = data.get("subject", "general")
    subject_name = SUBJECT_NAMES.get(subject, subject)

    session_id = await create_session(callback.from_user.id, subject, duration)
    await state.update_data(session_id=session_id, duration=duration)
    await state.set_state(SessionState.in_session)

    await callback.message.edit_text(
        f"🔥 <b>الجلسة بدأت!</b>\n\n"
        f"📚 المادة: <b>{subject_name}</b>\n"
        f"⏱ المدة: <b>{duration} دقيقة</b>\n\n"
        f"💪 ركّز. أغلق التطبيقات الأخرى.\n"
        f"سأنبهك عند انتهاء الوقت!",
        parse_mode="HTML"
    )
    await callback.answer("🚀 الجلسة بدأت!")

    asyncio.create_task(
        session_timer(callback.message, session_id, duration, callback.from_user.id)
    )


async def session_timer(message, session_id: int, duration: int, user_id: int):
    """تايمر الجلسة — ينتظر ثم يسأل عن الالتزام"""
    await asyncio.sleep(duration * 60)
    try:
        await message.answer(
            f"⏰ <b>انتهى الوقت!</b>\n\nهل التزمت بالدراسة طوال الجلسة؟",
            reply_markup=session_complete_keyboard(session_id),
            parse_mode="HTML"
        )
    except Exception:
        pass


# ── جلسة ناجحة ────────────────────────────────────────────
@router.callback_query(F.data.startswith("session_yes_"))
async def cb_session_yes(callback: CallbackQuery, state: FSMContext):
    session_id = int(callback.data.replace("session_yes_", ""))
    user_id = callback.from_user.id

    await complete_session(session_id, True)
    await update_xp(user_id, XP_SESSION_COMPLETE)
    await touch_last_active(user_id)
    await increment_streak(user_id)

    # تحديث التحدي النشط
    challenge = await get_active_challenge(user_id)
    if challenge:
        done = await update_challenge_progress(challenge["id"])
        if done:
            await update_xp(user_id, 100)
            await callback.message.answer(
                "🎉 <b>أكملت التحدي!</b> +100 XP إضافية! 👑",
                parse_mode="HTML"
            )

    from database import get_user
    user = await get_user(user_id)
    level_info = get_level(user["xp"])

    await callback.message.edit_text(
        f"🎉 <b>جلسة ناجحة!</b>\n\n"
        f"⚡ +{XP_SESSION_COMPLETE} XP\n"
        f"🏆 المجموع: <b>{user['xp']} XP</b>\n"
        f"🎖 المستوى: <b>{level_info['name_ar']}</b>\n"
        f"🔥 Streak: <b>{user['streak']} يوم</b>\n\n"
        f"الآن اختبار سريع! 🧠",
        reply_markup=back_to_menu(),
        parse_mode="HTML"
    )
    await callback.answer("أحسنت! 💪")

    # اقتراح تحدي أصعب إذا نجح 5 مرات متتالية
    successes = await count_recent_successes(user_id)
    if successes >= 5 and not challenge:
        from behavior import suggest_harder_challenge_if_needed
        await suggest_harder_challenge_if_needed(callback.message.bot, user_id)

    # تشغيل الاختبار
    from handlers.quiz import start_quiz
    from database import get_session
    session = await get_session(session_id)
    if session:
        await start_quiz(callback.message, session["subject"], session_id)

    await state.clear()


# ── جلسة فاشلة ────────────────────────────────────────────
@router.callback_query(F.data.startswith("session_no_"))
async def cb_session_no(callback: CallbackQuery, state: FSMContext):
    session_id = int(callback.data.replace("session_no_", ""))
    user_id = callback.from_user.id

    await complete_session(session_id, False)
    await update_xp(user_id, XP_SESSION_FAIL)
    await touch_last_active(user_id)

    from database import get_user
    user = await get_user(user_id)

    await callback.message.edit_text(
        f"😤 <b>كنت أتوقع أفضل منك!</b>\n\n"
        f"⚡ {XP_SESSION_FAIL} XP\n"
        f"🏆 المجموع: <b>{user['xp']} XP</b>\n\n"
        f"لا تكرر هذا. الالتزام هو الطريق الوحيد. 💪",
        reply_markup=back_to_menu(),
        parse_mode="HTML"
    )
    await callback.answer("المحاولة القادمة أفضل!")

    # اقتراح جلسة قصيرة إذا فشل +3 مرات
    fails = await count_recent_fails(user_id)
    if fails >= 3:
        from behavior import suggest_short_session_if_needed
        await suggest_short_session_if_needed(callback.message.bot, user_id)

    await state.clear()
