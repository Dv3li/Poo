"""
handlers/motivation.py — زر "حفّزني"
يعرض رسائل تحفيزية عشوائية مع Inline keyboard
"""

import random
from aiogram import Router, F
from aiogram.types import CallbackQuery

from keyboards import back_to_menu

router = Router()

MOTIVATIONS = [
    ("🔥", "النجاح لا يأتي بالتمني، بل بالعمل والمثابرة. ابدأ الآن!"),
    ("⚔️", "كل دقيقة تدرسها هي خطوة نحو هدفك. لا تتوقف."),
    ("🏆", "الفرق بينك وبين الناجحين ليس الذكاء — بل الانضباط اليومي."),
    ("💪", "الجلسة الواحدة لن تغير حياتك. لكن ألف جلسة ستفعل."),
    ("🎯", "ركّز. أغلق التلفون. الدنيا تنتظر بعد الدراسة."),
    ("🌟", "كل عالم كان يوماً طالباً يشعر بصعوبة الدراسة — واستمر."),
    ("⏰", "الوقت يمر سواء درست أم لا. اختر بحكمة."),
    ("🚀", "لا يوجد 'لاحقاً مناسب'. الوقت المناسب هو الآن."),
    ("🧠", "دماغك يتقوى كلما تحديته. الصعوبة علامة على النمو."),
    ("👑", "المذاكر الصارم اليوم = الناجح المحترم غداً."),
]


@router.callback_query(F.data == "motivate_me")
async def cb_motivate(callback: CallbackQuery):
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

    icon, text = random.choice(MOTIVATIONS)

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 رسالة أخرى", callback_data="motivate_me")],
        [InlineKeyboardButton(text="📚 ابدأ جلسة الآن!", callback_data="start_session")],
        [InlineKeyboardButton(text="🏠 القائمة", callback_data="main_menu")],
    ])

    await callback.message.edit_text(
        f"{icon} <b>حفّزني!</b>\n\n"
        f"<i>{text}</i>",
        reply_markup=keyboard,
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "quick_session_5")
async def cb_quick_session(callback: CallbackQuery):
    """جلسة 5 دقائق للمستخدمين الذين فشلوا أكثر من 3 مرات"""
    import asyncio
    from database import create_session, complete_session, update_xp, touch_last_active
    from config import XP_SESSION_COMPLETE
    from keyboards import session_complete_keyboard

    subject = "general"
    session_id = await create_session(callback.from_user.id, subject, 5)
    await touch_last_active(callback.from_user.id)

    await callback.message.edit_text(
        "⚡ <b>جلسة 5 دقائق بدأت!</b>\n\n"
        "فقط 5 دقائق. تستطيع.\n"
        "ركّز على شيء واحد صغير. اقرأ صفحة. حل مسألة.\n\n"
        "سأرسل لك تنبيهاً بعد 5 دقائق.",
        parse_mode="HTML"
    )
    await callback.answer("🚀 ابدأ!")

    await asyncio.sleep(5 * 60)
    try:
        await callback.message.answer(
            "⏰ انتهت الـ 5 دقائق!\nهل التزمت؟",
            reply_markup=session_complete_keyboard(session_id)
        )
    except Exception:
        pass


@router.callback_query(F.data == "challenge_harder")
async def cb_challenge_harder(callback: CallbackQuery):
    """قبول تحدي أصعب بعد الأداء الممتاز"""
    from database import create_challenge, get_active_challenge
    from keyboards import back_to_menu

    existing = await get_active_challenge(callback.from_user.id)
    if existing:
        await callback.answer("⚠️ لديك تحدٍ نشط حالياً!")
        return

    # تحدي أصعب: 4 جلسات يومياً × 7 أيام = 28 جلسة
    await create_challenge(callback.from_user.id, "4sessions_hard", 28)

    await callback.message.edit_text(
        "🔥 <b>قبلت التحدي الأصعب!</b>\n\n"
        "📌 <b>4 جلسات يومياً × 7 أيام</b>\n"
        "المكافأة: <b>+250 XP</b>\n\n"
        "أثبت أنك تستحق المستوى الأعلى! 👑",
        reply_markup=back_to_menu(),
        parse_mode="HTML"
    )
    await callback.answer("تحدي قُبل! 🔥")
