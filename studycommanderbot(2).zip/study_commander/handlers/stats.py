from aiogram import Router, F
from aiogram.types import CallbackQuery

from database import get_user
from keyboards import back_to_menu
from config import get_level, xp_to_next_level

router = Router()


@router.callback_query(F.data == "my_stats")
async def cb_my_stats(callback: CallbackQuery):
    user = await get_user(callback.from_user.id)
    if not user:
        await callback.answer("لم يتم العثور على بياناتك!")
        return

    xp = user["xp"]
    level_info = get_level(xp)
    to_next = xp_to_next_level(xp)
    hours = user["total_minutes"] // 60
    minutes = user["total_minutes"] % 60

    # XP progress bar
    current_level = level_info["level"]
    from config import LEVELS
    if current_level < max(LEVELS.keys()):
        current_min = LEVELS[current_level]["min_xp"]
        next_min = LEVELS[current_level + 1]["min_xp"]
        progress_in_level = xp - current_min
        range_size = next_min - current_min
        filled = int((progress_in_level / range_size) * 10)
        bar = "🟩" * filled + "⬜" * (10 - filled)
    else:
        bar = "🟩" * 10

    text = (
        f"📊 <b>إحصائياتك</b>\n\n"
        f"👤 {callback.from_user.first_name}\n"
        f"🎖 المستوى: <b>{level_info['name_ar']}</b>\n\n"
        f"⚡ XP: <b>{xp}</b>\n"
        f"{bar}\n"
    )

    if to_next > 0:
        text += f"📈 متبقي للمستوى التالي: <b>{to_next} XP</b>\n\n"
    else:
        text += "👑 أعلى مستوى!\n\n"

    text += (
        f"📚 <b>الجلسات:</b> {user['total_sessions']}\n"
        f"⏱ <b>وقت الدراسة:</b> {hours}س {minutes}د\n"
    )

    await callback.message.edit_text(text, reply_markup=back_to_menu(), parse_mode="HTML")
    await callback.answer()
