from aiogram import Router, F
from aiogram.types import CallbackQuery

from database import add_daily_tasks, get_today_tasks, mark_task_done, update_xp
from keyboards import plan_goal_keyboard, tasks_keyboard, back_to_menu
from config import XP_DAILY_TASK

router = Router()

GOAL_NAMES = {
    "exam_final": "النجاح في الامتحان النهائي 🏆",
    "chapter_1": "مراجعة الفصل الأول 📝",
    "chapter_2": "مراجعة الفصل الثاني 📝",
    "improve_grade": "رفع معدلي 💯",
    "full_curriculum": "إنهاء المنهج 📚",
}

# Pre-defined task templates per goal
GOAL_TASKS = {
    "exam_final": [
        {"subject": "الرياضيات 📐", "description": "راجع الوحدة الأولى"},
        {"subject": "العلوم 🔬", "description": "احفظ التعريفات الأساسية"},
        {"subject": "اللغة العربية 📖", "description": "مراجعة قواعد النحو"},
        {"subject": "الاجتماعيات 🌍", "description": "راجع الخرائط والتواريخ"},
    ],
    "chapter_1": [
        {"subject": "رياضيات 📐", "description": "حل تمارين الفصل الأول"},
        {"subject": "علوم 🔬", "description": "قراءة الفصل الأول"},
        {"subject": "عربي 📖", "description": "حفظ مفردات الدرس الأول"},
    ],
    "chapter_2": [
        {"subject": "رياضيات 📐", "description": "حل تمارين الفصل الثاني"},
        {"subject": "علوم 🔬", "description": "قراءة الفصل الثاني"},
        {"subject": "عربي 📖", "description": "حفظ مفردات الدرس الثاني"},
    ],
    "improve_grade": [
        {"subject": "المادة الأضعف 📐", "description": "ركّز على نقاط الضعف"},
        {"subject": "تمارين إضافية 📝", "description": "حل 10 أسئلة تدريبية"},
        {"subject": "مراجعة الأخطاء ✏️", "description": "راجع الاختبارات السابقة"},
    ],
    "full_curriculum": [
        {"subject": "رياضيات 📐", "description": "درّب على الوحدة التالية"},
        {"subject": "علوم 🔬", "description": "أكمل الدرس المتبقي"},
        {"subject": "عربي 📖", "description": "تمارين الكتاب المدرسي"},
        {"subject": "اجتماعيات 🌍", "description": "قراءة وتلخيص الدرس"},
    ],
}


@router.callback_query(F.data == "daily_plan")
async def cb_daily_plan(callback: CallbackQuery):
    tasks = await get_today_tasks(callback.from_user.id)

    if tasks:
        # Show existing tasks
        done = sum(1 for t in tasks if t["is_done"])
        await callback.message.edit_text(
            f"🎯 <b>مهامك اليوم</b>\n\n"
            f"✅ منجز: {done}/{len(tasks)}\n\n"
            f"اضغط على مهمة لتحديدها كمنجزة:",
            reply_markup=tasks_keyboard(tasks),
            parse_mode="HTML"
        )
    else:
        await callback.message.edit_text(
            "🎯 <b>ما هو هدفك الدراسي؟</b>\n\n"
            "اختر هدفك وسأحدد لك مهام اليوم:",
            reply_markup=plan_goal_keyboard(),
            parse_mode="HTML"
        )
    await callback.answer()


@router.callback_query(F.data.startswith("goal_"))
async def cb_choose_goal(callback: CallbackQuery):
    goal_key = callback.data.replace("goal_", "")
    goal_name = GOAL_NAMES.get(goal_key, goal_key)
    tasks_data = GOAL_TASKS.get(goal_key, GOAL_TASKS["exam_final"])

    await add_daily_tasks(callback.from_user.id, goal_name, tasks_data)
    tasks = await get_today_tasks(callback.from_user.id)

    await callback.message.edit_text(
        f"✅ هدفك: <b>{goal_name}</b>\n\n"
        f"📋 <b>مهامك لليوم:</b>\n\n"
        f"اضغط على مهمة عند إتمامها:",
        reply_markup=tasks_keyboard(tasks),
        parse_mode="HTML"
    )
    await callback.answer("تم تحديد خطتك! 💪")


@router.callback_query(F.data.startswith("task_done_"))
async def cb_task_done(callback: CallbackQuery):
    task_id = int(callback.data.replace("task_done_", ""))

    tasks = await get_today_tasks(callback.from_user.id)
    task = next((t for t in tasks if t["id"] == task_id), None)

    if task and not task["is_done"]:
        await mark_task_done(task_id)
        await update_xp(callback.from_user.id, XP_DAILY_TASK)
        await callback.answer(f"✅ أحسنت! +{XP_DAILY_TASK} XP")
    else:
        await callback.answer("هذه المهمة منجزة مسبقاً ✅")
        return

    # Refresh tasks
    tasks = await get_today_tasks(callback.from_user.id)
    done = sum(1 for t in tasks if t["is_done"])

    if done == len(tasks):
        await callback.message.edit_text(
            f"🎉 <b>أنجزت جميع مهام اليوم!</b>\n\n"
            f"هذا هو الانضباط الحقيقي. أنت تستحق النجاح! 💪\n"
            f"⚡ +{XP_DAILY_TASK} XP",
            reply_markup=back_to_menu(),
            parse_mode="HTML"
        )
    else:
        await callback.message.edit_text(
            f"🎯 <b>مهامك اليوم</b>\n\n"
            f"✅ منجز: {done}/{len(tasks)}\n\n"
            f"⚡ +{XP_DAILY_TASK} XP — استمر!",
            reply_markup=tasks_keyboard(tasks),
            parse_mode="HTML"
        )
