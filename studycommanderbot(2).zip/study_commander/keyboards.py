"""
keyboards.py — كل أزرار Inline Keyboard مركزية في مكان واحد
"""

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def main_menu() -> InlineKeyboardMarkup:
    """القائمة الرئيسية — 6 أزرار"""
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📚 ابدأ جلسة",   callback_data="start_session"),
            InlineKeyboardButton(text="🎯 خطتي اليوم",  callback_data="daily_plan"),
        ],
        [
            InlineKeyboardButton(text="🔥 التحديات",    callback_data="challenges"),
            InlineKeyboardButton(text="📊 تقدمي",       callback_data="my_stats"),
        ],
        [
            InlineKeyboardButton(text="🧠 اختبار سريع", callback_data="quick_quiz"),
            InlineKeyboardButton(text="⚡ حفّزني",       callback_data="motivate_me"),
        ],
    ])


def subject_keyboard() -> InlineKeyboardMarkup:
    subjects = [
        ("📐 رياضيات", "math"),      ("🔬 علوم",      "science"),
        ("📖 عربي",    "arabic"),     ("🌍 اجتماعيات", "social"),
        ("⚗️ كيمياء",  "chemistry"),  ("⚡ فيزياء",    "physics"),
        ("🧬 أحياء",   "biology"),    ("💻 حاسوب",     "computer"),
    ]
    rows = []
    for i in range(0, len(subjects), 2):
        row = [InlineKeyboardButton(text=s[0], callback_data=f"subject_{s[1]}") for s in subjects[i:i+2]]
        rows.append(row)
    rows.append([InlineKeyboardButton(text="🔙 رجوع", callback_data="main_menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def duration_keyboard(include_5min: bool = False) -> InlineKeyboardMarkup:
    rows = []
    if include_5min:
        rows.append([InlineKeyboardButton(text="⚡ 5 دقائق (سريع)", callback_data="duration_5")])
    rows.append([
        InlineKeyboardButton(text="⏱ 25 دقيقة", callback_data="duration_25"),
        InlineKeyboardButton(text="⏱ 50 دقيقة", callback_data="duration_50"),
    ])
    rows.append([InlineKeyboardButton(text="🔙 رجوع", callback_data="start_session")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def session_complete_keyboard(session_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ نعم، التزمت!", callback_data=f"session_yes_{session_id}"),
            InlineKeyboardButton(text="❌ لا، ما التزمت", callback_data=f"session_no_{session_id}"),
        ]
    ])


def quiz_keyboard(options: list, session_id: int, q_index: int) -> InlineKeyboardMarkup:
    buttons = [
        [InlineKeyboardButton(text=opt, callback_data=f"quiz_{session_id}_{q_index}_{i}")]
        for i, opt in enumerate(options)
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def standalone_quiz_keyboard(options: list, subject: str, q_index: int) -> InlineKeyboardMarkup:
    """اختبار سريع من القائمة الرئيسية (بدون session_id)"""
    buttons = [
        [InlineKeyboardButton(text=opt, callback_data=f"sqz_{subject}_{q_index}_{i}")]
        for i, opt in enumerate(options)
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def challenges_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📅 7 أيام التزام",         callback_data="challenge_7days")],
        [InlineKeyboardButton(text="🔥 3 جلسات يومياً (أسبوع)", callback_data="challenge_3sessions")],
        [InlineKeyboardButton(text="📈 تقدم التحدي الحالي",    callback_data="challenge_progress")],
        [InlineKeyboardButton(text="🔙 رجوع",                  callback_data="main_menu")],
    ])


def plan_goal_keyboard() -> InlineKeyboardMarkup:
    goals = [
        ("🏆 النجاح في الامتحان النهائي", "exam_final"),
        ("📝 مراجعة الفصل الأول",          "chapter_1"),
        ("📝 مراجعة الفصل الثاني",         "chapter_2"),
        ("💯 رفع معدلي",                   "improve_grade"),
        ("📚 إنهاء المنهج",                "full_curriculum"),
    ]
    buttons = [[InlineKeyboardButton(text=g[0], callback_data=f"goal_{g[1]}")] for g in goals]
    buttons.append([InlineKeyboardButton(text="🔙 رجوع", callback_data="main_menu")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def tasks_keyboard(tasks: list) -> InlineKeyboardMarkup:
    buttons = []
    for task in tasks:
        status = "✅" if task["completed"] else "⬜"
        label = f"{status} {task['subject']} — {task['title'][:28]}"
        buttons.append([InlineKeyboardButton(text=label, callback_data=f"task_done_{task['id']}")])
    buttons.append([InlineKeyboardButton(text="🔙 رجوع", callback_data="main_menu")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def back_to_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🏠 القائمة الرئيسية", callback_data="main_menu")]
    ])
