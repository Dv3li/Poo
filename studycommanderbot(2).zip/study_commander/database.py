"""
database.py — طبقة البيانات الكاملة
Schema:
  users    → id, name, xp, level, streak, last_active
  sessions → user_id, subject, duration, completed, date
  tasks    → user_id, title, completed
  challenges
"""

import aiosqlite
import logging
from datetime import date

DB_PATH = "study_commander.db"
logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════
# تهيئة قاعدة البيانات
# ═══════════════════════════════════════════════════════════

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:

        # ── Users ──────────────────────────────────────────
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id        INTEGER PRIMARY KEY,
                username       TEXT,
                full_name      TEXT,
                xp             INTEGER DEFAULT 0,
                level          INTEGER DEFAULT 1,
                streak         INTEGER DEFAULT 0,
                last_active    TEXT DEFAULT CURRENT_TIMESTAMP,
                joined_at      TEXT DEFAULT CURRENT_TIMESTAMP,
                total_sessions INTEGER DEFAULT 0,
                total_minutes  INTEGER DEFAULT 0
            )
        """)

        # ── Sessions ───────────────────────────────────────
        await db.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id          INTEGER NOT NULL,
                subject          TEXT,
                duration_minutes INTEGER,
                completed        INTEGER DEFAULT 0,
                started_at       TEXT DEFAULT CURRENT_TIMESTAMP,
                ended_at         TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)

        # ── Tasks (daily plan) ─────────────────────────────
        await db.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER NOT NULL,
                title       TEXT,
                subject     TEXT,
                goal        TEXT,
                completed   INTEGER DEFAULT 0,
                task_date   TEXT DEFAULT (DATE('now')),
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)

        # ── Challenges ─────────────────────────────────────
        await db.execute("""
            CREATE TABLE IF NOT EXISTS challenges (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id         INTEGER NOT NULL,
                challenge_type  TEXT,
                target          INTEGER,
                progress        INTEGER DEFAULT 0,
                is_complete     INTEGER DEFAULT 0,
                started_at      TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)

        await db.commit()
    logger.info("✅ Database initialized.")


# ═══════════════════════════════════════════════════════════
# Users
# ═══════════════════════════════════════════════════════════

async def get_or_create_user(user_id: int, username: str, full_name: str) -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM users WHERE user_id = ?", (user_id,)
        ) as cursor:
            row = await cursor.fetchone()

        if not row:
            await db.execute(
                "INSERT INTO users (user_id, username, full_name) VALUES (?, ?, ?)",
                (user_id, username, full_name)
            )
            await db.commit()
            async with db.execute(
                "SELECT * FROM users WHERE user_id = ?", (user_id,)
            ) as cursor:
                row = await cursor.fetchone()

        return dict(row)


async def get_user(user_id: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM users WHERE user_id = ?", (user_id,)
        ) as cursor:
            row = await cursor.fetchone()
        return dict(row) if row else None


async def update_xp(user_id: int, xp_delta: int):
    """تحديث XP مع حساب المستوى الجديد تلقائياً"""
    from config import get_level
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET xp = MAX(0, xp + ?) WHERE user_id = ?",
            (xp_delta, user_id)
        )
        async with db.execute(
            "SELECT xp FROM users WHERE user_id = ?", (user_id,)
        ) as cursor:
            row = await cursor.fetchone()
        if row:
            new_level = get_level(row[0])["level"]
            await db.execute(
                "UPDATE users SET level = ? WHERE user_id = ?",
                (new_level, user_id)
            )
        await db.commit()


async def touch_last_active(user_id: int):
    """تحديث وقت آخر نشاط"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET last_active = CURRENT_TIMESTAMP WHERE user_id = ?",
            (user_id,)
        )
        await db.commit()


async def increment_streak(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET streak = streak + 1 WHERE user_id = ?",
            (user_id,)
        )
        await db.commit()


async def reset_streak(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET streak = 0 WHERE user_id = ?",
            (user_id,)
        )
        await db.commit()


# ═══════════════════════════════════════════════════════════
# Sessions
# ═══════════════════════════════════════════════════════════

async def create_session(user_id: int, subject: str, duration: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "INSERT INTO sessions (user_id, subject, duration_minutes) VALUES (?, ?, ?)",
            (user_id, subject, duration)
        )
        await db.commit()
        return cursor.lastrowid


async def complete_session(session_id: int, completed: bool):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE sessions SET completed = ?, ended_at = CURRENT_TIMESTAMP WHERE id = ?",
            (1 if completed else 0, session_id)
        )
        if completed:
            async with db.execute(
                "SELECT user_id, duration_minutes FROM sessions WHERE id = ?",
                (session_id,)
            ) as cursor:
                row = await cursor.fetchone()
            if row:
                await db.execute(
                    """UPDATE users
                       SET total_sessions = total_sessions + 1,
                           total_minutes  = total_minutes + ?
                       WHERE user_id = ?""",
                    (row[1], row[0])
                )
        await db.commit()


async def get_session(session_id: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM sessions WHERE id = ?", (session_id,)
        ) as cursor:
            row = await cursor.fetchone()
        return dict(row) if row else None


async def count_recent_fails(user_id: int, limit: int = 5) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT completed FROM sessions WHERE user_id = ? ORDER BY started_at DESC LIMIT ?",
            (user_id, limit)
        ) as cursor:
            rows = await cursor.fetchall()
    count = 0
    for row in rows:
        if row[0] == 0:
            count += 1
        else:
            break
    return count


async def count_recent_successes(user_id: int, limit: int = 5) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT completed FROM sessions WHERE user_id = ? ORDER BY started_at DESC LIMIT ?",
            (user_id, limit)
        ) as cursor:
            rows = await cursor.fetchall()
    count = 0
    for row in rows:
        if row[0] == 1:
            count += 1
        else:
            break
    return count


# ═══════════════════════════════════════════════════════════
# Tasks
# ═══════════════════════════════════════════════════════════

async def add_daily_tasks(user_id: int, goal: str, tasks: list):
    today = str(date.today())
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "DELETE FROM tasks WHERE user_id = ? AND task_date = ?",
            (user_id, today)
        )
        for task in tasks:
            await db.execute(
                "INSERT INTO tasks (user_id, title, subject, goal, task_date) VALUES (?, ?, ?, ?, ?)",
                (user_id, task["description"], task["subject"], goal, today)
            )
        await db.commit()


async def get_today_tasks(user_id: int) -> list:
    today = str(date.today())
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM tasks WHERE user_id = ? AND task_date = ?",
            (user_id, today)
        ) as cursor:
            rows = await cursor.fetchall()
    return [dict(r) for r in rows]


async def mark_task_done(task_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE tasks SET completed = 1 WHERE id = ?", (task_id,))
        await db.commit()


# ═══════════════════════════════════════════════════════════
# Challenges
# ═══════════════════════════════════════════════════════════

async def create_challenge(user_id: int, challenge_type: str, target: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "INSERT INTO challenges (user_id, challenge_type, target) VALUES (?, ?, ?)",
            (user_id, challenge_type, target)
        )
        await db.commit()
        return cursor.lastrowid


async def get_active_challenge(user_id: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM challenges WHERE user_id = ? AND is_complete = 0 ORDER BY id DESC LIMIT 1",
            (user_id,)
        ) as cursor:
            row = await cursor.fetchone()
    return dict(row) if row else None


async def update_challenge_progress(challenge_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE challenges SET progress = progress + 1 WHERE id = ?",
            (challenge_id,)
        )
        async with db.execute(
            "SELECT progress, target FROM challenges WHERE id = ?",
            (challenge_id,)
        ) as cursor:
            row = await cursor.fetchone()
        if row and row[0] >= row[1]:
            await db.execute(
                "UPDATE challenges SET is_complete = 1 WHERE id = ?",
                (challenge_id,)
            )
            await db.commit()
            return True
        await db.commit()
        return False
