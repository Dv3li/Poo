# 🤖 Study Commander Bot — دليل التشغيل الكامل

## هيكل المشروع

```
study_commander/
├── bot.py                  ← نقطة البداية + تشغيل behavior loop
├── config.py               ← إعدادات + XP + مستويات (يقرأ .env)
├── database.py             ← كل عمليات SQLite
├── keyboards.py            ← كل أزرار Inline مركزية
├── behavior.py             ← منطق الذكاء (تذكير / اقتراحات)
├── requirements.txt
├── .env.example            ← نسخه إلى .env وعبّئ التوكن
└── handlers/
    ├── common.py           ← /start + القائمة الرئيسية + المستوى
    ├── study.py            ← جلسات الدراسة + تايمر ذكي
    ├── plan.py             ← الخطة اليومية
    ├── challenges.py       ← التحديات
    ├── stats.py            ← إحصائيات المستخدم
    ├── quiz.py             ← اختبار سريع (بعد جلسة + مستقل)
    └── motivation.py       ← حفّزني + جلسة 5 دقائق + تحدي أصعب
```

---

## ⚙️ كيف تربط البوت بـ Telegram API

### الخطوة 1 — إنشاء البوت
1. افتح تلجرام وابحث عن **@BotFather**
2. أرسل: `/newbot`
3. أدخل اسماً للبوت: `Study Commander`
4. أدخل username: `study_commander_bot` (مثال)
5. ستحصل على **توكن** مثل: `7123456789:AAFxxx...`

### الخطوة 2 — إعداد ملف .env
```bash
cp .env.example .env
nano .env
```
ضع التوكن:
```
BOT_TOKEN=7123456789:AAFxxx...
```

---

## 🚀 التشغيل على VPS (Contabo)

```bash
# رفع الملفات
scp -r study_commander/ root@62.171.156.153:/root/

# الدخول للسيرفر
ssh root@62.171.156.153
cd /root/study_commander

# تثبيت المتطلبات
pip install -r requirements.txt --break-system-packages

# إعداد .env
cp .env.example .env
nano .env   ← ضع التوكن هنا

# تشغيل تجريبي
python bot.py
```

---

## 🔄 التشغيل الدائم (systemd service)

```bash
nano /etc/systemd/system/studybot.service
```

```ini
[Unit]
Description=Study Commander Bot
After=network.target

[Service]
User=root
WorkingDirectory=/root/study_commander
EnvironmentFile=/root/study_commander/.env
ExecStart=/usr/bin/python3 bot.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
systemctl daemon-reload
systemctl enable studybot
systemctl start studybot
systemctl status studybot

# مراقبة الـ logs
journalctl -u studybot -f
```

---

## 🧠 منطق الذكاء (behavior.py)

| الحالة | الإجراء |
|--------|---------|
| غياب أكثر من 24 ساعة | تذكير تلقائي بزر "ابدأ جلسة" |
| فشل 3 مرات متتالية | اقتراح جلسة 5 دقائق |
| نجاح 5 مرات متتالية | اقتراح تحدي أصعب |

تعمل `behavior_loop` كـ background task كل ساعة.

---

## 🎮 نظام XP والمستويات

| الإجراء | XP |
|---------|-----|
| جلسة مكتملة | +50 |
| جلسة فاشلة | -20 |
| إجابة صحيحة | +15 |
| مهمة يومية | +20 |
| إكمال تحدي | +100 |

| المستوى | الاسم | XP |
|---------|-------|-----|
| 1 | مبتدئ 🌱 | 0 |
| 2 | مركّز 🎯 | 200 |
| 3 | محارب ⚔️ | 500 |
| 4 | أسطورة 👑 | 1000 |

---

## 📊 Schema قاعدة البيانات

```sql
users    (user_id, username, full_name, xp, level, streak, last_active, total_sessions, total_minutes)
sessions (id, user_id, subject, duration_minutes, completed, started_at, ended_at)
tasks    (id, user_id, title, subject, goal, completed, task_date)
challenges (id, user_id, challenge_type, target, progress, is_complete, started_at)
```
