import aiosqlite
import logging
from datetime import date
from contextlib import asynccontextmanager
from config import DB_PATH

logger = logging.getLogger(__name__)

@asynccontextmanager
async def db_session():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        yield db
        await db.commit()

async def init_db():
    async with db_session() as db:
        # Users
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY, username TEXT, full_name TEXT,
                xp INTEGER DEFAULT 0, level INTEGER DEFAULT 1, streak INTEGER DEFAULT 0,
                last_active TEXT DEFAULT CURRENT_TIMESTAMP, joined_at TEXT DEFAULT CURRENT_TIMESTAMP,
                total_sessions INTEGER DEFAULT 0, total_minutes INTEGER DEFAULT 0
            )
        """)
        # Sessions
        await db.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
                subject TEXT, duration_minutes INTEGER, completed INTEGER DEFAULT 0,
                started_at TEXT DEFAULT CURRENT_TIMESTAMP, ended_at TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        # Tasks
        await db.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
                title TEXT, subject TEXT, goal TEXT, completed INTEGER DEFAULT 0,
                task_date TEXT DEFAULT (DATE('now')),
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        # Challenges
        await db.execute("""
            CREATE TABLE IF NOT EXISTS challenges (
                id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
                challenge_type TEXT, target INTEGER, progress INTEGER DEFAULT 0,
                is_complete INTEGER DEFAULT 0, started_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
    logger.info("✅ Database initialized.")

# ── User Operations ───────────────────────────────────────
async def get_user(user_id: int) -> dict | None:
    async with db_session() as db:
        async with db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None

async def ensure_user(user_id: int, username: str, full_name: str) -> dict:
    user = await get_user(user_id)
    if not user:
        async with db_session() as db:
            await db.execute(
                "INSERT INTO users (user_id, username, full_name) VALUES (?, ?, ?)",
                (user_id, username, full_name)
            )
        user = await get_user(user_id)
    return user

async def update_user(user_id: int, **kwargs):
    """Generic user update helper."""
    if not kwargs: return
    cols = ", ".join([f"{k} = ?" for k in kwargs.keys()])
    async with db_session() as db:
        await db.execute(f"UPDATE users SET {cols} WHERE user_id = ?", (*kwargs.values(), user_id))

async def update_xp(user_id: int, xp_delta: int):
    from config import get_level_info
    user = await get_user(user_id)
    if user:
        new_xp = max(0, user['xp'] + xp_delta)
        new_level = get_level_info(new_xp)['level']
        await update_user(user_id, xp=new_xp, level=new_level, last_active="CURRENT_TIMESTAMP")

# ── Session Operations ────────────────────────────────────
async def create_session(user_id: int, subject: str, duration: int) -> int:
    async with db_session() as db:
        cursor = await db.execute(
            "INSERT INTO sessions (user_id, subject, duration_minutes) VALUES (?, ?, ?)",
            (user_id, subject, duration)
        )
        return cursor.lastrowid

async def finalize_session(session_id: int, completed: bool):
    async with db_session() as db:
        await db.execute(
            "UPDATE sessions SET completed = ?, ended_at = CURRENT_TIMESTAMP WHERE id = ?",
            (1 if completed else 0, session_id)
        )
        if completed:
            async with db.execute("SELECT user_id, duration_minutes FROM sessions WHERE id = ?", (session_id,)) as cursor:
                row = await cursor.fetchone()
                if row:
                    await db.execute(
                        "UPDATE users SET total_sessions = total_sessions + 1, total_minutes = total_minutes + ? WHERE user_id = ?",
                        (row[1], row[0])
                    )

async def get_recent_stats(user_id: int, limit: int = 5):
    async with db_session() as db:
        async with db.execute(
            "SELECT completed FROM sessions WHERE user_id = ? ORDER BY started_at DESC LIMIT ?",
            (user_id, limit)
        ) as cursor:
            rows = await cursor.fetchall()
            return [r[0] for r in rows]

# ── Task Operations ───────────────────────────────────────
async def sync_daily_tasks(user_id: int, goal: str, tasks: list):
    today = str(date.today())
    async with db_session() as db:
        await db.execute("DELETE FROM tasks WHERE user_id = ? AND task_date = ?", (user_id, today))
        for t in tasks:
            await db.execute(
                "INSERT INTO tasks (user_id, title, subject, goal, task_date) VALUES (?, ?, ?, ?, ?)",
                (user_id, t["description"], t["subject"], goal, today)
            )

async def get_today_tasks(user_id: int) -> list:
    async with db_session() as db:
        async with db.execute("SELECT * FROM tasks WHERE user_id = ? AND task_date = ?", (user_id, str(date.today()))) as cursor:
            return [dict(r) for r in await cursor.fetchall()]

# ── Challenge Operations ──────────────────────────────────
async def create_challenge(user_id: int, c_type: str, target: int):
    async with db_session() as db:
        await db.execute("INSERT INTO challenges (user_id, challenge_type, target) VALUES (?, ?, ?)", (user_id, c_type, target))

async def get_active_challenge(user_id: int) -> dict | None:
    async with db_session() as db:
        async with db.execute("SELECT * FROM challenges WHERE user_id = ? AND is_complete = 0 ORDER BY id DESC LIMIT 1", (user_id,)) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None

async def advance_challenge(challenge_id: int) -> bool:
    async with db_session() as db:
        await db.execute("UPDATE challenges SET progress = progress + 1 WHERE id = ?", (challenge_id,))
        async with db.execute("SELECT progress, target FROM challenges WHERE id = ?", (challenge_id,)) as cursor:
            row = await cursor.fetchone()
            if row and row[0] >= row[1]:
                await db.execute("UPDATE challenges SET is_complete = 1 WHERE id = ?", (challenge_id,))
                return True
    return False
