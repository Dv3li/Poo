import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage

from config import BOT_TOKEN
from database import init_db
from handlers import common, study, plan, challenges, stats, quiz, motivation
from behavior import behavior_loop

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger(__name__)

async def main():
    bot = Bot(token=BOT_TOKEN)
    dp = Dispatcher(storage=MemoryStorage())

    # Register Routers
    for router in [common.router, study.router, plan.router, challenges.router, stats.router, quiz.router, motivation.router]:
        dp.include_router(router)

    await init_db()
    asyncio.create_task(behavior_loop(bot))

    logger.info("🤖 Study Commander Bot is running!")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
