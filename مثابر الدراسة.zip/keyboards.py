from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import InlineKeyboardMarkup
from config import SUBJECTS

def make_kb(buttons: list, width: int = 2) -> InlineKeyboardMarkup:
    """Helper to create inline keyboards quickly."""
    builder = InlineKeyboardBuilder()
    for text, data in buttons:
        builder.button(text=text, callback_data=data)
    builder.adjust(width)
    return builder.as_markup()

def main_menu() -> InlineKeyboardMarkup:
    return make_kb([
        ("📖 ابدأ جلسة", "start_session"), ("📅 خطتي اليومية", "daily_plan"),
        ("🏆 مستواي", "my_level"), ("📊 إحصائياتي", "my_stats"),
        ("🔥 التحديات", "challenges"), ("🧠 اختبار سريع", "quick_quiz")
    ])

def subject_keyboard() -> InlineKeyboardMarkup:
    btns = [(name, f"subject_{code}") for code, name in SUBJECTS.items()]
    btns.append(("🔙 رجوع", "main_menu"))
    return make_kb(btns, width=2)

def duration_keyboard(include_5min: bool = False) -> InlineKeyboardMarkup:
    btns = [("⏱ 25 دقيقة", "duration_25"), ("⏱ 50 دقيقة", "duration_50")]
    if include_5min: btns.insert(0, ("⚡ 5 دقائق (سريع)", "duration_5"))
    btns.append(("🔙 رجوع", "start_session"))
    return make_kb(btns)

def session_complete_keyboard(session_id: int) -> InlineKeyboardMarkup:
    return make_kb([
        ("✅ نعم، التزمت", f"session_yes_{session_id}"),
        ("❌ لا، فشلت", f"session_no_{session_id}")
    ])

def quiz_keyboard(options: list, session_id: int, q_index: int) -> InlineKeyboardMarkup:
    btns = [(opt, f"quiz_{session_id}_{q_index}_{i}") for i, opt in enumerate(options)]
    return make_kb(btns, width=1)

def standalone_quiz_keyboard(options: list, subject: str, q_index: int) -> InlineKeyboardMarkup:
    btns = [(opt, f"sqz_{subject}_{q_index}_{i}") for i, opt in enumerate(options)]
    return make_kb(btns, width=1)

def challenges_keyboard() -> InlineKeyboardMarkup:
    return make_kb([
        ("🌱 تحدي 7 أيام", "challenge_7days"),
        ("⚔️ تحدي 21 جلسة", "challenge_3sessions"),
        ("🔙 رجوع", "main_menu")
    ])

def plan_goal_keyboard() -> InlineKeyboardMarkup:
    return make_kb([
        ("🎓 تفوق دراسي", "goal_excellence"),
        ("📚 إنهاء المنهج", "goal_finish"),
        ("🔙 رجوع", "main_menu")
    ])

def tasks_keyboard(tasks: list) -> InlineKeyboardMarkup:
    btns = []
    for t in tasks:
        icon = "✅" if t.get('completed') else "⏳"
        btns.append((f"{icon} {t['subject'][:10]}: {t['title'][:15]}...", f"task_done_{t['id']}"))
    btns.append(("🔙 رجوع", "main_menu"))
    return make_kb(btns, width=1)

def back_to_menu() -> InlineKeyboardMarkup:
    return make_kb([("🔙 القائمة الرئيسية", "main_menu")])
