import os
from dotenv import load_dotenv

load_dotenv()

# ── Settings ──────────────────────────────────────────────
BOT_TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
DB_PATH = os.getenv("DATABASE_URL", "study_commander.db")

# ── Rewards ───────────────────────────────────────────────
XP_REWARDS = {
    "session_complete": 50,
    "session_fail": -20,
    "quiz_correct": 15,
    "challenge_complete": 100,
    "daily_task": 20
}

# ── Progression ───────────────────────────────────────────
LEVELS = [
    (0, "Beginner 🌱", "مبتدئ 🌱"),
    (200, "Focused 🎯", "مركّز 🎯"),
    (500, "Warrior ⚔️", "محارب ⚔️"),
    (1000, "Master 👑", "أسطورة 👑"),
]

def get_level_info(xp: int) -> dict:
    """Returns current level data based on XP."""
    current = LEVELS[0]
    next_xp = None
    for i, (min_xp, name, name_ar) in enumerate(LEVELS):
        if xp >= min_xp:
            current = {"level": i + 1, "name": name, "name_ar": name_ar, "min_xp": min_xp}
            next_xp = LEVELS[i+1][0] if i+1 < len(LEVELS) else None
    
    return {
        **current,
        "next_xp": next_xp,
        "to_next": (next_xp - xp) if next_xp else 0
    }

# ── Subjects ──────────────────────────────────────────────
SUBJECTS = {
    "math": "الرياضيات 📐", "science": "العلوم 🔬", "arabic": "اللغة العربية 📖",
    "social": "الاجتماعيات 🌍", "chemistry": "الكيمياء ⚗️", "physics": "الفيزياء ⚡",
    "biology": "الأحياء 🧬", "computer": "الحاسوب 💻", "general": "عام 📚"
}
