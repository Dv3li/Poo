from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart

from database import ensure_user, get_user
from keyboards import main_menu, back_to_menu
from config import get_level_info

router = Router()

def welcome_text(name: str) -> str:
    return (
        f"⚔️ مرحباً <b>{name}</b>!\n\n"
        "أنا <b>مدرب الدراسة الصارم</b> — هنا لأجعلك تدرس بجدية وانضباط.\n\n"
        "لا عذر. لا كسل. فقط نتائج. 💪\n\n"
        "اختر من القائمة:"
    )

@router.message(CommandStart())
async def cmd_start(message: Message):
    user = message.from_user
    await ensure_user(user.id, user.username or "", user.full_name)
    await message.answer(welcome_text(user.first_name), reply_markup=main_menu(), parse_mode="HTML")

@router.callback_query(F.data == "main_menu")
async def cb_main_menu(callback: CallbackQuery):
    await callback.message.edit_text(welcome_text(callback.from_user.first_name), reply_markup=main_menu(), parse_mode="HTML")
    await callback.answer()

@router.callback_query(F.data == "my_level")
async def cb_my_level(callback: CallbackQuery):
    user = await get_user(callback.from_user.id)
    if not user: return await callback.answer("سجّل أولاً!")

    lvl = get_level_info(user["xp"])
    text = (
        f"🏆 <b>مستواك الحالي</b>\n\n"
        f"🎖 المستوى: <b>{lvl['name_ar']}</b>\n"
        f"⚡ XP الحالي: <b>{user['xp']}</b>\n"
        f"{f'📈 تحتاج <b>{lvl['to_next']} XP</b> للمستوى التالي' if lvl['next_xp'] else '👑 أنت في أعلى مستوى!'}\n\n"
        f"📊 <b>الإنجازات:</b>\n"
        f"• الجلسات المكتملة: {user['total_sessions']}\n"
        f"• دقائق الدراسة: {user['total_minutes']}\n"
    )
    await callback.message.edit_text(text, reply_markup=back_to_menu(), parse_mode="HTML")
    await callback.answer()
