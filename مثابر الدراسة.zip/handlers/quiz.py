import random
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from database import update_xp, get_session
from keyboards import quiz_keyboard, standalone_quiz_keyboard, back_to_menu
from config import XP_REWARDS, SUBJECTS

router = Router()

QUESTIONS = {
    "math": [
        {"q": "ما ناتج ٧ × ٨؟", "options": ["٥٤", "٥٦", "٦٤", "٤٨"], "answer": 1},
        {"q": "ما هو مربع العدد ١٢؟", "options": ["١٢٢", "١٣٢", "١٤٤", "١٦٠"], "answer": 2},
        {"q": "ما ناتج ١٥ ÷ ٣؟", "options": ["٣", "٤", "٥", "٦"], "answer": 2},
    ],
    "science": [
        {"q": "ما هي وحدة قياس القوة؟", "options": ["واط", "نيوتن", "جول", "باسكال"], "answer": 1},
        {"q": "كم عدد الكروموسومات في الخلية البشرية؟", "options": ["٢٣", "٤٦", "٤٢", "٤٨"], "answer": 1},
        {"q": "ما الصيغة الكيميائية للماء؟", "options": ["CO2", "H2O", "O2", "NaCl"], "answer": 1},
    ],
    "arabic": [
        {"q": "ما إعراب كلمة 'محمدٌ' في جملة: محمدٌ مجتهدٌ؟", "options": ["فاعل", "مبتدأ", "خبر", "مفعول به"], "answer": 1},
        {"q": "ما جمع كلمة 'كتاب'؟", "options": ["كتُب", "كتابات", "كتيبات", "أكتاب"], "answer": 0},
        {"q": "ما نوع الجملة: 'جاء الطالبُ'؟", "options": ["اسمية", "فعلية", "شرطية", "استفهامية"], "answer": 1},
    ],
    "social": [
        {"q": "ما عاصمة العراق؟", "options": ["البصرة", "الموصل", "بغداد", "أربيل"], "answer": 2},
        {"q": "على أي نهرين يقع العراق؟", "options": ["النيل والأردن", "دجلة والفرات", "دجلة والنيل", "الفرات والأردن"], "answer": 1},
        {"q": "ما أكبر قارات العالم مساحةً؟", "options": ["أفريقيا", "أمريكا الشمالية", "آسيا", "أوروبا"], "answer": 2},
    ],
    "chemistry": [
        {"q": "ما الرمز الكيميائي للذهب؟", "options": ["Go", "Gd", "Au", "Ag"], "answer": 2},
        {"q": "ما عدد العناصر في الجدول الدوري؟", "options": ["108", "118", "128", "98"], "answer": 1},
    ],
    "physics": [
        {"q": "ما سرعة الضوء تقريباً؟", "options": ["300,000 كم/ث", "150,000 كم/ث", "450,000 كم/ث", "200,000 كم/ث"], "answer": 0},
        {"q": "ما وحدة قياس الطاقة؟", "options": ["واط", "نيوتن", "جول", "فولت"], "answer": 2},
    ],
    "biology": [
        {"q": "ما وظيفة الكلوروفيل؟", "options": ["التنفس", "البناء الضوئي", "الهضم", "التكاثر"], "answer": 1},
        {"q": "ما الوحدة الأساسية للحياة؟", "options": ["النسيج", "العضو", "الخلية", "الجزيء"], "answer": 2},
    ],
    "computer": [
        {"q": "ما اختصار CPU؟", "options": ["Central Processing Unit", "Computer Power Unit", "Central Power Unit", "Computer Processing Unit"], "answer": 0},
        {"q": "ما وحدة قياس سرعة المعالج؟", "options": ["GB", "MB", "GHz", "KB"], "answer": 2},
    ],
}

async def start_quiz(message: Message, subject: str, session_id: int):
    qs = QUESTIONS.get(subject, QUESTIONS["math"])
    q = qs[0]
    await message.answer(f"🧠 <b>اختبار سريع: {SUBJECTS.get(subject, subject)}</b>\n\n❓ {q['q']}", 
                         reply_markup=quiz_keyboard(q["options"], session_id, 0), parse_mode="HTML")

@router.callback_query(F.data.startswith("quiz_"))
async def cb_quiz(callback: CallbackQuery):
    _, session_id, q_idx, ans_idx = callback.data.split("_")
    session = await get_session(int(session_id))
    subject = session["subject"] if session else "math"
    qs = QUESTIONS.get(subject, QUESTIONS["math"])
    q = qs[int(q_idx)]
    
    correct = int(ans_idx) == q["answer"]
    if correct:
        await update_xp(callback.from_user.id, XP_REWARDS["quiz_correct"])
        res = "✅ <b>صح!</b> +15 XP 🎉"
    else:
        res = f"❌ <b>خطأ!</b> الجواب: <b>{q['options'][q['answer']]}</b>"

    next_idx = int(q_idx) + 1
    if next_idx < len(qs) and next_idx < 3:
        nq = qs[next_idx]
        await callback.message.edit_text(f"{res}\n\n❓ {nq['q']}", reply_markup=quiz_keyboard(nq["options"], int(session_id), next_idx), parse_mode="HTML")
    else:
        await callback.message.edit_text(f"{res}\n\n🏁 <b>انتهى الاختبار!</b> 💪", reply_markup=back_to_menu(), parse_mode="HTML")
    await callback.answer()

@router.callback_query(F.data == "quick_quiz")
async def cb_quick_quiz(callback: CallbackQuery):
    subject = random.choice(list(QUESTIONS.keys()))
    q = QUESTIONS[subject][0]
    await callback.message.edit_text(f"🧠 <b>اختبار سريع: {SUBJECTS.get(subject, subject)}</b>\n\n❓ {q['q']}", 
                                     reply_markup=standalone_quiz_keyboard(q["options"], subject, 0), parse_mode="HTML")
    await callback.answer()

@router.callback_query(F.data.startswith("sqz_"))
async def cb_standalone_quiz(callback: CallbackQuery):
    _, subject, q_idx, ans_idx = callback.data.split("_")
    qs = QUESTIONS.get(subject, QUESTIONS["math"])
    q = qs[int(q_idx)]
    
    correct = int(ans_idx) == q["answer"]
    if correct:
        await update_xp(callback.from_user.id, XP_REWARDS["quiz_correct"])
        res = "✅ <b>صح!</b> +15 XP 🎉"
    else:
        res = f"❌ <b>خطأ!</b> الجواب: <b>{q['options'][q['answer']]}</b>"

    next_idx = int(q_idx) + 1
    if next_idx < len(qs) and next_idx < 3:
        nq = qs[next_idx]
        await callback.message.edit_text(f"{res}\n\n❓ {nq['q']}", reply_markup=standalone_quiz_keyboard(nq["options"], subject, next_idx), parse_mode="HTML")
    else:
        await callback.message.edit_text(f"{res}\n\n🏁 <b>انتهى الاختبار!</b> 💪", reply_markup=back_to_menu(), parse_mode="HTML")
    await callback.answer()
