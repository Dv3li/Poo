import asyncio
from aiogram import Router, F
from aiogram.types import CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database import (
    create_session, finalize_session, update_xp,
    advance_challenge, get_active_challenge,
    get_recent_stats, get_user
)
from keyboards import subject_keyboard, duration_keyboard, session_complete_keyboard, back_to_menu
from config import XP_REWARDS, get_level_info, SUBJECTS

router = Router()

class SessionState(StatesGroup):
    choosing_subject = State()
    choosing_duration = State()
    in_session = State()

async def check_consecutive_fails(user_id: int) -> bool:
    stats = await get_recent_stats(user_id, 3)
    return len(stats) >= 3 and all(s == 0 for s in stats)

@router.callback_query(F.data == "start_session")
async def cb_start_session(callback: CallbackQuery, state: FSMContext):
    include_5 = await check_consecutive_fails(callback.from_user.id)
    await state.set_state(SessionState.choosing_subject)
    text = "😤 لاحظت فشلك المتكرر. ابدأ بـ 5 دقائق!" if include_5 else "📚 <b>اختر المادة التي ستدرسها:</b>"
    await callback.message.edit_text(text, reply_markup=subject_keyboard(), parse_mode="HTML")
    await callback.answer()

@router.callback_query(F.data.startswith("subject_"))
async def cb_choose_subject(callback: CallbackQuery, state: FSMContext):
    subject = callback.data.split("_")[1]
    await state.update_data(subject=subject)
    await state.set_state(SessionState.choosing_duration)
    include_5 = await check_consecutive_fails(callback.from_user.id)
    await callback.message.edit_text(
        f"✅ المادة: <b>{SUBJECTS.get(subject, subject)}</b>\n\n⏱ <b>كم دقيقة ستدرس؟</b>",
        reply_markup=duration_keyboard(include_5min=include_5),
        parse_mode="HTML"
    )
    await callback.answer()

@router.callback_query(F.data.startswith("duration_"))
async def cb_choose_duration(callback: CallbackQuery, state: FSMContext):
    duration = int(callback.data.split("_")[1])
    data = await state.get_data()
    subject = data.get("subject", "general")
    
    session_id = await create_session(callback.from_user.id, subject, duration)
    await state.update_data(session_id=session_id, duration=duration)
    await state.set_state(SessionState.in_session)

    await callback.message.edit_text(
        f"🔥 <b>الجلسة بدأت!</b>\n\n📚 المادة: <b>{SUBJECTS.get(subject, subject)}</b>\n⏱ المدة: <b>{duration} دقيقة</b>\n\n💪 ركّز. سأنبهك عند الانتهاء!",
        parse_mode="HTML"
    )
    await callback.answer("🚀 انطلق!")
    asyncio.create_task(session_timer(callback.message, session_id, duration))

async def session_timer(message, session_id: int, duration: int):
    await asyncio.sleep(duration * 60)
    try:
        await message.answer(f"⏰ <b>انتهى الوقت!</b>\n\nهل التزمت بالدراسة؟", reply_markup=session_complete_keyboard(session_id), parse_mode="HTML")
    except: pass

@router.callback_query(F.data.startswith("session_yes_"))
async def cb_session_yes(callback: CallbackQuery, state: FSMContext):
    session_id = int(callback.data.split("_")[2])
    user_id = callback.from_user.id

    await finalize_session(session_id, True)
    await update_xp(user_id, XP_REWARDS["session_complete"])
    
    challenge = await get_active_challenge(user_id)
    if challenge and await advance_challenge(challenge["id"]):
        await update_xp(user_id, XP_REWARDS["challenge_complete"])
        await callback.message.answer("🎉 <b>أكملت التحدي!</b> +100 XP إضافية! 👑", parse_mode="HTML")

    user = await get_user(user_id)
    lvl = get_level_info(user["xp"])
    
    await callback.message.edit_text(
        f"🎉 <b>جلسة ناجحة!</b>\n\n⚡ +{XP_REWARDS['session_complete']} XP\n🏆 المجموع: <b>{user['xp']} XP</b>\n🎖 المستوى: <b>{lvl['name_ar']}</b>\n🔥 Streak: <b>{user['streak']} يوم</b>\n\nالآن اختبار سريع! 🧠",
        reply_markup=back_to_menu(), parse_mode="HTML"
    )
    
    from handlers.quiz import start_quiz
    await start_quiz(callback.message, (await state.get_data()).get("subject", "general"), session_id)
    await state.clear()

@router.callback_query(F.data.startswith("session_no_"))
async def cb_session_no(callback: CallbackQuery, state: FSMContext):
    session_id = int(callback.data.split("_")[2])
    await finalize_session(session_id, False)
    await update_xp(callback.from_user.id, XP_REWARDS["session_fail"])
    
    user = await get_user(callback.from_user.id)
    await callback.message.edit_text(
        f"😤 <b>كنت أتوقع أفضل منك!</b>\n\n⚡ {XP_REWARDS['session_fail']} XP\n🏆 المجموع: <b>{user['xp']} XP</b>\n\nلا تكرر هذا. 💪",
        reply_markup=back_to_menu(), parse_mode="HTML"
    )
    await state.clear()
