# تعليمات تثبيت بوت التنزيل - أثر للتعليم

## 1. رفع الملفات للـ VPS

```bash
# إنشاء المجلد
mkdir -p /root/athar_downloader_bot
cd /root/athar_downloader_bot
```

انسخ محتوى bot.py عبر:
```bash
cat > bot.py << 'EOF'
# (الصق محتوى bot.py هنا)
EOF
```

## 2. تثبيت المتطلبات

```bash
# تثبيت ffmpeg (ضروري للتحويل)
apt update && apt install -y ffmpeg

# تثبيت yt-dlp
pip3 install yt-dlp --break-system-packages

# تثبيت aiogram
pip3 install aiogram==3.15.0 --break-system-packages
```

## 3. ضع التوكن

في bot.py غيّر هذا السطر:
```
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"
```

إلى توكن البوت من @BotFather

## 4. تشغيل تجريبي

```bash
cd /root/athar_downloader_bot
python3 bot.py
```

## 5. تشغيل كـ Service دائم

```bash
# انسخ ملف الـ service
cp athar_downloader.service /etc/systemd/system/

# تفعيل وتشغيل
systemctl daemon-reload
systemctl enable athar_downloader
systemctl start athar_downloader

# تحقق من الحالة
systemctl status athar_downloader
```

## 6. عرض اللوقات

```bash
journalctl -u athar_downloader -f
```

## المواقع المدعومة
- YouTube
- Instagram
- TikTok
- Twitter / X
- Facebook
- Reddit
- Vimeo
- Dailymotion
- Twitch
- وغيرها (كل ما يدعمه yt-dlp)

## ملاحظات
- حد تيليقرام للملفات هو 50 MB
- ffmpeg ضروري لتحويل الفيديو والصوت
- مجلد downloads ينظّف نفسه تلقائياً بعد كل عملية
