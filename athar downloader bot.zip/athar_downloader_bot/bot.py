import asyncio
import logging
import os
import re
import subprocess
import uuid
from pathlib import Path

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

# ─── إعدادات ───────────────────────────────────────────────
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"  # ← ضع توكن البوت هنا
DOWNLOAD_DIR = Path("downloads")
DOWNLOAD_DIR.mkdir(exist_ok=True)

# ─── لوقر ──────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# ─── URL Regex ─────────────────────────────────────────────
URL_PATTERN = re.compile(
    r"(https?://)"
    r"(www\.)?"
    r"("
    r"(youtube\.com|youtu\.be|"
    r"instagram\.com|"
    r"twitter\.com|x\.com|"
    r"tiktok\.com|"
    r"facebook\.com|fb\.watch|"
    r"reddit\.com|"
    r"vimeo\.com|"
    r"dailymotion\.com|"
    r"twitch\.tv|"
    r"snapchat\.com|"
    r"pinterest\.com|"
    r"linkedin\.com)"
    r")[^\s]+"
)

# ─── States ────────────────────────────────────────────────
class DownloadStates(StatesGroup):
    waiting_for_format = State()

# ─── إنشاء البوت ───────────────────────────────────────────
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())

# ─── مساعدات ───────────────────────────────────────────────
def extract_url(text: str) -> str | None:
    match = URL_PATTERN.search(text)
    return match.group(0) if match else None


def format_keyboard(url: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="🎬 فيديو", callback_data=f"video|{url}"
                ),
                InlineKeyboardButton(
                    text="🎵 ملف صوتي (MP3)", callback_data=f"audio|{url}"
                ),
            ],
            [
                InlineKeyboardButton(
                    text="🎤 Voice Note", callback_data=f"voice|{url}"
                ),
            ],
        ]
    )


def unique_path(ext: str) -> Path:
    return DOWNLOAD_DIR / f"{uuid.uuid4().hex}.{ext}"


async def run_ytdlp(args: list[str]) -> tuple[bool, str]:
    """تشغيل yt-dlp وإرجاع (نجح؟, رسالة_الخطأ)"""
    try:
        proc = await asyncio.create_subprocess_exec(
            "yt-dlp",
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=300)
        if proc.returncode == 0:
            return True, ""
        return False, stderr.decode(errors="ignore")
    except asyncio.TimeoutError:
        return False, "انتهت مهلة التنزيل (5 دقائق)"
    except FileNotFoundError:
        return False, "yt-dlp غير مثبت على الخادم"


async def download_video(url: str) -> Path | None:
    out = unique_path("mp4")
    ok, err = await run_ytdlp([
        "-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
        "--merge-output-format", "mp4",
        "--no-playlist",
        "-o", str(out),
        url,
    ])
    if ok and out.exists():
        return out
    # fallback: أي فيديو متاح
    ok, _ = await run_ytdlp([
        "-f", "best",
        "--no-playlist",
        "-o", str(out),
        url,
    ])
    return out if ok and out.exists() else None


async def download_audio(url: str) -> Path | None:
    out = unique_path("mp3")
    ok, _ = await run_ytdlp([
        "-x",
        "--audio-format", "mp3",
        "--audio-quality", "0",
        "--no-playlist",
        "-o", str(out),
        url,
    ])
    # yt-dlp قد يضيف .mp3 تلقائياً
    if not out.exists():
        mp3_variant = Path(str(out).replace(".mp3", "") + ".mp3")
        if mp3_variant.exists():
            return mp3_variant
    return out if ok and out.exists() else None


async def download_voice(url: str) -> Path | None:
    """تنزيل كصوت OGG مضغوط (مناسب لـ Voice Note)"""
    out = unique_path("ogg")
    ok, _ = await run_ytdlp([
        "-x",
        "--audio-format", "opus",
        "--audio-quality", "5",
        "--no-playlist",
        "-o", str(out),
        url,
    ])
    if not out.exists():
        ogg_variant = Path(str(out).replace(".ogg", "") + ".ogg")
        if ogg_variant.exists():
            return ogg_variant
    return out if ok and out.exists() else None


def cleanup(path: Path):
    try:
        if path and path.exists():
            path.unlink()
    except Exception:
        pass


# ─── هاندلرز ───────────────────────────────────────────────
@dp.message(CommandStart())
async def cmd_start(message: Message):
    await message.answer(
        "👋 أهلاً!\n\n"
        "أرسل لي رابط من يوتيوب، إنستقرام، تيك توك، تويتر، فيسبوك "
        "أو غيرها وسأسألك بأي صيغة تريد التنزيل."
    )


@dp.message(F.text)
async def handle_message(message: Message, state: FSMContext):
    url = extract_url(message.text or "")
    if not url:
        await message.answer("⚠️ لم أتعرف على رابط صالح في رسالتك.")
        return

    await state.set_state(DownloadStates.waiting_for_format)
    await state.update_data(url=url)

    await message.answer(
        f"🔗 تم استلام الرابط!\n\nكيف تريد التنزيل؟",
        reply_markup=format_keyboard(url),
    )


@dp.callback_query(F.data.startswith("video|"))
async def cb_video(call: CallbackQuery, state: FSMContext):
    url = call.data.split("|", 1)[1]
    await call.message.edit_text("⏳ جاري تنزيل الفيديو، انتظر قليلاً...")
    await call.answer()

    path = await download_video(url)
    if not path:
        await call.message.edit_text("❌ فشل التنزيل. تأكد أن الرابط صحيح وأن الفيديو متاح.")
        return

    size_mb = path.stat().st_size / (1024 * 1024)
    if size_mb > 49:
        await call.message.edit_text(
            f"⚠️ الفيديو كبير جداً ({size_mb:.1f} MB).\n"
            "تيليقرام يسمح بحد أقصى 50 MB. جرب رابطاً لفيديو أقصر."
        )
        cleanup(path)
        return

    await call.message.edit_text("📤 جاري الإرسال...")
    try:
        await call.message.answer_video(
            FSInputFile(path),
            caption="🎬 تم التنزيل بواسطة بوت أثر للتعليم",
        )
        await call.message.delete()
    except Exception as e:
        logger.error(f"Video send error: {e}")
        await call.message.edit_text("❌ حدث خطأ أثناء الإرسال.")
    finally:
        cleanup(path)
    await state.clear()


@dp.callback_query(F.data.startswith("audio|"))
async def cb_audio(call: CallbackQuery, state: FSMContext):
    url = call.data.split("|", 1)[1]
    await call.message.edit_text("⏳ جاري تنزيل الصوت (MP3)...")
    await call.answer()

    path = await download_audio(url)
    if not path:
        await call.message.edit_text("❌ فشل التنزيل. تأكد من صحة الرابط.")
        return

    size_mb = path.stat().st_size / (1024 * 1024)
    if size_mb > 49:
        await call.message.edit_text(f"⚠️ الملف كبير جداً ({size_mb:.1f} MB).")
        cleanup(path)
        return

    await call.message.edit_text("📤 جاري الإرسال...")
    try:
        await call.message.answer_audio(
            FSInputFile(path),
            caption="🎵 تم التنزيل بواسطة بوت أثر للتعليم",
        )
        await call.message.delete()
    except Exception as e:
        logger.error(f"Audio send error: {e}")
        await call.message.edit_text("❌ حدث خطأ أثناء الإرسال.")
    finally:
        cleanup(path)
    await state.clear()


@dp.callback_query(F.data.startswith("voice|"))
async def cb_voice(call: CallbackQuery, state: FSMContext):
    url = call.data.split("|", 1)[1]
    await call.message.edit_text("⏳ جاري التحويل إلى voice note...")
    await call.answer()

    path = await download_voice(url)
    if not path:
        await call.message.edit_text("❌ فشل التنزيل أو التحويل.")
        return

    size_mb = path.stat().st_size / (1024 * 1024)
    if size_mb > 49:
        await call.message.edit_text(f"⚠️ الملف كبير جداً ({size_mb:.1f} MB).")
        cleanup(path)
        return

    await call.message.edit_text("📤 جاري الإرسال...")
    try:
        await call.message.answer_voice(
            FSInputFile(path),
            caption="🎤 تم التنزيل بواسطة بوت أثر للتعليم",
        )
        await call.message.delete()
    except Exception as e:
        logger.error(f"Voice send error: {e}")
        await call.message.edit_text("❌ حدث خطأ أثناء الإرسال.")
    finally:
        cleanup(path)
    await state.clear()


# ─── تشغيل ─────────────────────────────────────────────────
async def main():
    logger.info("البوت يعمل...")
    await dp.start_polling(bot, skip_updates=True)


if __name__ == "__main__":
    asyncio.run(main())
